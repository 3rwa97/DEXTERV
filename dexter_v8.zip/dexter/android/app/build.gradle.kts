plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.dexter.tv"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.dexter.tv"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
        val server = (project.findProperty("DEXTER_SERVER") as String?) ?: "http://192.168.1.50:8787"
        buildConfigField("String", "DEXTER_SERVER", "\"$server\"")
        // Optional keys baked in at build time (TV-only mode), so nothing has to be typed on the TV.
        val tmdb = ((project.findProperty("TMDB_KEY") as String?) ?: "").trim()
        val claudeK = ((project.findProperty("CLAUDE_KEY") as String?) ?: "").trim()
        buildConfigField("String", "TMDB_KEY", "\"$tmdb\"")
        buildConfigField("String", "CLAUDE_KEY", "\"$claudeK\"")
        val geminiK = ((project.findProperty("GEMINI_KEY") as String?) ?: "").trim()
        val geminiM = ((project.findProperty("GEMINI_MODEL") as String?) ?: "gemini-flash-latest").trim()
        buildConfigField("String", "GEMINI_KEY", "\"$geminiK\"")
        buildConfigField("String", "GEMINI_MODEL", "\"$geminiM\"")
    }

    buildTypes {
        release {
            // Smaller + faster app. Signed with the debug key so you can sideload it straight away.
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")

    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.google.zxing:core:3.5.3")
}

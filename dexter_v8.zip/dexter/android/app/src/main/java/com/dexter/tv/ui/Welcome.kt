package com.dexter.tv.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.dexter.tv.R
import kotlinx.coroutines.delay

/** The welcome screen: Dexter's artwork fills the TV for a moment (slow zoom), then fades into the app. */
@Composable
fun WelcomeOverlay() {
    var show by rememberSaveable { mutableStateOf(true) }
    val zoom = remember { Animatable(1f) }
    LaunchedEffect(Unit) {
        if (show) {
            zoom.animateTo(1.06f, tween(3600))
        }
    }
    LaunchedEffect(Unit) {
        if (show) { delay(3200); show = false }
    }
    AnimatedVisibility(show, Modifier.fillMaxSize(), enter = fadeIn(tween(300)), exit = fadeOut(tween(700))) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            Image(
                painterResource(R.drawable.welcome), null,
                Modifier.fillMaxSize().graphicsLayer { scaleX = zoom.value; scaleY = zoom.value },
                contentScale = ContentScale.Crop,
            )
        }
    }
}

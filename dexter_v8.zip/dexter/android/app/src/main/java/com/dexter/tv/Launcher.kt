package com.dexter.tv

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.dexter.tv.data.Prefs

/**
 * Opens other apps on the TV (Netflix, Shahid, YouTube...) and talks to the user's own IPTV app, PrimeVision.
 *
 * PrimeVision bridge, tried in this order:
 *  1. Deep link template from Settings (e.g. primevision://search?q={query}) sent to the PrimeVision package.
 *  2. A standard SEARCH intent (action android.intent.action.SEARCH + query) sent to the PrimeVision package.
 *  3. Plain launch of PrimeVision (the query is passed as an extra in case the app reads it).
 */
object Launcher {
    private val known = mapOf(
        "netflix" to "com.netflix.ninja",
        "youtube" to "com.google.android.youtube.tv",
        "shahid" to "net.mbc.shahidtv",
        "prime" to "com.amazon.amazonvideo.livingroom",
        "disney" to "com.disney.disneyplus",
    )

    private fun launchIntent(ctx: Context, pkg: String): Intent? {
        val pm = ctx.packageManager
        return pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)
    }

    fun isInstalled(ctx: Context, pkg: String?): Boolean = !pkg.isNullOrBlank() && launchIntent(ctx, pkg) != null

    fun openPackage(ctx: Context, pkg: String?): Boolean {
        if (pkg.isNullOrBlank()) return false
        val i = launchIntent(ctx, pkg) ?: return false
        return start(ctx, i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Names Dexter understands from the AI or from voice: primevision, netflix, youtube, shahid, prime, disney. */
    fun openByName(ctx: Context, prefs: Prefs, name: String): Boolean {
        val n = name.lowercase().replace(" ", "")
        if (n.contains("primevision") || n.contains("برايم")) return openPrimeVision(ctx, prefs, null)
        val pkg = known.entries.firstOrNull { n.contains(it.key) }?.value
        return openPackage(ctx, pkg)
    }

    fun primeConfigured(prefs: Prefs) = prefs.primePkg.isNotBlank()

    fun openPrimeVision(ctx: Context, prefs: Prefs, query: String?): Boolean {
        val pkg = prefs.primePkg
        if (pkg.isBlank()) return false
        val pm = ctx.packageManager

        if (!query.isNullOrBlank() && prefs.primeLink.isNotBlank()) {
            val uri = Uri.parse(prefs.primeLink.replace("{query}", Uri.encode(query)))
            val i = Intent(Intent.ACTION_VIEW, uri).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (i.resolveActivity(pm) != null && start(ctx, i)) return true
        }
        if (!query.isNullOrBlank()) {
            val i = Intent(Intent.ACTION_SEARCH).setPackage(pkg).putExtra(SearchManager.QUERY, query).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (i.resolveActivity(pm) != null && start(ctx, i)) return true
        }
        val i = launchIntent(ctx, pkg) ?: return false
        if (!query.isNullOrBlank()) i.putExtra("query", query)
        return start(ctx, i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun openYouTube(ctx: Context, key: String): Boolean {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=$key")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return start(ctx, i)
    }

    private fun start(ctx: Context, i: Intent): Boolean = try { ctx.startActivity(i); true } catch (_: Exception) { false }
}

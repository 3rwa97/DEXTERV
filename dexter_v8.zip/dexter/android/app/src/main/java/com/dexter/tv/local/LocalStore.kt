package com.dexter.tv.local

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.CopyOnWriteArrayList

class ProfRow(
    val id: Long,
    var name: String,
    var color: String,
    var isKid: Boolean,
    var lang: String,
    var pinHash: String?,
    var favorites: List<String>,
    var genres: List<String>,
    var services: List<String>,
    var notes: List<String>,
    var spoilerSafe: Boolean,
)

class LibRow(
    val pid: Long,
    val id: Long,
    val type: String,
    var title: String,
    var poster: String?,
    var year: String,
    var watchlist: Boolean,
    var watched: Boolean,
    var reaction: Int,
    var updated: Long,
)

class ChatRow(val id: Long, val pid: Long, val role: String, val text: String, val titles: String?, val at: Long)

/** Profiles, watch memory and conversation log, saved as one small JSON file on the TV. */
class LocalStore(ctx: Context) {
    private val file = File(ctx.filesDir, "dexter_local.json")
    val profiles = CopyOnWriteArrayList<ProfRow>()
    val library = CopyOnWriteArrayList<LibRow>()
    val chat = CopyOnWriteArrayList<ChatRow>()
    @Volatile var parentPinHash: String? = null
    @Volatile private var nextId = 1L

    init { load() }

    @Synchronized fun newId(): Long = nextId++

    private fun strs(a: JSONArray?): List<String> = if (a == null) emptyList() else (0 until a.length()).map { a.optString(it) }

    private fun load() {
        try {
            if (!file.exists()) return
            val j = JSONObject(file.readText())
            nextId = j.optLong("nextId", 1L)
            parentPinHash = if (j.isNull("parentPin")) null else j.optString("parentPin")
            val ps = j.optJSONArray("profiles")
            if (ps != null) for (i in 0 until ps.length()) {
                val o = ps.getJSONObject(i)
                profiles.add(
                    ProfRow(
                        o.getLong("id"), o.optString("name"), o.optString("color", "#E50914"), o.optBoolean("isKid"), o.optString("lang", "en"),
                        if (o.isNull("pin")) null else o.optString("pin"),
                        strs(o.optJSONArray("favorites")), strs(o.optJSONArray("genres")), strs(o.optJSONArray("services")), strs(o.optJSONArray("notes")),
                        o.optBoolean("spoilerSafe", true),
                    ),
                )
            }
            val ls = j.optJSONArray("library")
            if (ls != null) for (i in 0 until ls.length()) {
                val o = ls.getJSONObject(i)
                library.add(
                    LibRow(
                        o.getLong("pid"), o.getLong("id"), o.optString("type", "movie"), o.optString("title"),
                        if (o.isNull("poster")) null else o.optString("poster"), o.optString("year"),
                        o.optBoolean("watchlist"), o.optBoolean("watched"), o.optInt("reaction"), o.optLong("updated"),
                    ),
                )
            }
            val cs = j.optJSONArray("chat")
            if (cs != null) for (i in 0 until cs.length()) {
                val o = cs.getJSONObject(i)
                chat.add(ChatRow(o.getLong("id"), o.getLong("pid"), o.optString("role"), o.optString("text"), if (o.isNull("titles")) null else o.optString("titles"), o.optLong("at")))
            }
        } catch (_: Exception) {
            // A damaged file should never stop the app from starting.
        }
    }

    @Synchronized
    fun save() {
        try {
            val j = JSONObject()
            j.put("nextId", nextId)
            j.put("parentPin", parentPinHash ?: JSONObject.NULL)
            j.put(
                "profiles",
                JSONArray().also { a ->
                    profiles.forEach { p ->
                        a.put(
                            JSONObject().put("id", p.id).put("name", p.name).put("color", p.color).put("isKid", p.isKid).put("lang", p.lang)
                                .put("pin", p.pinHash ?: JSONObject.NULL).put("favorites", JSONArray(p.favorites)).put("genres", JSONArray(p.genres))
                                .put("services", JSONArray(p.services)).put("notes", JSONArray(p.notes)).put("spoilerSafe", p.spoilerSafe),
                        )
                    }
                },
            )
            j.put(
                "library",
                JSONArray().also { a ->
                    library.forEach { r ->
                        a.put(
                            JSONObject().put("pid", r.pid).put("id", r.id).put("type", r.type).put("title", r.title).put("poster", r.poster ?: JSONObject.NULL)
                                .put("year", r.year).put("watchlist", r.watchlist).put("watched", r.watched).put("reaction", r.reaction).put("updated", r.updated),
                        )
                    }
                },
            )
            j.put(
                "chat",
                JSONArray().also { a ->
                    chat.forEach { c ->
                        a.put(JSONObject().put("id", c.id).put("pid", c.pid).put("role", c.role).put("text", c.text).put("titles", c.titles ?: JSONObject.NULL).put("at", c.at))
                    }
                },
            )
            val tmp = File(file.path + ".tmp")
            tmp.writeText(j.toString())
            tmp.renameTo(file)
        } catch (_: Exception) {
        }
    }

    /** Keep the log small: at most 300 messages per profile. */
    fun trimChat(pid: Long) {
        val mine = chat.filter { it.pid == pid }
        if (mine.size > 300) mine.take(mine.size - 300).forEach { chat.remove(it) }
    }

    // ----- PINs (salted SHA-256; the PIN is only a family lock, not bank security) -----
    private fun sha(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    fun hashPin(pin: String): String {
        val salt = ByteArray(8).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }
        return salt + ":" + sha(salt + pin)
    }

    fun checkPin(pin: String, stored: String?): Boolean {
        if (stored == null) return false
        val parts = stored.split(":")
        if (parts.size != 2) return false
        return sha(parts[0] + pin) == parts[1]
    }
}

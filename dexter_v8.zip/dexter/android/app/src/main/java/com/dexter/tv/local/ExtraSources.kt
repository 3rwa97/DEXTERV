package com.dexter.tv.local

import com.dexter.tv.data.objs
import com.dexter.tv.data.str
import com.dexter.tv.data.strOrNull
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** A show found on an outside site, before it is matched to a TMDB title (the app's main catalogue). */
class ShowRef(val name: String, val year: Int?, val imdb: String?, val rating: Double, val season: Int = 0, val number: Int = 0, val airdate: String = "")

/** Tiny cached JSON fetcher shared by the free, key-less sources below. */
private class Fetcher(private val http: OkHttpClient) {
    private class Entry(val exp: Long, val body: String)
    private val cache = object : LinkedHashMap<String, Entry>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Entry>?): Boolean = size > 80
    }

    suspend fun get(url: String, ttlMs: Long): String? = withContext(Dispatchers.IO) {
        synchronized(cache) { cache[url]?.let { if (it.exp > System.currentTimeMillis()) return@withContext it.body } }
        try {
            http.newCall(Request.Builder().url(url).header("accept", "application/json").build()).execute().use { r ->
                if (!r.isSuccessful) return@withContext null
                val b = r.body?.string().orEmpty()
                synchronized(cache) { cache[url] = Entry(System.currentTimeMillis() + ttlMs, b) }
                b
            }
        } catch (_: IOException) {
            null
        }
    }

    fun clear() { synchronized(cache) { cache.clear() } }
}

/**
 * TVmaze (api.tvmaze.com, free, no key): what is on the air tonight, new seasons starting this week,
 * and the next episode of a show. Every function is safe: on any failure it returns an empty result.
 */
class TvMazeClient(http: OkHttpClient) {
    private val f = Fetcher(http)
    fun clear() = f.clear()

    private val dayFmt get() = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    private fun refOf(ep: JSONObject): ShowRef? {
        val show = ep.optJSONObject("show") ?: ep.optJSONObject("_embedded")?.optJSONObject("show") ?: return null
        if (show.str("type") != "Scripted") return null // skip talk shows, news, reality, sports
        val rating = show.optJSONObject("rating")?.optDouble("average", 0.0) ?: 0.0
        val year = show.strOrNull("premiered")?.take(4)?.toIntOrNull()
        val imdb = show.optJSONObject("externals")?.strOrNull("imdb")
        return ShowRef(show.str("name"), year, imdb, rating, ep.optInt("season"), ep.optInt("number"), ep.str("airdate"))
    }

    /** Episodes (broadcast TV in the US + streaming) airing on a given day offset from today. */
    private suspend fun day(offset: Int): List<JSONObject> {
        val date = dayFmt.format(Date(System.currentTimeMillis() + offset * 86_400_000L))
        return coroutineScope {
            val a = async { f.get("https://api.tvmaze.com/schedule/web?date=$date", 3 * 3600_000L) }
            val b = async { f.get("https://api.tvmaze.com/schedule?country=US&date=$date", 3 * 3600_000L) }
            listOfNotNull(a.await(), b.await()).flatMap { JSONArray(it).objs() }
        }
    }

    /** Good scripted shows with a new episode today. */
    suspend fun onAirTonight(): List<ShowRef> = try {
        day(0).mapNotNull(::refOf).filter { it.rating >= 6.8 }.distinctBy { it.name }.sortedByDescending { it.rating }.take(14)
    } catch (e: CancellationException) { throw e } catch (_: Exception) { emptyList() }

    /** Season premieres (episode 1) in the next few days. */
    suspend fun premieres(): List<ShowRef> = try {
        coroutineScope { (0..5).map { d -> async { try { day(d) } catch (e: CancellationException) { throw e } catch (_: Exception) { emptyList() } } }.map { it.await() } }
            .flatten().filter { it.optInt("number") == 1 && it.str("type") == "regular" }
            .mapNotNull(::refOf).filter { it.rating == 0.0 || it.rating >= 6.5 }.distinctBy { it.name }.take(14)
    } catch (e: CancellationException) { throw e } catch (_: Exception) { emptyList() }

    /** Next episode of the show with this IMDb id, or null. */
    suspend fun nextEpisode(imdb: String): ShowRef? = try {
        val show = f.get("https://api.tvmaze.com/lookup/shows?imdb=$imdb", 6 * 3600_000L)?.let { JSONObject(it) }
        val id = show?.optLong("id") ?: 0L
        val body = if (id > 0) f.get("https://api.tvmaze.com/shows/$id?embed=nextepisode", 60 * 60_000L) else null
        val next = body?.let { JSONObject(it) }?.optJSONObject("_embedded")?.optJSONObject("nextepisode")
        if (next == null) null else ShowRef(show?.str("name").orEmpty(), null, imdb, 0.0, next.optInt("season"), next.optInt("number"), next.str("airdate"))
    } catch (e: CancellationException) { throw e } catch (_: Exception) { null }
}

/** Jikan (api.jikan.moe, free, no key): anime that is airing right now, popular with the audience. */
class JikanClient(http: OkHttpClient) {
    private val f = Fetcher(http)
    fun clear() = f.clear()

    suspend fun airingNow(): List<ShowRef> = try {
        val body = f.get("https://api.jikan.moe/v4/top/anime?filter=airing&limit=15&sfw=true", 6 * 3600_000L)
        if (body == null) emptyList() else JSONObject(body).optJSONArray("data").objs().mapNotNull { a ->
            val name = a.strOrNull("title_english") ?: a.strOrNull("title") ?: return@mapNotNull null
            ShowRef(name, null, null, a.optDouble("score", 0.0))
        }
    } catch (e: CancellationException) { throw e } catch (_: Exception) { emptyList() }
}

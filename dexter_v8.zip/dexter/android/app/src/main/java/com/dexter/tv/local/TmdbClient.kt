package com.dexter.tv.local

import com.dexter.tv.data.ApiException
import com.dexter.tv.data.Detail
import com.dexter.tv.data.Item
import com.dexter.tv.data.LibState
import com.dexter.tv.data.Prefs
import com.dexter.tv.data.Provider
import com.dexter.tv.data.objs
import com.dexter.tv.data.str
import com.dexter.tv.data.strOrNull
import com.dexter.tv.data.strs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** A title plus the extra facts needed for filtering (genres, adult flag). */
class Raw(val item: Item, val genres: List<Int>, val adult: Boolean)

val KID_GENRES = setOf(16, 10751, 10762) // Animation, Family, Kids
const val REGION = "JO"
private const val IMG = "https://image.tmdb.org/t/p"
const val ERR_NEED_TMDB = "NEED_TMDB"
const val ERR_BAD_TMDB = "BAD_TMDB"

fun isKeyError(e: ApiException) = e.message == ERR_NEED_TMDB || e.message == ERR_BAD_TMDB
fun langTag(l: String) = if (l == "ar") "ar-SA" else "en-US"
fun keyOf(i: Item) = "${i.type}:${i.id}"

/** Direct access to The Movie Database with a small in-memory cache so the TV stays fast. */
class TmdbClient(private val prefs: Prefs, private val http: OkHttpClient) {
    private class Entry(val exp: Long, val json: JSONObject)

    private val cache = object : LinkedHashMap<String, Entry>(128, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Entry>?): Boolean = size > 400
    }

    fun enabled() = prefs.tmdbKey.isNotBlank()
    fun clear() { synchronized(cache) { cache.clear() } }

    suspend fun get(path: String, params: Map<String, String> = emptyMap(), ttlMs: Long = 30 * 60_000L): JSONObject {
        if (!enabled()) throw ApiException(400, ERR_NEED_TMDB)
        val key = path + params.toSortedMap().toString()
        synchronized(cache) { cache[key]?.let { if (it.exp > System.currentTimeMillis()) return it.json } }
        val json = fetch(path, params)
        synchronized(cache) { cache[key] = Entry(System.currentTimeMillis() + ttlMs, json) }
        return json
    }

    private suspend fun fetch(path: String, params: Map<String, String>): JSONObject = withContext(Dispatchers.IO) {
        val key = prefs.tmdbKey.trim()
        val url = try {
            ("https://api.themoviedb.org/3$path").toHttpUrl().newBuilder().apply {
                params.forEach { (k, v) -> addQueryParameter(k, v) }
                if (key.length <= 40) addQueryParameter("api_key", key)
            }.build()
        } catch (e: IllegalArgumentException) {
            throw ApiException(400, ERR_BAD_TMDB)
        }
        val rb = Request.Builder().url(url).header("accept", "application/json")
        if (key.length > 40) rb.header("Authorization", "Bearer $key")
        val req = rb.build()
        var last: ApiException? = null
        for (attempt in 0..2) {
            if (attempt > 0) delay(300L * attempt)
            try {
                http.newCall(req).execute().use { r ->
                    val body = r.body?.string().orEmpty()
                    when {
                        r.code == 401 -> throw ApiException(400, ERR_BAD_TMDB)
                        r.isSuccessful -> return@withContext JSONObject(body)
                        r.code == 429 || r.code >= 500 -> last = ApiException(r.code, "TMDB ${r.code}")
                        else -> throw ApiException(r.code, "TMDB ${r.code}")
                    }
                }
            } catch (e: IOException) {
                last = ApiException(0, "network")
            }
        }
        throw last ?: ApiException(0, "network")
    }

    // ---------- normalising ----------
    fun norm(o: JSONObject, forced: String? = null): Raw? {
        val type = o.optString("media_type").ifBlank { forced ?: if (o.has("title")) "movie" else "tv" }
        if (type != "movie" && type != "tv") return null
        val item = Item(
            id = o.optLong("id"),
            type = type,
            title = o.str("title").ifBlank { o.str("name") },
            year = (o.strOrNull("release_date") ?: o.strOrNull("first_air_date") ?: "").take(4),
            poster = o.strOrNull("poster_path")?.let { "$IMG/w342$it" },
            backdrop = o.strOrNull("backdrop_path")?.let { "$IMG/w780$it" },
            rating = Math.round(o.optDouble("vote_average", 0.0) * 10) / 10.0,
            overview = o.str("overview"),
        )
        val ids = o.optJSONArray("genre_ids")?.let { a -> (0 until a.length()).map { a.optInt(it) } } ?: o.optJSONArray("genres").objs().map { it.optInt("id") }
        return Raw(item, ids, o.optBoolean("adult"))
    }

    fun clean(a: JSONArray?, forced: String? = null, kid: Boolean = false, exclude: Set<String> = emptySet()): List<Raw> =
        a.objs().mapNotNull { norm(it, forced) }
            .filter { r -> r.item.poster != null && !r.adult && (!kid || r.genres.any { it in KID_GENRES }) && keyOf(r.item) !in exclude }
            .distinctBy { keyOf(it.item) }

    // ---------- lookups ----------
    suspend fun search(q: String, lang: String, kid: Boolean): List<Raw> {
        val j = get("/search/multi", mapOf("query" to q, "language" to langTag(lang), "include_adult" to "false", "page" to "1"), 10 * 60_000L)
        return clean(j.optJSONArray("results"), null, kid).take(20)
    }

    suspend fun resolveTitle(title: String, year: Int?, type: String?, lang: String): Raw? {
        if (title.isBlank()) return null
        val path = when (type) { "movie" -> "/search/movie"; "tv" -> "/search/tv"; else -> "/search/multi" }
        val params = mutableMapOf("query" to title, "language" to langTag(lang), "include_adult" to "false")
        if (year != null && type == "movie") params["year"] = year.toString()
        if (year != null && type == "tv") params["first_air_date_year"] = year.toString()
        val kind = if (type == "movie" || type == "tv") type else null
        var list = clean(get(path, params, 60 * 60_000L).optJSONArray("results"), kind)
        if (list.isEmpty() && year != null) {
            // The AI often gets a series' year wrong (latest season instead of first air year), so retry without it.
            params.remove("year"); params.remove("first_air_date_year")
            list = clean(get(path, params, 60 * 60_000L).optJSONArray("results"), kind)
        }
        if (list.isEmpty()) return null
        return list.firstOrNull { it.item.title.equals(title, true) && (year == null || it.item.year == year.toString()) } ?: list.first()
    }

    /** Exact match through an IMDb id (TVmaze gives us these), so the right title opens. */
    suspend fun findByImdb(imdb: String, lang: String): Raw? {
        val j = get("/find/$imdb", mapOf("external_source" to "imdb_id", "language" to langTag(lang)), 24 * 3600_000L)
        return clean(j.optJSONArray("tv_results"), "tv").firstOrNull()
    }

    suspend fun imdbId(type: String, id: Long): String? = get("/$type/$id/external_ids", emptyMap(), 24 * 3600_000L).strOrNull("imdb_id")

    suspend fun lists(kind: String, lang: String, kid: Boolean, exclude: Set<String>): List<Raw> {
        val l = langTag(lang)
        val kidMovie = if (kid) mapOf("with_genres" to "16|10751", "certification_country" to "US", "certification.lte" to "PG") else emptyMap()
        val kidTv = if (kid) mapOf("with_genres" to "16|10751|10762") else emptyMap()
        val base = mapOf("language" to l, "include_adult" to "false")
        return when (kind) {
            "trending" -> clean(get("/trending/all/week", mapOf("language" to l), 60 * 60_000L).optJSONArray("results"), null, kid, exclude)
            "arabic-tv" -> clean(get("/discover/tv", base + mapOf("with_original_language" to "ar", "sort_by" to "popularity.desc", "vote_count.gte" to "20") + kidTv, 6 * 3600_000L).optJSONArray("results"), "tv", kid, exclude)
            "arabic-movie" -> clean(get("/discover/movie", base + mapOf("with_original_language" to "ar", "sort_by" to "popularity.desc", "vote_count.gte" to "20") + kidMovie, 6 * 3600_000L).optJSONArray("results"), "movie", kid, exclude)
            "top-movie" -> clean(get("/discover/movie", base + mapOf("sort_by" to "vote_average.desc", "vote_count.gte" to "3000") + kidMovie, 12 * 3600_000L).optJSONArray("results"), "movie", kid, exclude)
            "top-tv" -> clean(get("/discover/tv", base + mapOf("sort_by" to "vote_average.desc", "vote_count.gte" to "1500") + kidTv, 12 * 3600_000L).optJSONArray("results"), "tv", kid, exclude)
            "family" -> clean(
                get("/discover/movie", base + mapOf("with_genres" to "10751|16", "sort_by" to "popularity.desc", "vote_count.gte" to "300", "certification_country" to "US", "certification.lte" to "PG"), 6 * 3600_000L).optJSONArray("results"),
                "movie", kid, exclude,
            )
            else -> emptyList()
        }
    }

    suspend fun genreDiscover(genreIds: List<Int>, type: String, lang: String, kid: Boolean, exclude: Set<String>): List<Raw> {
        val p = mutableMapOf("language" to langTag(lang), "with_genres" to genreIds.joinToString(","), "sort_by" to "popularity.desc", "vote_count.gte" to "200", "include_adult" to "false")
        if (kid && type == "movie") { p["certification_country"] = "US"; p["certification.lte"] = "PG" }
        return clean(get("/discover/$type", p, 3 * 3600_000L).optJSONArray("results"), type, kid, exclude)
    }

    /** Several pages of one category (genre ids joined with OR, or AND when [any] is false), most popular first. */
    suspend fun genrePages(genreIds: List<Int>, type: String, lang: String, kid: Boolean, exclude: Set<String>, pages: Int = 3, any: Boolean = true): List<Raw> = coroutineScope {
        (1..pages).map { pg ->
            async {
                try {
                    val p = mutableMapOf("language" to langTag(lang), "with_genres" to genreIds.joinToString(if (any) "|" else ","), "sort_by" to "popularity.desc", "vote_count.gte" to "150", "include_adult" to "false", "page" to pg.toString())
                    if (kid && type == "movie") { p["certification_country"] = "US"; p["certification.lte"] = "PG" }
                    clean(get("/discover/$type", p, 3 * 3600_000L).optJSONArray("results"), type, kid, exclude)
                } catch (e: ApiException) {
                    if (isKeyError(e)) throw e else emptyList()
                }
            }
        }.flatMap { it.await() }
    }.distinctBy { keyOf(it.item) }

    suspend fun recommendations(type: String, id: Long, lang: String, kid: Boolean, exclude: Set<String>): List<Raw> =
        clean(get("/$type/$id/recommendations", mapOf("language" to langTag(lang)), 12 * 3600_000L).optJSONArray("results"), type, kid, exclude)

    private val packages = listOf(
        Regex("netflix", RegexOption.IGNORE_CASE) to "com.netflix.ninja",
        Regex("shahid", RegexOption.IGNORE_CASE) to "net.mbc.shahidtv",
        Regex("amazon|prime", RegexOption.IGNORE_CASE) to "com.amazon.amazonvideo.livingroom",
        Regex("disney", RegexOption.IGNORE_CASE) to "com.disney.disneyplus",
        Regex("apple tv", RegexOption.IGNORE_CASE) to "com.apple.atve.androidtv.appletv",
        Regex("youtube", RegexOption.IGNORE_CASE) to "com.google.android.youtube.tv",
        Regex("osn", RegexOption.IGNORE_CASE) to "com.osn.stargate.tv",
        Regex("max|hbo", RegexOption.IGNORE_CASE) to "com.wbd.stream",
        Regex("viu", RegexOption.IGNORE_CASE) to "com.vuclip.viu",
        Regex("starz", RegexOption.IGNORE_CASE) to "com.parsifal.starz",
    )
    private fun pkgFor(name: String): String? = packages.firstOrNull { it.first.containsMatchIn(name) }?.second

    suspend fun providerIdsFor(names: List<String>): List<Int> {
        if (names.isEmpty()) return emptyList()
        val all = coroutineScope {
            listOf("movie", "tv").map { t -> async { get("/watch/providers/$t", mapOf("watch_region" to REGION, "language" to "en-US"), 24 * 3600_000L).optJSONArray("results").objs() } }
        }.flatMap { it.await() }
        return names.mapNotNull { n -> all.firstOrNull { it.str("provider_name").contains(n, true) }?.optInt("provider_id") }.distinct()
    }

    suspend fun newThisWeek(lang: String, kid: Boolean, providerIds: List<Int>): List<Raw> {
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val since = fmt.format(Date(System.currentTimeMillis() - 7 * 86_400_000L))
        val until = fmt.format(Date())
        val common = mutableMapOf("language" to langTag(lang), "sort_by" to "popularity.desc", "include_adult" to "false", "watch_region" to REGION)
        if (providerIds.isNotEmpty()) common["with_watch_providers"] = providerIds.joinToString("|")
        val (m, t) = coroutineScope {
            val a = async { get("/discover/movie", common + mapOf("primary_release_date.gte" to since, "primary_release_date.lte" to until) + (if (kid) mapOf("with_genres" to "16|10751") else emptyMap()), 3 * 3600_000L) }
            val b = async { get("/discover/tv", common + mapOf("air_date.gte" to since, "air_date.lte" to until) + (if (kid) mapOf("with_genres" to "16|10751|10762") else emptyMap()), 3 * 3600_000L) }
            a.await() to b.await()
        }
        return (clean(m.optJSONArray("results"), "movie", kid) + clean(t.optJSONArray("results"), "tv", kid)).sortedByDescending { it.item.rating }.take(12)
    }

    /** Full details page. Returns the detail (with an empty library state) and the genre ids for kid checks. */
    suspend fun details(type: String, id: Long, lang: String): Pair<Detail, List<Int>> {
        val j = get(
            "/$type/$id",
            mapOf("language" to langTag(lang), "append_to_response" to "videos,credits,similar,watch/providers,release_dates,content_ratings", "include_video_language" to "en,ar,null"),
            60 * 60_000L,
        )
        val base = norm(j, type) ?: throw ApiException(404, "Not found")
        var overview = j.str("overview")
        if (overview.isBlank() && lang != "en") overview = get("/$type/$id", mapOf("language" to "en-US"), 6 * 3600_000L).str("overview")
        val vids = (j.optJSONObject("videos")?.optJSONArray("results")).objs().filter { it.str("site") == "YouTube" }
        val trailer = vids.firstOrNull { it.str("type") == "Trailer" && it.optBoolean("official") } ?: vids.firstOrNull { it.str("type") == "Trailer" } ?: vids.firstOrNull()
        val region = j.optJSONObject("watch/providers")?.optJSONObject("results")?.optJSONObject(REGION)
        val providers = ArrayList<Provider>()
        for ((kind, key) in listOf("stream" to "flatrate", "rent" to "rent", "buy" to "buy", "free" to "free")) {
            for (p in region?.optJSONArray(key).objs()) {
                val name = p.str("provider_name")
                if (providers.none { it.name == name && it.kind == kind }) providers.add(Provider(name, kind, pkgFor(name)))
            }
        }
        val cert = if (type == "movie") {
            j.optJSONObject("release_dates")?.optJSONArray("results").objs().firstOrNull { it.str("iso_3166_1") == "US" }
                ?.optJSONArray("release_dates").objs().firstOrNull { it.str("certification").isNotBlank() }?.str("certification") ?: ""
        } else {
            j.optJSONObject("content_ratings")?.optJSONArray("results").objs().firstOrNull { it.str("iso_3166_1") == "US" }?.str("rating") ?: ""
        }
        val runtime = if (j.optInt("runtime") > 0) j.optInt("runtime") else j.optJSONArray("episode_run_time")?.let { if (it.length() > 0) it.optInt(0) else 0 } ?: 0
        val detail = Detail(
            item = base.item.copy(overview = overview),
            tagline = j.str("tagline"),
            runtime = runtime,
            seasons = j.optInt("number_of_seasons"),
            genres = j.optJSONArray("genres").objs().map { it.str("name") },
            cast = (j.optJSONObject("credits")?.optJSONArray("cast")).objs().take(8).map { it.str("name") },
            trailerKey = trailer?.strOrNull("key"),
            providers = providers,
            certification = cert,
            similar = clean(j.optJSONObject("similar")?.optJSONArray("results"), type).map { it.item }.take(12),
            state = LibState(),
        )
        return detail to base.genres
    }
}

package com.dexter.tv.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// Small hand-drawn icons (no icon library needed). Every icon is drawn on a square of [size].

@Composable
fun MicIcon(size: Dp, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension
        val sw = s * 0.09f
        val cw = s * 0.32f
        drawRoundRect(color, Offset((s - cw) / 2f, s * 0.04f), Size(cw, s * 0.52f), CornerRadius(cw / 2f))
        drawArc(color, 0f, 180f, false, Offset(s * 0.2f, s * 0.2f), Size(s * 0.6f, s * 0.56f), style = Stroke(sw, cap = StrokeCap.Round))
        drawLine(color, Offset(s * 0.5f, s * 0.76f), Offset(s * 0.5f, s * 0.93f), sw, StrokeCap.Round)
        drawLine(color, Offset(s * 0.34f, s * 0.93f), Offset(s * 0.66f, s * 0.93f), sw, StrokeCap.Round)
    }
}

@Composable
fun KeyboardIcon(size: Dp, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension
        val sw = s * 0.08f
        drawRoundRect(color, Offset(s * 0.05f, s * 0.22f), Size(s * 0.9f, s * 0.56f), CornerRadius(s * 0.12f), style = Stroke(sw))
        val r = s * 0.04f
        for (row in 0..1) for (col in 0..3) drawCircle(color, r, Offset(s * (0.24f + col * 0.17f), s * (0.38f + row * 0.13f)))
        drawLine(color, Offset(s * 0.32f, s * 0.64f), Offset(s * 0.68f, s * 0.64f), sw * 0.8f, StrokeCap.Round)
    }
}

@Composable
fun ClockIcon(size: Dp, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension
        val sw = s * 0.09f
        drawCircle(color, s * 0.4f, center, style = Stroke(sw))
        drawLine(color, center, Offset(s * 0.5f, s * 0.26f), sw, StrokeCap.Round)
        drawLine(color, center, Offset(s * 0.66f, s * 0.58f), sw, StrokeCap.Round)
    }
}

@Composable
fun SearchIcon(size: Dp, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension
        val sw = s * 0.1f
        drawCircle(color, s * 0.27f, Offset(s * 0.43f, s * 0.43f), style = Stroke(sw))
        drawLine(color, Offset(s * 0.63f, s * 0.63f), Offset(s * 0.9f, s * 0.9f), sw, StrokeCap.Round)
    }
}

@Composable
fun PlayIcon(size: Dp, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension
        val p = Path().apply {
            moveTo(s * 0.22f, s * 0.12f); lineTo(s * 0.88f, s * 0.5f); lineTo(s * 0.22f, s * 0.88f); close()
        }
        drawPath(p, color)
    }
}

@Composable
fun StopIcon(size: Dp, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension
        drawRoundRect(color, Offset(s * 0.2f, s * 0.2f), Size(s * 0.6f, s * 0.6f), CornerRadius(s * 0.1f))
    }
}

/** Rounded pill button with a drawn icon and a short label. */
@Composable
fun DIconButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, primary: Boolean = false, icon: @Composable (Color) -> Unit) {
    Focusable(
        onClick, modifier,
        shape = RoundedCornerShape(50),
        color = if (primary) C.Accent else C.Panel2,
        focusColor = if (primary) C.AccentHi else Color(0xFF2E2420),
        ring = Color.White,
    ) {
        Row(
            Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(7.dp),
        ) {
            icon(Color.White)
            T(text, 13, weight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

/** The big round talk button: a violet-to-pink gradient disc with a mic. Turns warm while listening. */
@Composable
fun MicOrbButton(listening: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier, size: Dp = 56.dp) {
    Focusable(
        onClick, modifier.size(size),
        shape = CircleShape,
        color = Color.Transparent, focusColor = Color.Transparent,
        ring = Color.White, scale = 1.14f, glow = if (listening) C.Pink else C.Glow,
    ) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.linearGradient(if (listening) listOf(C.Pink, Color(0xFFFF8A5C)) else listOf(C.Accent, C.Cyan)),
                CircleShape,
            ),
            contentAlignment = Alignment.Center,
        ) { MicIcon(size * 0.46f, Color.White) }
    }
}

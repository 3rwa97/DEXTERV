package com.dexter.tv.data

import org.json.JSONArray
import org.json.JSONObject

data class Item(
    val id: Long,
    val type: String,
    val title: String,
    val year: String,
    val poster: String?,
    val backdrop: String?,
    val rating: Double,
    val overview: String,
    val why: String? = null,
    val lovedBy: List<String> = emptyList(),
)

data class HomeRow(val id: String, val title: String, val items: List<Item>)

data class Profile(
    val id: Long,
    val name: String,
    val color: String,
    val isKid: Boolean,
    val lang: String,
    val hasPin: Boolean,
    val favorites: List<String>,
    val genres: List<String>,
    val services: List<String>,
    val spoilerSafe: Boolean,
)

data class ChatMsg(val id: Long, val role: String, val text: String, val titles: List<Item> = emptyList())
data class ChatReply(val reply: String, val titles: List<Item>, val openApp: String?)

data class Provider(val name: String, val kind: String, val pkg: String?)
data class LibState(val watchlist: Boolean = false, val watched: Boolean = false, val reaction: Int = 0)

data class Detail(
    val item: Item,
    val tagline: String,
    val runtime: Int,
    val seasons: Int,
    val genres: List<String>,
    val cast: List<String>,
    val trailerKey: String?,
    val providers: List<Provider>,
    val certification: String,
    val similar: List<Item>,
    val state: LibState,
    /** Extra one-liner shown on the page, e.g. the next episode date (from TVmaze). */
    val extra: String = "",
)

data class Briefing(
    val greeting: String,
    val date: String,
    val text: String,
    val weather: String,
    val pick: Item?,
    val fresh: List<Item>,
    val watchlist: List<Item>,
)

data class Me(val email: String, val hasParentPin: Boolean, val creatorName: String, val creatorEmail: String, val ai: Boolean, val tmdb: Boolean)

data class DeviceLogin(val deviceCode: String, val userCode: String, val verifyUrl: String, val expiresIn: Int)

// ---------- JSON helpers (org.json returns "null" for JSON null, so we check explicitly) ----------
fun JSONObject.str(k: String, d: String = ""): String = if (isNull(k)) d else optString(k, d)
fun JSONObject.strOrNull(k: String): String? = if (isNull(k)) null else optString(k).ifBlank { null }
fun JSONArray?.objs(): List<JSONObject> = if (this == null) emptyList() else (0 until length()).mapNotNull { optJSONObject(it) }
fun JSONArray?.strs(): List<String> = if (this == null) emptyList() else (0 until length()).mapNotNull { if (isNull(it)) null else optString(it) }

fun parseItem(o: JSONObject) = Item(
    id = o.optLong("id"),
    type = o.str("type", "movie"),
    title = o.str("title"),
    year = o.str("year"),
    poster = o.strOrNull("poster"),
    backdrop = o.strOrNull("backdrop"),
    rating = o.optDouble("rating", 0.0),
    overview = o.str("overview"),
    why = o.strOrNull("why"),
    lovedBy = o.optJSONArray("lovedBy").strs(),
)

// distinctBy: lazy lists crash on duplicate keys, so each title may appear only once per list.
fun parseItems(a: JSONArray?): List<Item> = a.objs().map(::parseItem).distinctBy { "${it.type}:${it.id}" }

fun parseProfile(o: JSONObject) = Profile(
    id = o.optLong("id"),
    name = o.str("name"),
    color = o.str("color", "#E50914"),
    isKid = o.optBoolean("isKid"),
    lang = o.str("lang", "en"),
    hasPin = o.optBoolean("hasPin"),
    favorites = o.optJSONArray("favorites").strs(),
    genres = o.optJSONArray("genres").strs(),
    services = o.optJSONArray("services").strs(),
    spoilerSafe = o.optBoolean("spoilerSafe", true),
)

fun parseRows(j: JSONObject): List<HomeRow> = j.optJSONArray("rows").objs().map { HomeRow(it.str("id"), it.str("title"), parseItems(it.optJSONArray("items"))) }

fun parseLib(o: JSONObject?) = if (o == null) LibState() else LibState(o.optBoolean("watchlist"), o.optBoolean("watched"), o.optInt("reaction"))

fun parseDetail(o: JSONObject) = Detail(
    item = parseItem(o),
    tagline = o.str("tagline"),
    runtime = o.optInt("runtime"),
    seasons = o.optInt("seasons"),
    genres = o.optJSONArray("genres").strs(),
    cast = o.optJSONArray("cast").strs(),
    trailerKey = o.strOrNull("trailerKey"),
    providers = o.optJSONArray("providers").objs().map { Provider(it.str("name"), it.str("kind"), it.strOrNull("pkg")) },
    certification = o.str("certification"),
    similar = parseItems(o.optJSONArray("similar")),
    state = parseLib(o.optJSONObject("state")),
)

fun parseBriefing(o: JSONObject): Briefing {
    val w = o.optJSONObject("weather")
    return Briefing(
        greeting = o.str("greeting"),
        date = o.str("date"),
        text = o.str("text"),
        weather = if (w == null) "" else "${w.optInt("temp")}°C  ${w.str("summary")}".trim(),
        pick = o.optJSONObject("pick")?.let(::parseItem),
        fresh = parseItems(o.optJSONArray("newThisWeek")),
        watchlist = parseItems(o.optJSONArray("watchlist")),
    )
}

package com.dexter.tv.data

import org.json.JSONObject

/**
 * Everything the app needs from "the brain". Two implementations:
 *  - Api          talks to a Dexter server (accounts, QR sign-in, many TVs share profiles)
 *  - LocalBackend runs entirely on this TV (no server, no account; data stays on the TV)
 */
interface Backend {
    suspend fun deviceStart(name: String): DeviceLogin
    suspend fun devicePoll(code: String): String?
    suspend fun me(): Me
    suspend fun logout()

    suspend fun profiles(): List<Profile>
    suspend fun saveProfile(id: Long?, body: JSONObject): Profile
    suspend fun deleteProfile(id: Long, parentPin: String?)
    suspend fun verifyProfilePin(id: Long, pin: String)
    suspend fun verifyParentPin(pin: String)
    suspend fun setParentPin(pin: String, current: String?)

    suspend fun homeRaw(): JSONObject
    suspend fun briefingRaw(tz: String): JSONObject
    suspend fun search(q: String): List<Item>
    suspend fun title(type: String, id: Long): Detail
    suspend fun why(type: String, id: Long): String

    suspend fun library(filter: String): List<Item>
    suspend fun setLibrary(item: Item, watchlist: Boolean?, watched: Boolean?, reaction: Int?): LibState

    suspend fun chat(message: String, tz: String): ChatReply
    /** Mood-based picks. Servers without a mood endpoint just treat it as a chat message. */
    suspend fun mood(text: String, tz: String, genres: List<Int> = emptyList(), all: Boolean = false): ChatReply = chat(text, tz)
    suspend fun chatLog(q: String? = null, limit: Int = 40): List<ChatMsg>
    suspend fun clearLog()

    suspend fun vote(ids: List<Long>): Pair<List<Item>, Boolean>
    suspend fun inbox(): List<Item>
}

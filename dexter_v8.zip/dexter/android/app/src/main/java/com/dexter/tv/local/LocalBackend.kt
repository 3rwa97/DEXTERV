package com.dexter.tv.local

import android.content.Context
import com.dexter.tv.data.ApiException
import com.dexter.tv.data.Backend
import com.dexter.tv.data.ChatMsg
import com.dexter.tv.data.ChatReply
import com.dexter.tv.data.Detail
import com.dexter.tv.data.DeviceLogin
import com.dexter.tv.data.Item
import com.dexter.tv.data.LibState
import com.dexter.tv.data.Me
import com.dexter.tv.data.Prefs
import com.dexter.tv.data.Profile
import com.dexter.tv.data.objs
import com.dexter.tv.data.parseItems
import com.dexter.tv.data.str
import com.dexter.tv.data.strs
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

private val COLORS = listOf("#E50914", "#F5A524", "#17C964", "#0E8AFF", "#9353D3", "#F31260", "#06B7DB", "#FF7A59")

private val GENRE_WORDS: List<Pair<Regex, Int>> = listOf(
    Regex("comed|funny|ضحك|كوميد", RegexOption.IGNORE_CASE) to 35,
    Regex("horror|scary|رعب|مخيف", RegexOption.IGNORE_CASE) to 27,
    Regex("action|اكشن|أكشن", RegexOption.IGNORE_CASE) to 28,
    Regex("drama|دراما", RegexOption.IGNORE_CASE) to 18,
    Regex("romanc|love|رومانس|حب", RegexOption.IGNORE_CASE) to 10749,
    Regex("sci-?fi|space|خيال علمي|فضاء", RegexOption.IGNORE_CASE) to 878,
    Regex("thriller|suspense|اثارة|إثارة|تشويق", RegexOption.IGNORE_CASE) to 53,
    Regex("anim|cartoon|انمي|أنمي|كرتون|رسوم", RegexOption.IGNORE_CASE) to 16,
    Regex("crime|جريمة|جريمه", RegexOption.IGNORE_CASE) to 80,
    Regex("documentar|وثائق", RegexOption.IGNORE_CASE) to 99,
    Regex("family|عائل|أطفال|اطفال|kids", RegexOption.IGNORE_CASE) to 10751,
    Regex("fantasy|فانتازيا|خيال", RegexOption.IGNORE_CASE) to 14,
    Regex("mystery|لغز|غموض", RegexOption.IGNORE_CASE) to 9648,
    Regex("adventure|مغامر", RegexOption.IGNORE_CASE) to 12,
)

private val ROW_TITLES = mapOf(
    "en" to mapOf("foryou" to "Picked for you", "mylist" to "My list", "fresh" to "New this week", "trending" to "Trending now", "arTv" to "Arabic series", "arMovie" to "Arabic movies", "family" to "Family time", "topMovie" to "Top rated movies", "topTv" to "Top rated series", "onAir" to "On the air tonight", "premieres" to "New seasons this week", "anime" to "Anime airing now"),
    "ar" to mapOf("foryou" to "مختارات لك", "mylist" to "قائمتي", "fresh" to "جديد هذا الأسبوع", "trending" to "الأكثر مشاهدة الآن", "arTv" to "مسلسلات عربية", "arMovie" to "أفلام عربية", "family" to "وقت العائلة", "topMovie" to "أفضل الأفلام تقييماً", "topTv" to "أفضل المسلسلات تقييماً", "onAir" to "مسلسلات تُعرض الليلة", "premieres" to "مواسم جديدة هذا الأسبوع", "anime" to "أنمي يُعرض الآن"),
)

private val GREET = mapOf(
    "en" to mapOf("morning" to "Good morning", "afternoon" to "Good afternoon", "evening" to "Good evening", "night" to "Hello, night owl"),
    "ar" to mapOf("morning" to "صباح الخير", "afternoon" to "نهارك سعيد", "evening" to "مساء الخير", "night" to "أهلاً يا سهران"),
)

private val WMO_EN = mapOf(0 to "clear", 1 to "mostly clear", 2 to "partly cloudy", 3 to "cloudy", 45 to "foggy", 48 to "foggy", 51 to "drizzly", 53 to "drizzly", 55 to "drizzly", 61 to "rainy", 63 to "rainy", 65 to "heavy rain", 71 to "snowy", 73 to "snowy", 75 to "snowy", 80 to "showery", 81 to "showery", 82 to "stormy", 95 to "stormy", 96 to "stormy", 99 to "stormy")
private val WMO_AR = mapOf(0 to "صافي", 1 to "صافي غالباً", 2 to "غائم جزئياً", 3 to "غائم", 45 to "ضبابي", 48 to "ضبابي", 51 to "رذاذ", 53 to "رذاذ", 55 to "رذاذ", 61 to "ماطر", 63 to "ماطر", 65 to "مطر غزير", 71 to "ثلجي", 73 to "ثلجي", 75 to "ثلجي", 80 to "زخات مطر", 81 to "زخات مطر", 82 to "عاصف", 95 to "عاصف", 96 to "عاصف", 99 to "عاصف")

private val FALLBACK = mapOf(
    "en" to mapOf(
        "genre" to "Here are a few picks that match your mood.",
        "found" to "Here is what I found.",
        "none" to "I couldn't find that. Try another title or tell me a mood, like something funny or a thriller.",
        "trending" to "Here's what everyone is watching this week.",
        "hi" to "Hi! I'm Dexter. Tell me your mood, a favorite title, or just say surprise me.",
    ),
    "ar" to mapOf(
        "genre" to "هذه بعض الاقتراحات التي تناسب مزاجك.",
        "found" to "هذا ما وجدته.",
        "none" to "لم أجد ذلك. جرّب عنواناً آخر أو أخبرني بمزاجك، مثل شيء مضحك أو فيلم إثارة.",
        "trending" to "هذا ما يشاهده الجميع هذا الأسبوع.",
        "hi" to "أهلاً! أنا ديكستر. أخبرني بمزاجك أو بفيلم تحبه، أو قل لي فاجئني.",
    ),
)

/** TMDB movie genre ids to their series equivalents (horror, romance and thriller have none for series). */
private fun tvGenres(ids: List<Int>): List<Int> = ids.mapNotNull { when (it) { 28, 12 -> 10759; 878, 14 -> 10765; 35, 18, 80, 9648, 10751, 16, 99 -> it; else -> null } }.distinct()

/** "movie" or "tv" when the viewer clearly asked for only one of them ("action movies", "مسلسلات كوميدية"), else null. */
private fun typeWish(msg: String): String? {
    val movie = Regex("movie|film|فيلم|أفلام|افلام", RegexOption.IGNORE_CASE).containsMatchIn(msg)
    val tv = Regex("series|\\bshows?\\b|\\btv\\b|مسلسل|مسلسلات", RegexOption.IGNORE_CASE).containsMatchIn(msg)
    return if (movie && !tv) "movie" else if (tv && !movie) "tv" else null
}

private fun wishRule(wish: String?): String = when (wish) {
    "movie" -> "\n\nIMPORTANT: the viewer asked for MOVIES ONLY. Every title must have type movie. Do not include any series."
    "tv" -> "\n\nIMPORTANT: the viewer asked for SERIES ONLY. Every title must have type tv. Do not include any movies."
    else -> ""
}

/** Alternates two lists: first of a, first of b, second of a, and so on. */
private fun <T> interleave(a: List<T>, b: List<T>): List<T> {
    val n = minOf(a.size, b.size)
    return (0 until n).flatMap { listOf(a[it], b[it]) } + a.drop(n) + b.drop(n)
}

private fun hasArabic(s: String) = s.any { it in '؀'..'ۿ' }
private fun detectLang(s: String, fallback: String) = if (hasArabic(s)) "ar" else if (s.any { it in 'a'..'z' || it in 'A'..'Z' }) "en" else fallback

private fun itemJson(i: Item): JSONObject = JSONObject().put("id", i.id).put("type", i.type).put("title", i.title).put("year", i.year)
    .put("poster", i.poster ?: JSONObject.NULL).put("backdrop", i.backdrop ?: JSONObject.NULL).put("rating", i.rating)
    .put("overview", i.overview.take(220)).put("why", i.why ?: JSONObject.NULL).put("lovedBy", JSONArray(i.lovedBy))

private fun slimLib(x: LibRow) = Item(x.id, x.type, x.title, x.year, x.poster, null, 0.0, "")

private fun cleanList(a: Collection<String>, max: Int = 40, len: Int = 80): List<String> =
    a.map { it.trim().take(len) }.filter { it.isNotEmpty() }.distinct().take(max)

private class Timed<T>(val v: T, val exp: Long)

/** Dexter running entirely on the TV: no server, no account. Same behaviour as the server version. */
class LocalBackend(ctx: Context, private val prefs: Prefs) : Backend {
    private val http = OkHttpClient.Builder().connectTimeout(8, TimeUnit.SECONDS).readTimeout(25, TimeUnit.SECONDS).retryOnConnectionFailure(true).build()
    private val tmdb = TmdbClient(prefs, http)
    private val claude = ClaudeClient(prefs, http)
    private val gemini = GeminiClient(prefs, http)
    private val ai = Ai(claude, gemini)
    private val tvmaze = TvMazeClient(http)
    private val jikan = JikanClient(http)
    private val store = LocalStore(ctx)
    private val lock = Mutex()
    private val forYouCache = HashMap<String, Timed<List<Item>>>()
    private val briefCache = HashMap<String, Timed<JSONObject>>()
    private var weatherCache: Timed<Pair<Int, Int>?>? = null

    fun clearCaches() {
        tmdb.clear(); tvmaze.clear(); jikan.clear()
        synchronized(forYouCache) { forYouCache.clear() }
        synchronized(briefCache) { briefCache.clear() }
        weatherCache = null
    }

    // ---------- account (none in this mode) ----------
    override suspend fun deviceStart(name: String): DeviceLogin = throw ApiException(400, "Not used in TV-only mode")
    override suspend fun devicePoll(code: String): String? = null
    override suspend fun me(): Me = Me("This TV only", store.parentPinHash != null, "Orwa Shoura", "orwashoura@gmail.com", ai.enabled(), tmdb.enabled())
    override suspend fun logout() {}

    // ---------- profiles ----------
    private fun out(p: ProfRow) = Profile(p.id, p.name, p.color, p.isKid, p.lang, p.pinHash != null, p.favorites, p.genres, p.services, p.spoilerSafe)
    private fun prof(id: Long): ProfRow = store.profiles.firstOrNull { it.id == id } ?: throw ApiException(404, "Profile not found")
    private fun current(): ProfRow = store.profiles.firstOrNull { it.id == prefs.profileId } ?: throw ApiException(400, "Select a profile first")

    private fun jlist(o: JSONObject, k: String, max: Int = 40, len: Int = 80) = cleanList(o.optJSONArray(k).strs(), max, len)

    private fun requireParentPin(pin: String?) {
        val h = store.parentPinHash ?: return
        if (!store.checkPin(pin.orEmpty(), h)) throw ApiException(403, "Wrong parent PIN")
    }

    override suspend fun profiles(): List<Profile> = store.profiles.map(::out)

    override suspend fun saveProfile(id: Long?, body: JSONObject): Profile = lock.withLock {
        if (id == null) {
            if (store.profiles.size >= 8) throw ApiException(400, "Up to 8 profiles per family")
            val name = body.str("name").trim().take(24)
            if (name.isEmpty()) throw ApiException(400, "Name is required")
            val pin = if (body.isNull("pin")) null else body.optString("pin").ifBlank { null }
            if (pin != null && !Regex("^\\d{4}$").matches(pin)) throw ApiException(400, "PIN must be 4 digits")
            val color = body.str("color").takeIf { it in COLORS } ?: COLORS[store.profiles.size % COLORS.size]
            val p = ProfRow(
                store.newId(), name, color, body.optBoolean("isKid"), if (body.str("lang") == "ar") "ar" else "en", pin?.let { store.hashPin(it) },
                jlist(body, "favorites"), jlist(body, "genres", 20, 30), jlist(body, "services", 12, 30), emptyList(), true,
            )
            store.profiles.add(p)
            store.save()
            out(p)
        } else {
            val p = prof(id)
            if (body.has("isKid") && body.optBoolean("isKid") != p.isKid) requireParentPin(body.optString("parentPin").ifBlank { null })
            if (body.has("name")) p.name = body.str("name").trim().take(24).ifBlank { p.name }
            if (body.has("color") && body.str("color") in COLORS) p.color = body.str("color")
            if (body.has("isKid")) p.isKid = body.optBoolean("isKid")
            if (body.has("lang")) p.lang = if (body.str("lang") == "ar") "ar" else "en"
            if (body.has("favorites")) p.favorites = jlist(body, "favorites")
            if (body.has("genres")) p.genres = jlist(body, "genres", 20, 30)
            if (body.has("services")) p.services = jlist(body, "services", 12, 30)
            if (body.has("spoilerSafe")) p.spoilerSafe = body.optBoolean("spoilerSafe")
            if (body.has("pin")) {
                val pin = if (body.isNull("pin")) "" else body.optString("pin")
                if (pin.isEmpty()) p.pinHash = null
                else if (Regex("^\\d{4}$").matches(pin)) p.pinHash = store.hashPin(pin)
                else throw ApiException(400, "PIN must be 4 digits")
            }
            store.save()
            out(p)
        }
    }

    override suspend fun deleteProfile(id: Long, parentPin: String?) = lock.withLock {
        val p = prof(id)
        requireParentPin(parentPin)
        store.profiles.remove(p)
        store.library.removeAll { it.pid == id }
        store.chat.removeAll { it.pid == id }
        store.save()
    }

    override suspend fun verifyProfilePin(id: Long, pin: String) {
        val p = prof(id)
        if (p.pinHash != null && !store.checkPin(pin, p.pinHash)) throw ApiException(403, "Wrong PIN")
    }

    override suspend fun verifyParentPin(pin: String) = requireParentPin(pin)

    override suspend fun setParentPin(pin: String, current: String?) = lock.withLock {
        if (!Regex("^\\d{4}$").matches(pin)) throw ApiException(400, "PIN must be 4 digits")
        requireParentPin(current)
        store.parentPinHash = store.hashPin(pin)
        store.save()
    }

    // ---------- taste ----------
    private fun lib(pid: Long) = store.library.filter { it.pid == pid }
    private fun banned(l: List<LibRow>) = l.filter { it.watched || it.reaction == -1 }.map { "${it.type}:${it.id}" }.toSet()
    private fun genreIdsFor(p: ProfRow) = p.genres.mapNotNull { g -> GENRE_WORDS.firstOrNull { it.first.containsMatchIn(g) }?.second }

    private suspend fun forYou(p: ProfRow, l: List<LibRow>, lang: String, kidOverride: Boolean? = null): List<Item> {
        val kid = kidOverride ?: p.isKid
        val stamp = l.maxOfOrNull { it.updated } ?: 0L
        val key = "${p.id}|$lang|$stamp|${p.favorites.joinToString(",")}|${p.genres.joinToString(",")}|$kid"
        synchronized(forYouCache) { forYouCache[key]?.let { if (it.exp > System.currentTimeMillis()) return it.v } }

        val exclude = banned(l).toMutableSet()
        l.filter { it.watchlist }.forEach { exclude.add("${it.type}:${it.id}") }

        val seeds = ArrayList<Pair<String, Long>>()
        l.filter { it.reaction == 1 }.take(4).forEach { seeds.add(it.type to it.id) }
        val favs = coroutineScope {
            p.favorites.take(4).map { t -> async { try { tmdb.resolveTitle(t, null, null, lang) } catch (e: ApiException) { if (isKeyError(e)) throw e else null } } }.map { it.await() }
        }
        favs.filterNotNull().forEach { seeds.add(it.item.type to it.item.id) }

        val score = LinkedHashMap<String, Pair<Item, Double>>()
        fun bump(it: Item, w: Double) {
            val k = keyOf(it)
            val cur = score[k]
            score[k] = it to ((cur?.second ?: 0.0) + w + it.rating / 10)
        }
        suspend fun <T> soft(block: suspend () -> List<T>): List<T> = try { block() } catch (e: ApiException) { if (isKeyError(e)) throw e else emptyList() }

        val recLists = coroutineScope { seeds.take(6).map { s -> async { soft { tmdb.recommendations(s.first, s.second, lang, kid, exclude) } } }.map { it.await() } }
        recLists.forEach { list -> list.forEachIndexed { i, r -> bump(r.item, 3 - minOf(i, 10) * 0.15) } }

        val gids = genreIdsFor(p)
        if (gids.isNotEmpty()) {
            val (m, t) = coroutineScope {
                val a = async { soft { tmdb.genreDiscover(gids.take(2), "movie", lang, kid, exclude) } }
                val b = async { soft { tmdb.genreDiscover(gids.take(2), "tv", lang, kid, exclude) } }
                a.await() to b.await()
            }
            (m + t).forEach { bump(it.item, 1.5) }
        }
        var res = score.values.sortedByDescending { it.second }.map { it.first }
        if (res.size < 8) {
            val extra = soft { tmdb.lists("trending", lang, kid, exclude) }.map { it.item }
            res = res + extra.filter { e -> res.none { it.id == e.id && it.type == e.type } }
        }
        res = res.take(20)
        synchronized(forYouCache) {
            forYouCache[key] = Timed(res, System.currentTimeMillis() + 20 * 60_000L)
            if (forYouCache.size > 100) forYouCache.remove(forYouCache.keys.first())
        }
        return res
    }

    // ---------- home ----------
    override suspend fun homeRaw(): JSONObject {
        val p = current()
        val lang = p.lang
        val l = lib(p.id)
        val kid = p.isKid
        val exclude = banned(l)
        val names = ROW_TITLES[lang] ?: ROW_TITLES.getValue("en")
        var keyErr: ApiException? = null
        suspend fun safe(f: suspend () -> List<Item>): List<Item> = try { f() } catch (e: ApiException) { if (isKeyError(e)) keyErr = e; emptyList() }

        val rows: Map<String, List<Item>> = coroutineScope {
            val d = LinkedHashMap<String, Deferred<List<Item>>>()
            d["foryou"] = async { safe { forYou(p, l, lang) } }
            d["fresh"] = async { safe { tmdb.newThisWeek(lang, kid, emptyList()).map { it.item } } }
            d["trending"] = async { safe { tmdb.lists("trending", lang, kid, exclude).map { it.item } } }
            d["arTv"] = async { safe { tmdb.lists("arabic-tv", lang, kid, exclude).map { it.item } } }
            d["arMovie"] = async { safe { tmdb.lists("arabic-movie", lang, kid, exclude).map { it.item } } }
            d["family"] = async { safe { tmdb.lists("family", lang, kid, exclude).map { it.item } } }
            d["topMovie"] = async { safe { tmdb.lists("top-movie", lang, kid, exclude).map { it.item } } }
            d["topTv"] = async { safe { tmdb.lists("top-tv", lang, kid, exclude).map { it.item } } }
            if (!kid) {
                d["onAir"] = async { safe { resolveRefs(tvmaze.onAirTonight(), lang, exclude) } }
                d["premieres"] = async { safe { resolveRefs(tvmaze.premieres(), lang, exclude) } }
                d["anime"] = async { safe { resolveRefs(jikan.airingNow(), lang, exclude) } }
            }
            d.mapValues { it.value.await() }
        }
        keyErr?.let { throw it }
        val mylist = l.filter { it.watchlist && !it.watched }.map(::slimLib)
        val all = rows + ("mylist" to mylist)
        val order = if (kid) kidOrder else if (lang == "ar") arOrder else enOrder
        val arr = JSONArray()
        for (k in order) {
            val items = (all[k] ?: emptyList()).take(20)
            if (items.isEmpty()) continue
            arr.put(JSONObject().put("id", k).put("title", names[k] ?: k).put("items", JSONArray().also { a -> items.forEach { a.put(itemJson(it)) } }))
        }
        return JSONObject().put("rows", arr)
    }

    /** Turns shows found on TVmaze / Jikan into TMDB titles (exact by IMDb id when we have it, else by name). */
    private suspend fun resolveRefs(refs: List<ShowRef>, lang: String, exclude: Set<String>): List<Item> = coroutineScope {
        refs.take(14).map { r ->
            async {
                try {
                    (r.imdb?.let { tmdb.findByImdb(it, lang) } ?: tmdb.resolveTitle(r.name, r.year, "tv", lang))?.item
                } catch (e: ApiException) {
                    if (isKeyError(e)) throw e else null
                }
            }
        }.map { it.await() }
    }.filterNotNull().filter { keyOf(it) !in exclude }.distinctBy { keyOf(it) }.take(14)

    private val kidOrder = listOf("foryou", "mylist", "family", "trending", "topMovie", "topTv", "arTv")
    private val arOrder = listOf("foryou", "mylist", "onAir", "arTv", "arMovie", "premieres", "fresh", "trending", "anime", "topMovie", "topTv", "family")
    private val enOrder = listOf("foryou", "mylist", "onAir", "premieres", "fresh", "trending", "anime", "arTv", "arMovie", "topMovie", "topTv", "family")

    // ---------- briefing ----------
    private suspend fun weather(): Pair<Int, Int>? {
        weatherCache?.let { if (it.exp > System.currentTimeMillis()) return it.v }
        val v: Pair<Int, Int>? = try {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                val req = Request.Builder().url("https://api.open-meteo.com/v1/forecast?latitude=31.95&longitude=35.93&current=temperature_2m,weather_code&timezone=auto").build()
                http.newBuilder().callTimeout(4, TimeUnit.SECONDS).build().newCall(req).execute().use { r ->
                    val c = JSONObject(r.body?.string().orEmpty()).getJSONObject("current")
                    Math.round(c.getDouble("temperature_2m")).toInt() to c.getInt("weather_code")
                }
            }
        } catch (_: Exception) {
            null
        }
        weatherCache = Timed(v, System.currentTimeMillis() + 60 * 60_000L)
        return v
    }

    override suspend fun briefingRaw(tz: String): JSONObject {
        val p = current()
        val lang = p.lang
        val zone = TimeZone.getTimeZone(tz.ifBlank { "Asia/Amman" })
        val cal = Calendar.getInstance(zone)
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        val period = if (hour < 5) "night" else if (hour < 12) "morning" else if (hour < 17) "afternoon" else if (hour < 22) "evening" else "night"
        val dayKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = zone }.format(Date())
        val l = lib(p.id)
        val stamp = l.maxOfOrNull { it.updated } ?: 0L
        val key = "${p.id}|$lang|$dayKey|$period|$stamp"
        synchronized(briefCache) { briefCache[key]?.let { if (it.exp > System.currentTimeMillis()) return it.v } }

        val kid = p.isKid
        val bannedSet = banned(l)
        val providerIds = try { tmdb.providerIdsFor(p.services) } catch (e: ApiException) { if (isKeyError(e)) throw e else emptyList() }
        val (w, fresh, picks) = coroutineScope {
            val a = async { weather() }
            val b = async { try { tmdb.newThisWeek(lang, kid, providerIds).map { it.item } } catch (e: ApiException) { if (isKeyError(e)) throw e else emptyList() } }
            val c = async { try { forYou(p, l, lang) } catch (e: ApiException) { if (isKeyError(e)) throw e else emptyList() } }
            Triple(a.await(), b.await(), c.await())
        }
        val newItems = fresh.filter { keyOf(it) !in bannedSet }.take(8)
        val pick = picks.firstOrNull() ?: try { tmdb.lists("trending", lang, kid, emptySet()).firstOrNull()?.item } catch (_: ApiException) { null }
        val watchlist = l.filter { it.watchlist && !it.watched }.take(6).map(::slimLib)

        val greeting = "${GREET.getValue(lang).getValue(period)}, ${p.name}"
        val date = SimpleDateFormat("EEEE d MMMM", if (lang == "ar") Locale("ar", "JO") else Locale.UK).apply { timeZone = zone }.format(Date())
        val wmo = if (lang == "ar") WMO_AR else WMO_EN
        val summary = w?.let { wmo[it.second] ?: "" } ?: ""
        val weatherText = if (w != null) "${w.first}°C, $summary".trim().trimEnd(',') else ""

        var text = ""
        if (ai.enabled()) {
            text = try {
                ai.text(
                    "You are Dexter, a warm TV companion. Write a spoken daily briefing in ${if (lang == "ar") "Arabic" else "English"}: 2 to 4 short sentences, no markdown, no emojis, no lists. Mention weather only if it shapes the viewing mood. Mention the pick of the day with one non-spoiler reason. Mention the watchlist or something new only if present. Do not greet by name (the app shows the greeting)." + if (kid) " Kids profile: playful, simple words." else "",
                    "Time of day: $period. Date: $date. Weather: ${weatherText.ifBlank { "unknown" }}. Pick: ${pick?.let { "${it.title} (${it.year}) - ${it.overview.take(160)}" } ?: "none"}. New this week: ${newItems.take(3).joinToString("; ") { it.title }.ifBlank { "none" }}. Watchlist: ${watchlist.take(3).joinToString("; ") { it.title }.ifBlank { "empty" }}. Favorites: ${p.favorites.joinToString("; ").ifBlank { "unknown" }}.",
                    260,
                )
            } catch (_: ApiException) {
                ""
            }
        }
        if (text.isBlank()) {
            val parts = ArrayList<String>()
            if (lang == "ar") {
                if (weatherText.isNotBlank()) parts.add("الطقس اليوم $weatherText.")
                if (pick != null) parts.add("اقتراحي لك الليلة: ${pick.title}.")
                if (newItems.isNotEmpty()) parts.add("وصل هذا الأسبوع ${newItems[0].title}.")
                if (watchlist.isNotEmpty()) parts.add("ما زال ${watchlist[0].title} ينتظرك في قائمتك.")
            } else {
                if (weatherText.isNotBlank()) parts.add("It's $weatherText today.")
                if (pick != null) parts.add("My pick for you: ${pick.title}.")
                if (newItems.isNotEmpty()) parts.add("New this week: ${newItems[0].title}.")
                if (watchlist.isNotEmpty()) parts.add("${watchlist[0].title} is still waiting on your list.")
            }
            text = parts.joinToString(" ")
        }

        val v = JSONObject().put("greeting", greeting).put("date", date).put("period", period).put("text", text).put("lang", lang)
            .put("weather", if (w != null) JSONObject().put("temp", w.first).put("summary", summary) else JSONObject.NULL)
            .put("pick", pick?.let { itemJson(it) } ?: JSONObject.NULL)
            .put("newThisWeek", JSONArray().also { a -> newItems.forEach { a.put(itemJson(it)) } })
            .put("watchlist", JSONArray().also { a -> watchlist.forEach { a.put(itemJson(it)) } })
        synchronized(briefCache) {
            briefCache[key] = Timed(v, System.currentTimeMillis() + 3 * 3600_000L)
            if (briefCache.size > 50) briefCache.remove(briefCache.keys.first())
        }
        return v
    }

    // ---------- search & details ----------
    override suspend fun search(q: String): List<Item> {
        val p = current()
        val text = q.trim().take(80)
        if (text.length < 2) return emptyList()
        return tmdb.search(text, p.lang, p.isKid).map { it.item }
    }

    override suspend fun title(type: String, id: Long): Detail {
        val p = current()
        val t = if (type == "tv") "tv" else "movie"
        val (d0, genreIds, extra) = coroutineScope {
            val next = if (t == "tv") async { nextEpisodeText(id, p.lang) } else null
            val det = tmdb.details(t, id, p.lang)
            Triple(det.first, det.second, next?.await().orEmpty())
        }
        val d = d0.copy(extra = extra)
        if (p.isKid && genreIds.none { it in KID_GENRES }) throw ApiException(403, "Not available on a kids profile")
        val st = store.library.firstOrNull { it.pid == p.id && it.id == id && it.type == t }
        return d.copy(state = if (st == null) LibState() else LibState(st.watchlist, st.watched, st.reaction))
    }

    /** "Next episode S2 E5 · 2026-11-12" from TVmaze, or empty. */
    private suspend fun nextEpisodeText(id: Long, lang: String): String {
        return try {
            val imdb = tmdb.imdbId("tv", id) ?: return ""
            val e = tvmaze.nextEpisode(imdb) ?: return ""
            if (lang == "ar") "الحلقة القادمة: الموسم ${e.season} الحلقة ${e.number} · ${e.airdate}" else "Next episode: S${e.season} E${e.number} · ${e.airdate}"
        } catch (ex: ApiException) {
            ""
        }
    }

    override suspend fun why(type: String, id: Long): String {
        val p = current()
        val (d, _) = tmdb.details(if (type == "tv") "tv" else "movie", id, p.lang)
        val l = lib(p.id)
        if (!ai.enabled()) {
            return if (p.lang == "ar") "أقترح ${d.item.title} لأن تقييمه ${d.item.rating} ويناسب ذوقك." else "I suggest ${d.item.title} because it is rated ${d.item.rating} and fits your taste."
        }
        return try {
            ai.text(
                "You are Dexter, a TV companion. In ${if (p.lang == "ar") "Arabic" else "English"}, in 1-2 spoken sentences with no markdown, explain why this title suits the viewer. No spoilers.",
                "Viewer: ${p.name}. Favorites: ${p.favorites.joinToString("; ").ifBlank { "n/a" }}. Genres: ${p.genres.joinToString(", ").ifBlank { "n/a" }}. Liked: ${l.filter { it.reaction == 1 }.take(10).joinToString("; ") { it.title }.ifBlank { "n/a" }}. Title: ${d.item.title} (${d.item.year}). Genres: ${d.genres.joinToString(", ")}. Overview: ${d.item.overview}",
                200,
            )
        } catch (e: ApiException) {
            if (e.message == ERR_BAD_CLAUDE) throw e
            "${d.item.title}: ${d.item.overview.take(120)}"
        }
    }

    // ---------- library ----------
    override suspend fun library(filter: String): List<Item> {
        val p = current()
        val rows = lib(p.id).sortedByDescending { it.updated }
        val f = when (filter) {
            "watchlist" -> rows.filter { it.watchlist && !it.watched }
            "watched" -> rows.filter { it.watched }
            "liked" -> rows.filter { it.reaction == 1 }
            else -> rows
        }
        return f.map(::slimLib)
    }

    override suspend fun setLibrary(item: Item, watchlist: Boolean?, watched: Boolean?, reaction: Int?): LibState = lock.withLock {
        val p = current()
        val cur = store.library.firstOrNull { it.pid == p.id && it.id == item.id && it.type == item.type }
        val w = watched ?: cur?.watched ?: false
        var wl = watchlist ?: cur?.watchlist ?: false
        if (w && watchlist == null) wl = false
        val r = reaction?.coerceIn(-1, 1) ?: cur?.reaction ?: 0
        if (cur != null) store.library.remove(cur)
        if (!w && !wl && r == 0) {
            store.save()
            return@withLock LibState()
        }
        store.library.add(LibRow(p.id, item.id, item.type, item.title.take(200), item.poster ?: cur?.poster, item.year.ifBlank { cur?.year ?: "" }, wl, w, r, System.currentTimeMillis()))
        store.save()
        LibState(wl, w, r)
    }

    // ---------- chat ----------
    private fun systemPrompt(p: ProfRow, l: List<LibRow>, nowText: String): String {
        fun names(f: (LibRow) -> Boolean) = l.filter(f).take(25).joinToString("; ") { it.title }
        val watched = names { it.watched }
        val liked = names { it.reaction == 1 }
        val disliked = names { it.reaction == -1 }
        val list = names { it.watchlist && !it.watched }
        return """You are Dexter, a friendly, witty movie-and-series companion living on a family's Google TV. You talk with ${p.name}.

Rules:
- Reply in the language the viewer used (Arabic or English; if they mix, follow their last message). Arabic replies use natural spoken Modern/light Levantine-friendly Arabic, never stiff.
- Keep replies short and spoken-friendly: 1 to 3 sentences, no markdown, no emojis, no lists.
- Suggest up to 12 titles at a time (about 5 for a casual ask, more when the viewer wants many or a whole category), always through the titles field using the official English/original title, type and year. Never invent titles; only suggest real films and series.
- Never suggest anything already watched or disliked. Prefer variety, and include Arabic-language options when it fits the request.
- Spoiler-safe is ${if (p.spoilerSafe) "ON: never reveal plot twists, endings or deaths; describe premise and tone only." else "OFF: spoilers allowed only if the viewer explicitly asks."}
- ${if (p.isKid) "This is a KIDS profile: only family-friendly, age-appropriate titles. Decline anything mature, kindly." else "Adult profile: respect maturity, but stay tasteful."}
- Use the viewer's streaming services when you can: ${p.services.joinToString(", ").ifBlank { "unknown" }}. Region: $REGION.
- Unless the viewer says only movies or only series, mix both: movies AND series, with at least a third of the titles being series (type tv).
- If they say how they feel or how much time they have, match mood and runtime.
- When they reveal a lasting taste ("I hate horror"), add it to learn.
- You cannot play content yourself; the app shows posters and the viewer opens them. Do not claim to play things.
- Current time: $nowText.

What you know about ${p.name}:
- Favorites: ${p.favorites.joinToString("; ").ifBlank { "not shared yet" }}
- Favorite genres: ${p.genres.joinToString(", ").ifBlank { "unknown" }}
- Notes: ${p.notes.joinToString("; ").ifBlank { "none" }}
- Recently watched: ${watched.ifBlank { "nothing logged" }}
- Liked: ${liked.ifBlank { "none" }}
- Disliked: ${disliked.ifBlank { "none" }}
- On their watchlist: ${list.ifBlank { "empty" }}"""
    }

    private class Turn(val reply: String, val lang: String, val titles: List<Raw>, val learn: List<String>, val openApp: String?)

    private val FILLER = Regex(
        "(اقترح|اقتراح|اقتراحات|رشح|ترشيح|لي|عطني|اعطني|أعطني|بدي|أريد|اريد|ابغى|ابي|شي|شيء|فيلم|أفلام|افلام|مسلسل|مسلسلات|جديد|حلو|جميل|زي|مثل|من فضلك|لو سمحت|suggest|recommend|recommendation|recommendations|please|me|a|an|some|movie|movies|film|films|series|show|shows|something|good|new|nice|i|want|to|watch|give|can|you|could|for|the|any|tonight)",
        RegexOption.IGNORE_CASE,
    )

    private suspend fun fallbackTurn(p: ProfRow, l: List<LibRow>, message: String): Turn {
        val lang = detectLang(message, p.lang)
        val t = FALLBACK.getValue(lang)
        val kid = p.isKid
        val wantsTv = Regex("series|show|مسلسل|مسلسلات", RegexOption.IGNORE_CASE).containsMatchIn(message)
        val wantsMovie = Regex("movie|film|فيلم|أفلام|افلام", RegexOption.IGNORE_CASE).containsMatchIn(message)
        val type = if (wantsTv) "tv" else "movie"
        val exclude = banned(l)
        if (Regex("^\\s*(hi|hello|hey|مرحبا|أهلا|اهلا|هلا)", RegexOption.IGNORE_CASE).containsMatchIn(message)) return Turn(t.getValue("hi"), lang, emptyList(), emptyList(), null)
        val g = GENRE_WORDS.firstOrNull { it.first.containsMatchIn(message) }
        if (g != null) {
            // Movies AND series, unless the viewer asked for only one of them.
            val onlyTv = wantsTv && !wantsMovie
            val onlyMovie = wantsMovie && !wantsTv
            val movies = if (onlyTv) emptyList() else tmdb.genreDiscover(listOf(g.second), "movie", lang, kid, exclude)
            val tvIds = tvGenres(listOf(g.second))
            val shows = if (onlyMovie || tvIds.isEmpty()) emptyList() else tmdb.genreDiscover(tvIds, "tv", lang, kid, exclude)
            val mixed = interleave(movies, shows).take(30)
            if (mixed.isNotEmpty()) return Turn(t.getValue("genre"), lang, mixed, emptyList(), null)
        }
        if (Regex("surprise|random|فاجئني|اي شي|أي شيء|any", RegexOption.IGNORE_CASE).containsMatchIn(message)) {
            return Turn(t.getValue("trending"), lang, tmdb.lists("trending", lang, kid, exclude).take(20), emptyList(), null)
        }
        // What is left after removing request words like "suggest me a movie" is the actual title the viewer typed, if any.
        val query = message.replace(Regex("[\\p{Punct}؟،]"), " ").split(Regex("\\s+")).filter { it.isNotBlank() && !FILLER.matches(it) }.joinToString(" ").trim()
        suspend fun personal(): List<Raw> {
            val picks = forYou(p, l, lang).filter { (!wantsTv || it.type == "tv") && (!wantsMovie || wantsTv || it.type == "movie") }
            val pool = if (picks.isEmpty()) forYou(p, l, lang) else picks
            return pool.take(20).shuffled().take(12).map { Raw(it, emptyList(), false) }
        }
        if (query.length >= 2) {
            val found = tmdb.search(query, lang, kid)
            if (found.isNotEmpty()) return Turn(t.getValue("found"), lang, found.take(12), emptyList(), null)
        }
        val mine = personal()
        if (mine.isNotEmpty()) {
            val msg = if (lang == "ar") "هذه اقتراحات مختارة حسب ذوقك." else "Here are picks chosen for your taste."
            return Turn(msg, lang, mine, emptyList(), null)
        }
        return Turn(t.getValue("none"), lang, emptyList(), emptyList(), null)
    }

    override suspend fun chat(message: String, tz: String): ChatReply {
        val p = current()
        val msg = message.trim().take(600)
        if (msg.isEmpty()) throw ApiException(400, "Say something first")
        val l = lib(p.id)
        val wish = typeWish(msg)
        val mine = store.chat.filter { it.pid == p.id }
        val history = mine.takeLast(12)
        store.chat.add(ChatRow(store.newId(), p.id, "user", msg, null, System.currentTimeMillis()))

        val nowText = try {
            SimpleDateFormat("EEEE d MMMM yyyy, HH:mm", Locale.UK).apply { timeZone = TimeZone.getTimeZone(tz.ifBlank { "Asia/Amman" }) }.format(Date())
        } catch (_: Exception) {
            Date().toString()
        }

        var turn: Turn? = null
        if (ai.enabled()) {
            val msgs = JSONArray()
            for (h in history.map { it.role to it.text } + ("user" to msg)) {
                val role = if (h.first == "assistant") "assistant" else "user"
                val last = if (msgs.length() > 0) msgs.getJSONObject(msgs.length() - 1) else null
                if (last != null && last.getString("role") == role) last.put("content", last.getString("content") + "\n" + h.second)
                else msgs.put(JSONObject().put("role", role).put("content", h.second))
            }
            while (msgs.length() > 0 && msgs.getJSONObject(0).getString("role") != "user") msgs.remove(0)
            val input = try {
                ai.reply(systemPrompt(p, l, nowText) + wishRule(wish), msgs)
            } catch (e: ApiException) {
                if (e.message == ERR_BAD_CLAUDE) { store.chat.removeAt(store.chat.size - 1); throw e }
                null
            }
            if (input != null && input.optString("reply").isNotBlank()) {
                val lang = input.str("lang").takeIf { it == "ar" || it == "en" } ?: detectLang(input.optString("reply"), p.lang)
                val titles = resolveTitles(input, p, l, lang).filter { wish == null || it.item.type == wish }
                turn = Turn(input.optString("reply"), lang, titles, input.optJSONArray("learn").strs().take(3), input.strOrNullSafe("open_app"))
            }
        }
        val t = turn ?: try {
            fallbackTurn(p, l, msg)
        } catch (e: ApiException) {
            store.chat.removeAt(store.chat.size - 1)
            throw e
        }

        val items = t.titles.map { it.item }
        store.chat.add(
            ChatRow(
                store.newId(), p.id, "assistant", t.reply,
                if (items.isEmpty()) null else JSONArray().also { a -> items.forEach { a.put(itemJson(it)) } }.toString(),
                System.currentTimeMillis(),
            ),
        )
        store.trimChat(p.id)
        if (t.learn.isNotEmpty()) p.notes = cleanList(p.notes + t.learn, 30, 120)
        store.save()
        return ChatReply(t.reply, items, t.openApp)
    }

    /** Looks up the titles the AI suggested on TMDB, dropping watched/disliked ones and anything unsafe for kids. */
    private suspend fun resolveTitles(input: JSONObject, p: ProfRow, l: List<LibRow>, lang: String, limit: Int = 12): List<Raw> {
        val bannedSet = banned(l)
        val seen = HashSet<String>()
        return coroutineScope {
            input.optJSONArray("titles").objs().take(limit).map { t ->
                async {
                    try {
                        val yr = if (t.has("year") && !t.isNull("year")) t.optInt("year").takeIf { it > 0 } else null
                        val ty = t.str("type").takeIf { it == "movie" || it == "tv" }
                        tmdb.resolveTitle(t.str("title"), yr, ty, lang)?.let { r -> Raw(r.item.copy(why = t.str("why").ifBlank { null }), r.genres, r.adult) }
                    } catch (e: ApiException) {
                        if (isKeyError(e)) throw e else null
                    }
                }
            }.map { it.await() }
        }.filterNotNull().filter { r ->
            val k = keyOf(r.item)
            if (!seen.add(k) || k in bannedSet) false else !(p.isKid && r.genres.none { it in KID_GENRES })
        }
    }

    private val MOOD_RULES = """

MOOD MODE: The viewer chose a mood or described a feeling instead of a genre. Read it precisely: the emotional tone, themes, pacing, plot structure and the kind of ending they want. Return 15 to 20 real titles that match it very closely (include both movies and series, at least a third of them series with type tv, unless they say which one they want). Prefer precision over popularity, skip the obvious generic picks, and include at most one Arabic-language title only if it truly fits. In each why, say in one short sentence how it matches the mood, without spoilers. The reply is one warm sentence. Do not ask questions."""

    /**
     * Mood or category picks. Returns the AI's precise picks first, then EVERY title of the matching genres
     * (movies and series, several pages each) so the viewer can browse the whole category. Not written to chat history.
     */
    override suspend fun mood(text: String, tz: String, genres: List<Int>, all: Boolean): ChatReply {
        val p = current()
        val msg = text.trim().take(400)
        if (msg.isEmpty()) throw ApiException(400, "Say something first")
        val l = lib(p.id)
        val lang = detectLang(msg, p.lang)
        val wish = typeWish(msg)
        val gids = genres.ifEmpty { GENRE_WORDS.filter { it.first.containsMatchIn(msg) }.map { it.second }.distinct().take(3) }
        val exclude = banned(l)

        var reply: String? = null
        var picks: List<Raw> = emptyList()
        if (ai.enabled()) {
            val nowText = try {
                SimpleDateFormat("EEEE d MMMM yyyy, HH:mm", Locale.UK).apply { timeZone = TimeZone.getTimeZone(tz.ifBlank { "Asia/Amman" }) }.format(Date())
            } catch (_: Exception) {
                Date().toString()
            }
            val msgs = JSONArray().put(JSONObject().put("role", "user").put("content", msg))
            val input = try {
                ai.reply(systemPrompt(p, l, nowText) + MOOD_RULES + wishRule(wish), msgs)
            } catch (e: ApiException) {
                if (e.message == ERR_BAD_CLAUDE) throw e
                null
            }
            if (input != null && input.optString("reply").isNotBlank()) {
                reply = input.optString("reply")
                val aiLang = input.str("lang").takeIf { it == "ar" || it == "en" } ?: detectLang(reply, p.lang)
                picks = resolveTitles(input, p, l, aiLang, 20).filter { wish == null || it.item.type == wish }
            }
        }

        val found: List<Raw> = if (gids.isEmpty()) emptyList() else coroutineScope {
            val m = async { if (wish == "tv") emptyList() else tmdb.genrePages(gids, "movie", lang, p.isKid, exclude, 3, !all) }
            val tvIds = tvGenres(gids)
            val t = async { if (tvIds.isEmpty() || wish == "movie") emptyList() else tmdb.genrePages(tvIds, "tv", lang, p.isKid, exclude, 3, !all) }
            m.await() + t.await()
        }
        val seen = HashSet<String>()
        val merged = (picks + found).filter { seen.add(keyOf(it.item)) }.map { it.item }
        if (merged.isNotEmpty()) {
            val say = reply ?: if (lang == "ar") "هذه كل الأفلام والمسلسلات المناسبة لمزاجك." else "Here are all the movies and series that fit your mood."
            return ChatReply(say, merged, null)
        }
        val t = fallbackTurn(p, l, msg)
        return ChatReply(t.reply, t.titles.map { it.item }, null)
    }

    private fun JSONObject.strOrNullSafe(k: String): String? = if (isNull(k)) null else optString(k).ifBlank { null }

    override suspend fun chatLog(q: String?, limit: Int): List<ChatMsg> {
        val p = current()
        var rows = store.chat.filter { it.pid == p.id }
        if (!q.isNullOrBlank()) rows = rows.filter { it.text.contains(q.trim(), ignoreCase = true) }
        return rows.takeLast(minOf(limit, 100)).map {
            ChatMsg(it.id, it.role, it.text, if (it.titles == null) emptyList() else parseItems(try { JSONArray(it.titles) } catch (_: Exception) { null }))
        }
    }

    override suspend fun clearLog() = lock.withLock {
        val p = current()
        store.chat.removeAll { it.pid == p.id }
        store.save()
    }

    // ---------- family vote ----------
    override suspend fun vote(ids: List<Long>): Pair<List<Item>, Boolean> {
        val ps = ids.distinct().take(8).mapNotNull { id -> store.profiles.firstOrNull { it.id == id } }
        if (ps.isEmpty()) throw ApiException(400, "Pick at least one person")
        val lang = ps[0].lang
        val anyKid = ps.any { it.isKid }
        class Entry(val item: Item, val who: MutableList<String>)
        val counts = LinkedHashMap<String, Entry>()
        val perProfile = coroutineScope {
            ps.map { p ->
                async {
                    val l = lib(p.id)
                    val picks = try { forYou(p, l, lang, anyKid || p.isKid) } catch (e: ApiException) { if (isKeyError(e)) throw e else emptyList() }
                    // Watchlists carry no genre data, so when a child is voting only the child's own list is trusted.
                    val wl = l.filter { it.watchlist && !it.watched && (!anyKid || p.isKid) }.map(::slimLib)
                    p to (wl + picks.take(15))
                }
            }.map { it.await() }
        }
        for ((p, items) in perProfile) {
            val own = HashSet<String>()
            for (it in items) {
                val k = keyOf(it)
                if (!own.add(k)) continue
                counts.getOrPut(k) { Entry(it, ArrayList()) }.who.add(p.name)
            }
        }
        val seen = HashSet<String>()
        ps.forEach { p -> lib(p.id).filter { it.watched }.forEach { seen.add("${it.type}:${it.id}") } }
        val out = counts.entries.filter { it.key !in seen }
            .map { it.value.item.copy(lovedBy = it.value.who.toList()) to it.value.who.size }
            .sortedWith(compareByDescending<Pair<Item, Int>> { it.second }.thenByDescending { it.first.rating })
            .take(10).map { it.first }
        return out to anyKid
    }

    override suspend fun inbox(): List<Item> = emptyList()
}

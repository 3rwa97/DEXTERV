package com.dexter.tv.local

import com.dexter.tv.data.ApiException
import org.json.JSONArray
import org.json.JSONObject

/**
 * The one "brain" the rest of the app talks to. Prefers Gemini when its key exists;
 * if Gemini fails and a Claude key exists, Claude takes over. Either alone works too.
 */
class Ai(private val claude: ClaudeClient, private val gemini: GeminiClient) {
    fun enabled() = gemini.enabled() || claude.enabled()

    private suspend fun <T> pick(g: suspend () -> T, c: suspend () -> T): T {
        if (gemini.enabled()) {
            try {
                return g()
            } catch (e: ApiException) {
                if (!claude.enabled()) throw e
            }
        }
        return c()
    }

    suspend fun reply(system: String, messages: JSONArray): JSONObject? =
        pick({ gemini.reply(system, messages) }, { claude.reply(system, messages) })

    suspend fun text(system: String, user: String, maxTokens: Int): String =
        pick({ gemini.text(system, user, maxTokens) }, { claude.text(system, user, maxTokens) })
}

package com.dexter.tv.data

import android.content.Context
import com.dexter.tv.BuildConfig
import java.io.File
import java.util.Locale

/** Small settings store + a tiny disk cache so screens can paint instantly while fresh data loads. */
class Prefs(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("dexter", Context.MODE_PRIVATE)

    var server: String
        get() = sp.getString("server", null)?.takeIf { it.isNotBlank() } ?: BuildConfig.DEXTER_SERVER
        set(v) { sp.edit().putString("server", v.trim().trimEnd('/')).apply() }

    var token: String?
        get() = sp.getString("token", null)
        set(v) { sp.edit().putString("token", v).apply() }

    var profileId: Long
        get() = sp.getLong("profile", 0L)
        set(v) { sp.edit().putLong("profile", v).apply() }

    /** UI language used before a profile is chosen (login screen). */
    var uiLang: String
        get() = sp.getString("uiLang", null) ?: if (Locale.getDefault().language == "ar") "ar" else "en"
        set(v) { sp.edit().putString("uiLang", v).apply() }

    var voiceOn: Boolean
        get() = sp.getBoolean("voiceOn", true)
        set(v) { sp.edit().putBoolean("voiceOn", v).apply() }

    var autoBrief: Boolean
        get() = sp.getBoolean("autoBrief", false)
        set(v) { sp.edit().putBoolean("autoBrief", v).apply() }

    /** applicationId of the user's PrimeVision IPTV app. */
    var primePkg: String
        get() = sp.getString("primePkg", null) ?: "com.example.myiptv"
        set(v) { sp.edit().putString("primePkg", v.trim()).apply() }

    /** Optional deep link template, e.g. primevision://search?q={query} */
    var primeLink: String
        get() = sp.getString("primeLink", "") ?: ""
        set(v) { sp.edit().putString("primeLink", v.trim()).apply() }

    /** TV-only mode: no server or account; everything runs on this TV. */
    var localMode: Boolean
        get() = sp.getBoolean("localMode", false)
        set(v) { sp.edit().putBoolean("localMode", v).apply() }

    /** Free key from themoviedb.org (Settings > API). Stored only on this TV. */
    var tmdbKey: String
        get() = sp.getString("tmdbKey", null)?.takeIf { it.isNotBlank() } ?: BuildConfig.TMDB_KEY
        set(v) { sp.edit().putString("tmdbKey", v.trim()).apply() }

    /** Optional Claude key from console.anthropic.com. Stored only on this TV. */
    var claudeKey: String
        get() = sp.getString("claudeKey", null)?.takeIf { it.isNotBlank() } ?: BuildConfig.CLAUDE_KEY
        set(v) { sp.edit().putString("claudeKey", v.trim()).apply() }

    /** Gemini key from Google AI Studio (aistudio.google.com). Preferred brain when present. */
    var geminiKey: String
        get() = sp.getString("geminiKey", null)?.takeIf { it.isNotBlank() } ?: BuildConfig.GEMINI_KEY
        set(v) { sp.edit().putString("geminiKey", v.trim()).apply() }

    var deviceName: String
        get() = sp.getString("deviceName", null) ?: "TV ${android.os.Build.MODEL}"
        set(v) { sp.edit().putString("deviceName", v).apply() }

    private fun cacheFile(key: String) = File(ctx.cacheDir, "c_" + key.replace(Regex("[^A-Za-z0-9_]"), "_") + ".json")

    fun cacheGet(key: String): String? = try { cacheFile(key).takeIf { it.exists() }?.readText() } catch (_: Exception) { null }
    fun cachePut(key: String, value: String) { try { cacheFile(key).writeText(value) } catch (_: Exception) { } }
    fun cacheClear() { ctx.cacheDir.listFiles { f -> f.name.startsWith("c_") }?.forEach { it.delete() } }
}

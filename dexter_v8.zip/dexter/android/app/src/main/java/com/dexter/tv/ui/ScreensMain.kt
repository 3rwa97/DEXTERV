package com.dexter.tv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.dexter.tv.AppViewModel
import com.dexter.tv.Screen
import com.dexter.tv.data.ChatMsg
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(vm: AppViewModel, active: Boolean) {
    LaunchedEffect(vm.homeDirty, active) { if (vm.homeDirty && active) vm.loadHome() }
    var restoreKey by remember { mutableStateOf<String?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    // Coming back from a detail page: put focus back on the poster the viewer left.
    LaunchedEffect(active) { if (active && restoreKey != null) tick++ }

    Column(Modifier.fillMaxSize().padding(horizontal = SafeH, vertical = SafeV)) {
        TopBar(vm, Screen.Home)
        Spacer(Modifier.height(6.dp))
        val err = vm.homeError
        when {
            vm.rows.isEmpty() && vm.homeLoading -> Centered { T(tr("loading"), 16, C.Muted) }
            vm.rows.isEmpty() && err != null -> Centered {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    T(err, 15, C.Muted)
                    DButton(tr("retry"), { vm.loadHome() }, primary = true)
                }
            }
            else -> LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item(key = "briefing", contentType = "briefing") { BriefingCard(vm, restoreKey == null) }
                item(key = "moods", contentType = "moods") { MoodStrip(vm) }
                items(vm.rows, key = { it.id }, contentType = { "row" }) { row ->
                    PosterRow(row.title, row.items, row.id, restoreKey, tick, { restoreKey = it }, { vm.go(Screen.Detail(it.type, it.id)) })
                }
            }
        }
    }
}

@Composable
fun BriefingCard(vm: AppViewModel, focusOnStart: Boolean) {
    val b = vm.briefing
    val speaking by vm.voice.speaking.collectAsState()
    val talkFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        if (focusOnStart) { delay(250); try { talkFocus.requestFocus() } catch (_: Exception) { } }
    }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF3A1D0C), C.Panel)))
            .border(1.dp, C.Line, RoundedCornerShape(16.dp)).padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            T(tr("brief_title").uppercase(), 11, C.AccentHi, FontWeight.Bold, spacing = 1.5f)
            if (b == null) {
                T(if (vm.briefingLoading) tr("loading") else "", 14, C.Muted)
            } else {
                T(b.greeting, 22, weight = FontWeight.ExtraBold, maxLines = 1)
                T(listOf(b.date, b.weather).filter { it.isNotBlank() }.joinToString("   ·   "), 12, C.Muted, maxLines = 1)
                T(b.text, 13, Color(0xFFE2E2EC), maxLines = 2)
            }
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DIconButton(if (speaking) tr("stop") else tr("play_brief"), { vm.playBriefing() }, primary = true) { if (speaking) StopIcon(14.dp, it) else PlayIcon(14.dp, it) }
                DIconButton(tr("talk"), { vm.tab(Screen.Chat); vm.startMic() }, Modifier.focusRequester(talkFocus)) { MicIcon(16.dp, it) }
            }
        }
        val pick = b?.pick
        if (pick != null) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                T(tr("pick_today"), 10, C.Muted, FontWeight.SemiBold, maxLines = 1)
                Spacer(Modifier.height(3.dp))
                PosterCard(pick, { vm.go(Screen.Detail(pick.type, pick.id)) }, width = 88.dp)
            }
        }
    }
}

@Composable
private fun Bubble(vm: AppViewModel, m: ChatMsg) {
    val mine = m.role == "user"
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
        Box(
            Modifier.widthIn(max = 560.dp).clip(RoundedCornerShape(16.dp))
                .background(if (mine) C.AccentDeep else C.Panel).padding(horizontal = 14.dp, vertical = 10.dp),
        ) { T(m.text, 15) }
        if (m.titles.isNotEmpty()) {
            Spacer(Modifier.height(4.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp)) {
                items(m.titles, key = { "${it.type}:${it.id}" }) { t ->
                    PosterCard(t, { vm.go(Screen.Detail(t.type, t.id)) }, width = 92.dp, caption = t.why)
                }
            }
        }
    }
}

@Composable
fun ChatScreen(vm: AppViewModel) {
    LaunchedEffect(Unit) { vm.loadChat() }
    val listState = rememberLazyListState()
    val count = vm.chat.size + if (vm.chatBusy) 1 else 0
    LaunchedEffect(count) { if (count > 0) listState.animateScrollToItem(count - 1) }
    val listening by vm.voice.listening.collectAsState()
    val partial by vm.voice.partial.collectAsState()
    var typing by remember { mutableStateOf(false) }
    val micFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { delay(200); try { micFocus.requestFocus() } catch (_: Exception) { } }
    val chips = listOf(tr("chip1"), tr("chip2"), tr("chip3"), tr("chip4"), tr("chip5"))

    Column(Modifier.fillMaxSize().padding(horizontal = SafeH, vertical = SafeV)) {
        TopBar(vm, Screen.Chat, down = micFocus)
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            state = listState,
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 8.dp),
        ) {
            items(vm.chat, key = { it.id }) { m -> Bubble(vm, m) }
            if (vm.chatBusy) item(key = "busy") { T(tr("thinking"), 13, C.Muted) }
        }
        if (vm.chat.size <= 2) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 4.dp)) {
                items(chips) { c -> DChip(c, false, { vm.sendChat(c) }) }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            MicOrbButton(listening, { vm.toggleMic() }, Modifier.focusRequester(micFocus), size = 56.dp)
            Column(Modifier.weight(1f)) {
                T(if (listening) partial.ifBlank { tr("hint_listen") } else tr("hint_press"), 13, if (listening) C.Text else C.Muted, maxLines = 2)
            }
            DIconButton(tr("type"), { typing = true }) { KeyboardIcon(18.dp, it) }
            DIconButton(tr("log"), { vm.go(Screen.Log) }) { ClockIcon(16.dp, it) }
            DChip(when (vm.voiceLangMode) { "auto" -> tr("lang_auto"); "ar" -> "عربي"; else -> "EN" }, false, { vm.cycleVoiceLang() })
        }
    }
    if (typing) TextInputDialog(tr("tab_chat"), "", onDone = { typing = false; vm.sendChat(it) }, onCancel = { typing = false })
}

@Composable
fun LogScreen(vm: AppViewModel) {
    var searching by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.searchLog("") }
    Column(Modifier.fillMaxSize().background(C.Bg).padding(horizontal = SafeH, vertical = SafeV)) {
        Row(Modifier.fillMaxWidth().height(44.dp), verticalAlignment = Alignment.CenterVertically) {
            T(tr("log"), 22, weight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
            DIconButton(tr("search_log"), { searching = true }) { SearchIcon(15.dp, it) }
            Spacer(Modifier.size(8.dp))
            DButton(tr("clear_log"), { vm.clearLog() })
            Spacer(Modifier.size(8.dp))
            DButton(tr("back_chat"), { vm.back() }, primary = true)
        }
        if (vm.logQuery.isNotBlank()) T("“${vm.logQuery}”", 12, C.Muted, modifier = Modifier.padding(vertical = 4.dp))
        Spacer(Modifier.height(6.dp))
        if (vm.logItems.isEmpty()) {
            Centered { T(tr("empty_log"), 14, C.Muted) }
        } else {
            LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(vm.logItems, key = { it.id }) { m ->
                    // Focusable so the remote can scroll through the history.
                    Focusable({ }, Modifier.fillMaxWidth(), RoundedCornerShape(10.dp), C.Panel, C.Panel2, scale = 1.01f) {
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            T(if (m.role == "user") "👤" else "▶", 14, if (m.role == "user") C.Muted else C.Accent)
                            T(m.text, 14, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
    if (searching) TextInputDialog(tr("search_log"), vm.logQuery, onDone = { searching = false; vm.searchLog(it.trim()) }, onCancel = { searching = false })
}

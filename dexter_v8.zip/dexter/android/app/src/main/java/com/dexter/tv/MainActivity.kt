package com.dexter.tv

import android.Manifest
import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.dexter.tv.ui.C
import com.dexter.tv.ui.ChatScreen
import com.dexter.tv.ui.BootScreen
import com.dexter.tv.ui.DetailScreen
import com.dexter.tv.ui.HomeScreen
import com.dexter.tv.ui.LocalLang
import com.dexter.tv.ui.LoginScreen
import com.dexter.tv.ui.LogScreen
import com.dexter.tv.ui.MoodScreen
import com.dexter.tv.ui.MyListScreen
import com.dexter.tv.ui.PinDialog
import com.dexter.tv.ui.ProfileEditScreen
import com.dexter.tv.ui.ProfilesScreen
import com.dexter.tv.ui.ScreenFit
import com.dexter.tv.ui.SettingsScreen
import com.dexter.tv.ui.Toast
import com.dexter.tv.ui.VoiceOverlay
import com.dexter.tv.ui.WelcomeOverlay
import com.dexter.tv.ui.VoteScreen

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { vm.micPermissionResult(it) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            BackHandler(enabled = vm.stack.size > 1) { vm.back() }
            LaunchedEffect(vm.needMic) { if (vm.needMic) micPermission.launch(Manifest.permission.RECORD_AUDIO) }
            App(vm)
        }
        vm.bootOnce()
    }

    /** The remote's mic / search / assistant key (and the yellow key as a backup) starts listening. */
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_SEARCH, KeyEvent.KEYCODE_VOICE_ASSIST, KeyEvent.KEYCODE_ASSIST,
            KeyEvent.KEYCODE_MEDIA_RECORD, KeyEvent.KEYCODE_PROG_YELLOW -> {
                if (event.repeatCount == 0) vm.toggleMic()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }
}

@Composable
private fun App(vm: AppViewModel) {
    val dir = if (vm.lang == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr
    CompositionLocalProvider(LocalLang provides vm.lang, LocalLayoutDirection provides dir) {
        ScreenFit {
            Box(Modifier.fillMaxSize().background(C.Bg)) {
                Navigator(vm)
                VoiceOverlay(vm)
                Toast(vm)
                PinDialog(vm)
                WelcomeOverlay()
            }
        }
    }
}

private fun isOverlay(s: Screen) = s is Screen.Detail || s is Screen.Log || s is Screen.ProfileEdit

/**
 * Detail / History / Profile editor open ON TOP of the screen below them. That screen stays alive underneath,
 * so going back is instant and keeps the scroll position (no reloading, no lag).
 */
@Composable
private fun Navigator(vm: AppViewModel) {
    val stack = vm.stack
    val top = stack.last()
    val overlay = if (isOverlay(top)) top else null
    val base = if (overlay == null) top else stack.dropLast(1).lastOrNull { !isOverlay(it) } ?: Screen.Home
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().focusProperties { canFocus = overlay == null }) { Render(vm, base, active = overlay == null) }
        if (overlay != null) Render(vm, overlay, active = true)
    }
}

@Composable
private fun Render(vm: AppViewModel, s: Screen, active: Boolean) {
    when (s) {
        Screen.Boot -> BootScreen(vm)
        Screen.Login -> LoginScreen(vm)
        Screen.Profiles -> ProfilesScreen(vm)
        Screen.Home -> HomeScreen(vm, active)
        Screen.Chat -> ChatScreen(vm)
        Screen.Mood -> MoodScreen(vm)
        Screen.Log -> LogScreen(vm)
        Screen.MyList -> MyListScreen(vm)
        Screen.Vote -> VoteScreen(vm)
        Screen.Settings -> SettingsScreen(vm)
        is Screen.ProfileEdit -> ProfileEditScreen(vm, s.id)
        is Screen.Detail -> DetailScreen(vm, s.type, s.id)
    }
}

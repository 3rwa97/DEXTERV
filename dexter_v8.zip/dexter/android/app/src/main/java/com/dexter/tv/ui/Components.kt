@file:OptIn(androidx.compose.ui.ExperimentalComposeUiApi::class)

package com.dexter.tv.ui

import android.view.KeyEvent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.zIndex
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.nativeKeyEvent
import androidx.compose.ui.input.key.nativeKeyCode
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import com.dexter.tv.R
import com.dexter.tv.AppViewModel
import com.dexter.tv.Screen
import com.dexter.tv.data.Item
import kotlinx.coroutines.delay
import java.util.Locale

object C {
    val Bg = Color(0xFF0A0706)
    val Panel = Color(0xFF171211)
    val Panel2 = Color(0xFF221A17)
    val Line = Color(0xFF33271F)
    val Text = Color(0xFFF7F2EE)
    val Muted = Color(0xFFA89A90)
    val Accent = Color(0xFFF26A0F)
    val AccentHi = Color(0xFFFF8A33)
    val AccentDeep = Color(0xFF3A1D0C)
    val Glow = Color(0xFFFF8A33)
    val Cyan = Color(0xFFFFB347)   // amber highlight (name kept from the first palette)
    val Pink = Color(0xFFFF4D2E)   // red-orange
    val Gold = Color(0xFFFFC23D)
    val Green = Color(0xFF5BE49B)
    val Danger = Color(0xFFFF6B6B)
}

val LocalLang = compositionLocalOf { "en" }

@Composable
fun tr(key: String): String = S.get(LocalLang.current, key)

/** Every screen is laid out on a 960 x 540 dp canvas. */
const val DESIGN_W = 960f
const val DESIGN_H = 540f

/** TV-safe margins (5% of the canvas) so nothing is ever cut off by the screen edge. */
val SafeH = 48.dp
val SafeV = 27.dp

/**
 * Makes the layout 100% screen-independent: whatever resolution or density the TV reports,
 * the 960x540 design canvas is scaled to exactly fit the real screen.
 */
@Composable
fun ScreenFit(content: @Composable () -> Unit) {
    val d = LocalDensity.current
    BoxWithConstraints(Modifier.fillMaxSize().background(C.Bg)) {
        val scale = minOf(maxWidth.value / DESIGN_W, maxHeight.value / DESIGN_H).coerceIn(0.5f, 4f)
        CompositionLocalProvider(LocalDensity provides Density(d.density * scale, 1f)) {
            Box(Modifier.fillMaxSize()) { content() }
        }
    }
}

@Composable
fun T(
    text: String,
    size: Int = 14,
    color: Color = C.Text,
    weight: FontWeight = FontWeight.Normal,
    modifier: Modifier = Modifier,
    maxLines: Int = Int.MAX_VALUE,
    align: TextAlign = TextAlign.Unspecified,
    spacing: Float = 0f,
) {
    BasicText(
        text,
        modifier,
        style = TextStyle(color = color, fontSize = size.sp, fontWeight = weight, textAlign = align, letterSpacing = spacing.sp, lineHeight = (size * 1.3f).sp),
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
    )
}

/**
 * Base for everything the remote can focus. The focused item springs up (zoom) and gets a bright frame
 * with a soft glow, so the viewer never loses track of where they are.
 */
@Composable
fun Focusable(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(12.dp),
    color: Color = C.Panel,
    focusColor: Color = C.Panel2,
    ring: Color = Color.White,
    scale: Float = 1.08f,
    glow: Color = C.Glow,
    content: @Composable BoxScope.(Boolean) -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val sc by animateFloatAsState(if (focused) scale else 1f, spring(dampingRatio = 0.7f, stiffness = 420f), label = "focusScale")
    val gl by animateFloatAsState(if (focused) 1f else 0f, tween(200), label = "focusGlow")
    val src = remember { MutableInteractionSource() }
    Box(
        modifier
            .onFocusChanged { focused = it.isFocused }
            .zIndex(if (focused) 1f else 0f)
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .drawBehind {
                if (gl > 0.01f) {
                    val outline = shape.createOutline(size, layoutDirection, this)
                    for (i in 1..6) drawOutline(outline, glow.copy(alpha = gl * 0.34f / i), style = Stroke(width = (i * 4).dp.toPx()))
                }
            }
            .clip(shape)
            .background(if (focused) focusColor else color, shape)
            .then(if (focused) Modifier.border(BorderStroke(2.5.dp, ring), shape) else Modifier)
            .clickable(interactionSource = src, indication = null, onClick = onClick),
    ) { content(focused) }
}

@Composable
fun DButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, primary: Boolean = false, size: Int = 13) {
    Focusable(
        onClick, modifier,
        shape = RoundedCornerShape(10.dp),
        color = if (primary) C.Accent else C.Panel2,
        focusColor = if (primary) C.AccentHi else C.Line,
        ring = Color.White,
    ) {
        Box(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), contentAlignment = Alignment.Center) {
            T(text, size, weight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

@Composable
fun DChip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Focusable(
        onClick, modifier,
        shape = RoundedCornerShape(50),
        color = if (selected) C.AccentDeep else C.Panel,
        focusColor = if (selected) Color(0xFF5A2E12) else C.Panel2,
        ring = if (selected) C.Accent else Color.White,
        scale = 1.06f,
    ) {
        Box(Modifier.padding(horizontal = 14.dp, vertical = 7.dp), contentAlignment = Alignment.Center) {
            T((if (selected) "✓ " else "") + text, 12, if (selected) Color.White else C.Muted, FontWeight.Medium, maxLines = 1)
        }
    }
}

@Composable
fun Avatar(name: String, colorHex: String, size: Dp, modifier: Modifier = Modifier) {
    val col = remember(colorHex) { try { Color(android.graphics.Color.parseColor(colorHex)) } catch (_: Exception) { C.Accent } }
    Box(modifier.size(size).clip(CircleShape).background(col), contentAlignment = Alignment.Center) {
        T(name.take(1).uppercase(), (size.value * 0.45f).toInt(), Color.White, FontWeight.Bold)
    }
}

@Composable
fun PosterCard(item: Item, onClick: () -> Unit, modifier: Modifier = Modifier, width: Dp = 112.dp, caption: String? = null) {
    Column(Modifier.width(width)) {
        Focusable(onClick, modifier.fillMaxWidth().aspectRatio(2f / 3f), shape = RoundedCornerShape(12.dp), color = C.Panel2, scale = 1.12f) {
            AsyncImage(model = item.poster, contentDescription = item.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            if (item.rating > 0) {
                Box(
                    Modifier.align(Alignment.TopEnd).padding(4.dp).background(Color(0xB0000000), RoundedCornerShape(6.dp)).padding(horizontal = 5.dp, vertical = 2.dp),
                ) { T("★ " + String.format(Locale.US, "%.1f", item.rating), 10, C.Gold, FontWeight.SemiBold) }
            }
        }
        Spacer(Modifier.height(5.dp))
        T(item.title, 11, C.Text, FontWeight.Medium, Modifier.padding(horizontal = 2.dp), maxLines = 1)
        if (caption != null) T(caption, 10, C.Muted, modifier = Modifier.padding(horizontal = 2.dp), maxLines = 2)
    }
}

/** A titled horizontal row of posters. Remembers which card had focus so coming back from a detail page lands on it. */
@Composable
fun PosterRow(
    title: String,
    items: List<Item>,
    rowId: String,
    restoreKey: String?,
    restoreTick: Int,
    onFocusItem: (String) -> Unit,
    onOpen: (Item) -> Unit,
    cardWidth: Dp = 112.dp,
) {
    val fr = remember { FocusRequester() }
    val hasRestore = restoreKey != null && items.any { "$rowId:${it.type}:${it.id}" == restoreKey }
    LaunchedEffect(restoreTick) {
        if (restoreTick > 0 && hasRestore) {
            delay(80)
            try { fr.requestFocus() } catch (_: Exception) { }
        }
    }
    Column {
        T(title, 16, weight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp)) {
            items(items, key = { "${it.type}:${it.id}" }) { item ->
                val k = "$rowId:${item.type}:${item.id}"
                PosterCard(
                    item,
                    onClick = { onOpen(item) },
                    modifier = (if (k == restoreKey) Modifier.focusRequester(fr) else Modifier).onFocusChanged { if (it.isFocused) onFocusItem(k) },
                    width = cardWidth,
                    caption = item.why,
                )
            }
        }
    }
}

@Composable
fun TopBar(vm: AppViewModel, current: Screen, down: FocusRequester? = null, landOnTab: Boolean = false) {
    val p = vm.profile
    // [down] is the first focusable thing of the screen below. Wiring it explicitly means Down always lands there,
    // instead of relying on the automatic search (which lost the highlight on some screens).
    val toContent = if (down != null) Modifier.focusProperties { this.down = down } else Modifier
    val tabFocus = remember { FocusRequester() }
    if (landOnTab) LaunchedEffect(current) { delay(150); try { tabFocus.requestFocus() } catch (_: Exception) { } }
    Row(Modifier.fillMaxWidth().height(40.dp), verticalAlignment = Alignment.CenterVertically) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.ic_launcher), null, Modifier.size(30.dp).clip(RoundedCornerShape(8.dp)))
            Spacer(Modifier.width(8.dp))
            T("Dexter", 20, weight = FontWeight.ExtraBold)
        }
        Spacer(Modifier.width(24.dp))
        val tabs = listOf(Screen.Home to "tab_home", Screen.Chat to "tab_chat", Screen.Mood to "tab_mood", Screen.MyList to "tab_list", Screen.Vote to "tab_vote", Screen.Settings to "tab_settings")
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.weight(1f)) {
            tabs.forEach { (s, key) ->
                val sel = current == s
                Focusable(
                    onClick = { if (!sel) vm.tab(s) },
                    modifier = (if (sel) Modifier.focusRequester(tabFocus) else Modifier).then(toContent),
                    shape = RoundedCornerShape(50),
                    color = if (sel) C.AccentDeep else Color.Transparent,
                    focusColor = C.Panel2,
                    ring = Color.White,
                    scale = 1.08f,
                ) {
                    Box(Modifier.padding(horizontal = 10.dp, vertical = 7.dp)) { T(tr(key), 13, if (sel) Color.White else C.Muted, if (sel) FontWeight.Bold else FontWeight.Medium, maxLines = 1) }
                }
            }
        }
        if (vm.primeReady) {
            DButton("PrimeVision", { vm.openPrime(null) }, toContent, size = 12)
            Spacer(Modifier.width(8.dp))
        }
        if (p != null) {
            Focusable(onClick = { vm.requestSwitchProfile() }, modifier = toContent, shape = CircleShape, color = Color.Transparent, focusColor = Color.Transparent, scale = 1.12f) {
                Avatar(p.name, p.color, 30.dp)
            }
        }
    }
}

@Composable
fun Centered(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { content() }
}

@Composable
fun Toast(vm: AppViewModel) {
    val m = vm.message ?: return
    Box(Modifier.fillMaxSize().padding(bottom = 34.dp), contentAlignment = Alignment.BottomCenter) {
        Box(Modifier.clip(RoundedCornerShape(50)).background(Color(0xF0221A17)).border(1.dp, C.Line, RoundedCornerShape(50)).padding(horizontal = 18.dp, vertical = 9.dp)) {
            T(m, 13, maxLines = 2)
        }
    }
}

// ---------- dialogs ----------
/**
 * Text entry that works with only a TV remote: our own on-screen keyboard (English + Arabic).
 * It never uses the system keyboard, which flickered open/closed on TVs and phones.
 */
@Composable
fun TextInputDialog(title: String, initial: String, hint: String = "", onDone: (String) -> Unit, onCancel: () -> Unit) {
    val rtl = androidx.compose.ui.platform.LocalLayoutDirection.current == androidx.compose.ui.unit.LayoutDirection.Rtl
    var text by remember { mutableStateOf(initial) }
    var arabic by remember { mutableStateOf(initial.any { it in '\u0600'..'\u06FF' } || (initial.isBlank() && rtl)) }
    var upper by remember { mutableStateOf(false) }
    val first = remember { FocusRequester() }
    val rows = if (arabic) listOf("1234567890", "ضصثقفغعهخحج", "شسيبلاتنمكط", "ئءؤرىةوزظذد") else listOf("1234567890", "qwertyuiop", "asdfghjkl", "zxcvbnm.-_@")
    Dialog(onDismissRequest = onCancel, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        androidx.compose.runtime.CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Ltr) {
            Column(
                Modifier.width(560.dp).clip(RoundedCornerShape(16.dp)).background(C.Panel).border(1.dp, C.Line, RoundedCornerShape(16.dp)).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                T(title, 16, weight = FontWeight.Bold)
                Box(Modifier.fillMaxWidth().background(C.Bg, RoundedCornerShape(10.dp)).border(2.dp, C.Accent, RoundedCornerShape(10.dp)).padding(horizontal = 12.dp, vertical = 8.dp)) {
                    CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides (if (arabic) androidx.compose.ui.unit.LayoutDirection.Rtl else androidx.compose.ui.unit.LayoutDirection.Ltr)) {
                        T(text + "|", 18, C.Text, maxLines = 1)
                    }
                }
                if (hint.isNotBlank()) T(hint, 11, C.Muted, maxLines = 1)
                rows.forEachIndexed { ri, row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        row.forEachIndexed { ci, ch ->
                            val shown = if (upper && !arabic) ch.uppercaseChar() else ch
                            Focusable(
                                onClick = { text += shown },
                                modifier = Modifier.weight(1f).height(34.dp).then(if (ri == 1 && ci == 0) Modifier.focusRequester(first) else Modifier),
                                shape = RoundedCornerShape(8.dp), color = C.Panel2, focusColor = C.Line, ring = Color.White, scale = 1.12f,
                            ) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { T(shown.toString(), 16, weight = FontWeight.SemiBold, maxLines = 1) } }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Focusable({ arabic = !arabic }, Modifier.weight(1.3f).height(34.dp), RoundedCornerShape(8.dp), C.Panel2, C.Line, Color.White) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { T(if (arabic) "EN" else "عربي", 14, weight = FontWeight.Bold, maxLines = 1) }
                    }
                    if (!arabic) Focusable({ upper = !upper }, Modifier.weight(1f).height(34.dp), RoundedCornerShape(8.dp), if (upper) C.Accent else C.Panel2, C.Line, Color.White) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { T("Aa", 14, weight = FontWeight.Bold, maxLines = 1) }
                    }
                    Focusable({ text += " " }, Modifier.weight(4f).height(34.dp), RoundedCornerShape(8.dp), C.Panel2, C.Line, Color.White) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { T("␣", 14, C.Muted, maxLines = 1) }
                    }
                    Focusable({ text = text.dropLast(1) }, Modifier.weight(1.3f).height(34.dp), RoundedCornerShape(8.dp), C.Panel2, C.Line, Color.White) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { T("⌫", 16, weight = FontWeight.Bold, maxLines = 1) }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    DButton(tr("save"), { onDone(text) }, primary = true)
                    DButton(tr("cancel"), onCancel)
                }
            }
        }
    }
    LaunchedEffect(Unit) {
        delay(250)
        try { first.requestFocus() } catch (_: Exception) { }
    }
}

@Composable
fun PinDialog(vm: AppViewModel) {
    val prompt = vm.pinPrompt ?: return
    var pin by remember(prompt, vm.pinErrorCount) { mutableStateOf("") }
    val fr = remember { FocusRequester() }
    fun press(d: String) {
        if (pin.length >= 4) return
        val n = pin + d
        pin = n
        if (n.length == 4) vm.submitPin(n)
    }
    Dialog(onDismissRequest = { vm.cancelPin() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.width(300.dp).clip(RoundedCornerShape(16.dp)).background(C.Panel).border(1.dp, C.Line, RoundedCornerShape(16.dp)).padding(18.dp)
                .onPreviewKeyEvent { e ->
                    val code = e.key.nativeKeyCode
                    if (e.type == KeyEventType.KeyDown && code in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9) { press((code - KeyEvent.KEYCODE_0).toString()); true } else false
                },
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            T(prompt.title, 15, weight = FontWeight.Bold, align = TextAlign.Center)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                repeat(4) { i -> Box(Modifier.size(14.dp).clip(CircleShape).background(if (i < pin.length) C.Accent else C.Line)) }
            }
            Box(Modifier.height(16.dp)) { vm.pinError?.let { T(it, 12, C.Danger) } }
            listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("⌫", "0", "✕")).forEach { rowKeys ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    rowKeys.forEach { k ->
                        Focusable(
                            onClick = { when (k) { "⌫" -> pin = pin.dropLast(1); "✕" -> vm.cancelPin(); else -> press(k) } },
                            modifier = Modifier.width(80.dp).height(44.dp).then(if (k == "5") Modifier.focusRequester(fr) else Modifier),
                            shape = RoundedCornerShape(10.dp), color = C.Panel2, focusColor = C.Line, ring = Color.White,
                        ) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { T(k, 20, weight = FontWeight.SemiBold) } }
                    }
                }
            }
        }
    }
    LaunchedEffect(prompt, vm.pinErrorCount) {
        delay(150)
        try { fr.requestFocus() } catch (_: Exception) { }
    }
}

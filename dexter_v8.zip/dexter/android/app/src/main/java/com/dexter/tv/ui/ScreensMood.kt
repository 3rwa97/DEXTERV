package com.dexter.tv.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.dexter.tv.AppViewModel
import com.dexter.tv.Screen
import kotlinx.coroutines.delay

/** A mood the viewer can pick. The prompt is what Dexter is asked, in the viewer's language. */
class Mood(
    val id: String, val emoji: String, val ar: String, val en: String, val arPrompt: String, val enPrompt: String,
    /** TMDB genres that hold the whole category; [all] = a title must be in every one of them. */
    val genres: List<Int>, val all: Boolean = false,
)

val MOODS = listOf(
    Mood("laugh", "😂", "بدي أضحك", "Make me laugh", "بدي أفلام ومسلسلات كوميدية خفيفة تضحّكني من قلبي", "I want light comedy movies and series that make me laugh out loud", listOf(35)),
    Mood("twist", "🕵️", "جريمة وتشويق", "Crime & twists", "بدي أفلام ومسلسلات جريمة معقدة ونهايات غير متوقعة", "I want complex crime movies and series with unexpected endings", listOf(80, 9648, 53)),
    Mood("revenge", "⛓️", "سجن وانتقام", "Prison & revenge", "بدي أفلام ومسلسلات دراما عن السجون وبطل مظلوم بينتقم", "Prison drama movies and series about a wrongly accused hero who takes revenge", listOf(80, 18), true),
    Mood("mind", "🧠", "يلعب بالعقل", "Mind-bending", "بدي أفلام ومسلسلات إثارة نفسية وتشويق تلعب بعقلي وما بتتوقع نهايتها", "Mind-bending psychological thrillers, movies and series, that I won't see coming", listOf(53, 9648)),
    Mood("action", "🔥", "أكشن وحماس", "Pure adrenaline", "بدي أفلام ومسلسلات أكشن سريعة ومليانة حماس", "Fast, explosive action movies and series that get my adrenaline up", listOf(28)),
    Mood("cry", "😢", "دراما مؤثرة", "Make me cry", "بدي أفلام ومسلسلات دراما مؤثرة تبكيني", "Moving drama movies and series that make me cry", listOf(18)),
    Mood("love", "❤️", "رومانسي", "Romantic", "بدي أفلام ومسلسلات رومانسية بقلب دافي", "Warm, sweet romance movies and series", listOf(10749)),
    Mood("scary", "😱", "رعب", "Scare me", "بدي أفلام ومسلسلات رعب مخيفة", "Truly scary horror movies and series", listOf(27)),
    Mood("mystery", "🧩", "لغز وغموض", "Mystery", "بدي أفلام ومسلسلات لغز وغموض ما حدا بيتوقع نهايتها", "Mystery movies and series nobody can guess the ending of", listOf(9648)),
    Mood("space", "🚀", "خيال علمي", "Sci-fi", "بدي أفلام ومسلسلات خيال علمي عن الفضاء والمستقبل", "Sci-fi movies and series about space and the future", listOf(878)),
    Mood("cozy", "🌙", "مريح ولطيف", "Cozy night", "بدي أفلام ومسلسلات كوميدية لطيفة ومريحة تحسّن المزاج قبل النوم", "Cozy feel-good comedy movies and series to unwind before bed", listOf(35)),
    Mood("family", "👨‍👩‍👧", "جلسة عائلية", "Family night", "بدي أفلام ومسلسلات عائلية بنشوفها كلنا سوا", "Family movies and series we can all watch together", listOf(10751)),
)

@Composable
fun MoodCard(m: Mood, selected: Boolean, w: Dp, h: Dp, emojiSize: Int, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val ar = LocalLang.current == "ar"
    Focusable(
        onClick,
        modifier.width(w).height(h),
        shape = RoundedCornerShape(18.dp),
        color = if (selected) C.AccentDeep else C.Panel,
        focusColor = Color(0xFF2E2420),
        scale = 1.12f,
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            T(m.emoji, emojiSize)
            Spacer(Modifier.height(4.dp))
            T(if (ar) m.ar else m.en, 12, if (selected) Color.White else Color(0xFFD8D8E6), FontWeight.SemiBold, maxLines = 2, align = TextAlign.Center)
        }
    }
}

/** A compact strip of moods on the Home screen. Picking one jumps to the Mood tab with the answer. */
@Composable
fun MoodStrip(vm: AppViewModel) {
    val ar = LocalLang.current == "ar"
    Column {
        T(tr("home_mood"), 16, weight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp)) {
            items(MOODS, key = { it.id }) { m ->
                MoodCard(m, false, 92.dp, 74.dp, 24) { vm.pickMood(if (ar) m.arPrompt else m.enPrompt, m.id, m.genres, m.all) }
            }
        }
    }
}

@Composable
fun MoodScreen(vm: AppViewModel) {
    val ar = LocalLang.current == "ar"
    var typing by remember { mutableStateOf(false) }
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { delay(220); try { first.requestFocus() } catch (_: Exception) { } }
    val movies = vm.moodItems.filter { it.type == "movie" }
    val series = vm.moodItems.filter { it.type == "tv" }
    val open = { t: com.dexter.tv.data.Item -> vm.go(Screen.Detail(t.type, t.id)) }

    Column(Modifier.fillMaxSize().padding(horizontal = SafeH, vertical = SafeV)) {
        TopBar(vm, Screen.Mood, down = first)
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            item(key = "head") {
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        T(tr("mood_title"), 20, weight = FontWeight.ExtraBold, maxLines = 1)
                        T(tr("mood_sub"), 12, C.Muted, maxLines = 1)
                    }
                    DIconButton(tr("mood_say"), { vm.startMic() }, primary = true) { MicIcon(16.dp, it) }
                    Spacer(Modifier.width(8.dp))
                    DIconButton(tr("mood_type"), { typing = true }) { KeyboardIcon(18.dp, it) }
                }
            }
            item(key = "cards") {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp)) {
                    itemsIndexed(MOODS, key = { _, m -> m.id }) { i, m ->
                        MoodCard(m, vm.moodSel == m.id, 108.dp, 84.dp, 28, if (i == 0) Modifier.focusRequester(first) else Modifier) {
                            vm.runMood(if (ar) m.arPrompt else m.enPrompt, m.id, m.genres, m.all)
                        }
                    }
                }
            }
            val reply = vm.moodReply
            when {
                vm.moodBusy -> item(key = "busy") { T(tr("thinking"), 14, C.Muted, modifier = Modifier.padding(start = 4.dp, top = 6.dp)) }
                reply != null -> {
                    item(key = "reply") { T(reply, 14, Color(0xFFE6E6F2), modifier = Modifier.padding(start = 4.dp, bottom = 2.dp), maxLines = 2) }
                    if (movies.isNotEmpty()) item(key = "movies") { PosterRow(tr("mood_movies") + "  ·  " + movies.size, movies, "mood-m", null, 0, { }, open, 104.dp) }
                    if (series.isNotEmpty()) item(key = "series") { PosterRow(tr("mood_series") + "  ·  " + series.size, series, "mood-s", null, 0, { }, open, 104.dp) }
                }
                else -> item(key = "empty") { T(tr("mood_empty"), 13, C.Muted, modifier = Modifier.padding(start = 4.dp, top = 6.dp)) }
            }
        }
    }
    if (typing) TextInputDialog(tr("mood_prompt"), "", onDone = { typing = false; vm.runMood(it) }, onCancel = { typing = false })
}

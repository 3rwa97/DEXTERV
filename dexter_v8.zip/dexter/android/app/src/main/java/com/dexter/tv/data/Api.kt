package com.dexter.tv.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class ApiException(val status: Int, message: String) : Exception(message)

class Api(private val prefs: Prefs, private val onUnauthorized: () -> Unit) : Backend {
    private val http = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    suspend fun call(
        method: String,
        path: String,
        body: JSONObject? = null,
        auth: Boolean = true,
        profile: Boolean = true,
    ): JSONObject = withContext(Dispatchers.IO) {
        val rb = if (method == "GET" || method == "DELETE") null else (body ?: JSONObject()).toString().toRequestBody(jsonType)
        val b = Request.Builder().url(prefs.server + path).method(method, rb)
        if (auth) prefs.token?.let { b.header("Authorization", "Bearer $it") }
        if (profile && prefs.profileId > 0) b.header("X-Profile", prefs.profileId.toString())
        try {
            http.newCall(b.build()).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                val json = try { JSONObject(text) } catch (_: Exception) { JSONObject() }
                if (!resp.isSuccessful) {
                    if (resp.code == 401 && auth) onUnauthorized()
                    throw ApiException(resp.code, json.optString("error", "Error ${resp.code}"))
                }
                json
            }
        } catch (e: IOException) {
            throw ApiException(0, "Can't reach Dexter's server")
        } catch (e: IllegalArgumentException) {
            throw ApiException(0, "Server address is not valid")
        }
    }

    // ----- login -----
    override suspend fun deviceStart(name: String): DeviceLogin {
        val j = call("POST", "/api/device/start", JSONObject().put("name", name), auth = false, profile = false)
        return DeviceLogin(j.str("deviceCode"), j.str("userCode"), j.str("verifyUrl"), j.optInt("expiresIn", 600))
    }

    /** Returns the device token once the phone approved, else null. */
    override suspend fun devicePoll(code: String): String? {
        val j = call("GET", "/api/device/poll?code=${enc(code)}", auth = false, profile = false)
        return if (j.str("status") == "approved") j.strOrNull("token") else null
    }

    override suspend fun me(): Me {
        val j = call("GET", "/api/me", profile = false)
        val a = j.optJSONObject("account") ?: JSONObject()
        val c = j.optJSONObject("creator") ?: JSONObject()
        val f = j.optJSONObject("features") ?: JSONObject()
        return Me(a.str("email"), a.optBoolean("hasParentPin"), c.str("name", "Orwa Shoura"), c.str("email", "orwashoura@gmail.com"), f.optBoolean("ai"), f.optBoolean("tmdb"))
    }

    override suspend fun logout() { call("POST", "/api/logout", profile = false) }

    // ----- profiles & pins -----
    override suspend fun profiles(): List<Profile> = call("GET", "/api/profiles", profile = false).optJSONArray("profiles").objs().map(::parseProfile)

    override suspend fun saveProfile(id: Long?, body: JSONObject): Profile {
        val j = if (id == null) call("POST", "/api/profiles", body, profile = false) else call("PATCH", "/api/profiles/$id", body, profile = false)
        return parseProfile(j.getJSONObject("profile"))
    }

    override suspend fun deleteProfile(id: Long, parentPin: String?) {
        call("DELETE", "/api/profiles/$id" + if (parentPin != null) "?parentPin=${enc(parentPin)}" else "", profile = false)
    }

    override suspend fun verifyProfilePin(id: Long, pin: String) { call("POST", "/api/profiles/$id/verify-pin", JSONObject().put("pin", pin), profile = false) }
    override suspend fun verifyParentPin(pin: String) { call("POST", "/api/pin/verify", JSONObject().put("pin", pin), profile = false) }
    override suspend fun setParentPin(pin: String, current: String?) {
        call("POST", "/api/pin/set", JSONObject().put("pin", pin).apply { if (current != null) put("current", current) }, profile = false)
    }

    // ----- content -----
    override suspend fun homeRaw(): JSONObject = call("GET", "/api/home")
    override suspend fun briefingRaw(tz: String): JSONObject = call("GET", "/api/briefing?tz=${enc(tz)}")
    override suspend fun search(q: String): List<Item> = parseItems(call("GET", "/api/search?q=${enc(q)}").optJSONArray("items"))
    override suspend fun title(type: String, id: Long): Detail = parseDetail(call("GET", "/api/title/$type/$id"))
    override suspend fun why(type: String, id: Long): String = call("POST", "/api/why", JSONObject().put("type", type).put("id", id)).str("text")

    override suspend fun library(filter: String): List<Item> = parseItems(call("GET", "/api/library?filter=$filter").optJSONArray("items"))

    override suspend fun setLibrary(item: Item, watchlist: Boolean?, watched: Boolean?, reaction: Int?): LibState {
        val b = JSONObject().put("id", item.id).put("type", item.type).put("title", item.title).put("year", item.year)
        item.poster?.let { b.put("poster", it) }
        watchlist?.let { b.put("watchlist", it) }
        watched?.let { b.put("watched", it) }
        reaction?.let { b.put("reaction", it) }
        return parseLib(call("POST", "/api/library", b).optJSONObject("state"))
    }

    // ----- chat -----
    override suspend fun chat(message: String, tz: String): ChatReply {
        val j = call("POST", "/api/chat", JSONObject().put("message", message).put("tz", tz))
        return ChatReply(j.str("reply"), parseItems(j.optJSONArray("titles")), j.strOrNull("openApp"))
    }

    override suspend fun chatLog(q: String?, limit: Int): List<ChatMsg> {
        val path = "/api/chat/log?limit=$limit" + if (!q.isNullOrBlank()) "&q=${enc(q)}" else ""
        return call("GET", path).optJSONArray("messages").objs().map {
            ChatMsg(it.optLong("id"), it.str("role"), it.str("content"), parseItems(it.optJSONArray("titles")))
        }
    }

    override suspend fun clearLog() { call("DELETE", "/api/chat/log") }

    override suspend fun vote(ids: List<Long>): Pair<List<Item>, Boolean> {
        val j = call("POST", "/api/vote", JSONObject().put("profileIds", JSONArray(ids)))
        return parseItems(j.optJSONArray("items")) to j.optBoolean("kidsIncluded")
    }

    override suspend fun inbox(): List<Item> = call("GET", "/api/inbox", profile = false).optJSONArray("items").objs().map(::parseItem)
}

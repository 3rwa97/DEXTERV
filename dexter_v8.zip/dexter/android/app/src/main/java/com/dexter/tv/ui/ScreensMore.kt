@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.dexter.tv.ui

import android.annotation.SuppressLint
import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.dexter.tv.AppViewModel
import com.dexter.tv.Screen
import com.dexter.tv.data.Detail
import kotlinx.coroutines.delay
import java.util.Locale

// ======================= DETAIL =======================
@Composable
fun DetailScreen(vm: AppViewModel, type: String, id: Long) {
    LaunchedEffect(type, id) { vm.loadDetail(type, id) }
    val d = vm.detail?.takeIf { it.item.id == id && it.item.type == type }
    var trailer by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().background(C.Bg)) {
        if (d == null) {
            Centered {
                val err = vm.detailError
                if (err != null) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        T(err, 15, C.Muted)
                        DButton(tr("retry"), { vm.loadDetail(type, id) }, primary = true)
                    }
                } else T(tr("loading"), 16, C.Muted)
            }
        } else {
            AsyncImage(d.item.backdrop ?: d.item.poster, null, Modifier.fillMaxSize().alpha(0.32f), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(C.Bg, C.Bg.copy(alpha = 0.88f), Color.Transparent))))
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, C.Bg))))
            DetailBody(vm, d) { trailer = true }
            val key = d.trailerKey
            if (trailer && key != null) TrailerDialog(key, onClose = { trailer = false }, onExternal = { vm.openTrailerExternally(key) })
        }
    }
}

@Composable
private fun DetailBody(vm: AppViewModel, d: Detail, onTrailer: () -> Unit) {
    val film = d.item
    val first = remember(film.id) { FocusRequester() }
    LaunchedEffect(film.id) { delay(250); try { first.requestFocus() } catch (_: Exception) { } }
    val st = d.state
    val meta = buildList {
        if (film.year.isNotBlank()) add(film.year)
        if (d.runtime > 0) add("${d.runtime} ${tr("min")}")
        if (d.seasons > 0) add("${d.seasons} ${tr("seasons")}")
        if (d.certification.isNotBlank()) add(d.certification)
        if (film.rating > 0) add("★ " + String.format(Locale.US, "%.1f", film.rating))
    }.joinToString("  ·  ")
    val streamers = d.providers.filter { p -> p.kind == "stream" || p.kind == "free" }.distinctBy { p -> p.name }.take(4)

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = SafeH, vertical = SafeV),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                AsyncImage(film.poster, film.title, Modifier.width(138.dp).aspectRatio(2f / 3f).clip(RoundedCornerShape(12.dp)).background(C.Panel2), contentScale = ContentScale.Crop)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    T(film.title, 26, weight = FontWeight.ExtraBold, maxLines = 2)
                    T(meta, 12, C.Muted, FontWeight.Medium)
                    if (d.genres.isNotEmpty()) T(d.genres.joinToString(" · "), 12, C.Accent, FontWeight.Medium, maxLines = 1)
                    if (d.tagline.isNotBlank()) T(d.tagline, 12, C.Muted, maxLines = 1)
                    if (d.extra.isNotBlank()) T("📅 " + d.extra, 12, C.Cyan, FontWeight.SemiBold, maxLines = 1)
                    T(film.overview, 13, Color(0xFFE2E2EC), maxLines = 4)
                    if (d.cast.isNotEmpty()) T(d.cast.take(5).joinToString(", "), 11, C.Muted, maxLines = 1)
                    Spacer(Modifier.height(4.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        DButton(if (st.watchlist) tr("in_list") else tr("add_list"), { vm.updateLib(d, watchlist = !st.watchlist) }, Modifier.focusRequester(first), primary = !st.watchlist)
                        DButton(if (st.watched) tr("watched") else tr("mark_watched"), { vm.updateLib(d, watched = !st.watched) })
                        DButton("👍", { vm.updateLib(d, reaction = if (st.reaction == 1) 0 else 1) }, primary = st.reaction == 1)
                        DButton("👎", { vm.updateLib(d, reaction = if (st.reaction == -1) 0 else -1) }, primary = st.reaction == -1)
                        if (d.trailerKey != null) DButton(tr("trailer"), onTrailer)
                        DButton(tr("why"), { vm.explain(d) })
                    }
                    if (streamers.isNotEmpty() || vm.primeReady) {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            streamers.forEach { p -> DButton("${tr("watch_on")} ${p.name}", { vm.openProvider(p, film.title) }) }
                            if (vm.primeReady) DButton("📺 " + tr("open_prime"), { vm.openPrime(film.title) })
                        }
                    }
                    val why = vm.whyText
                    if (vm.whyBusy) T(tr("thinking"), 12, C.Muted)
                    else if (why != null) T("💡 $why", 13, C.Green)
                }
            }
        }
        if (d.similar.isNotEmpty()) {
            item {
                PosterRow(tr("more_like"), d.similar, "sim", null, 0, { }, { s -> vm.go(Screen.Detail(s.type, s.id)) })
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun TrailerDialog(key: String, onClose: () -> Unit, onExternal: () -> Unit) {
    var web by remember { mutableStateOf<WebView?>(null) }
    DisposableEffect(Unit) { onDispose { web?.destroy() } }
    val html = "<html><body style='margin:0;background:#000'><iframe style='position:absolute;inset:0;width:100%;height:100%;border:0' " +
        "src='https://www.youtube.com/embed/$key?autoplay=1&rel=0&playsinline=1' allow='autoplay; encrypted-media; fullscreen' allowfullscreen></iframe></body></html>"
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(Color.Black).padding(horizontal = SafeH, vertical = SafeV), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        webChromeClient = WebChromeClient()
                        setBackgroundColor(android.graphics.Color.BLACK)
                        loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "utf-8", null)
                        web = this
                    }
                },
                modifier = Modifier.weight(1f).fillMaxWidth(),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DButton(tr("close"), onClose, primary = true)
                DButton("YouTube", onExternal)
            }
        }
    }
}

// ======================= MY LIST =======================
@Composable
fun MyListScreen(vm: AppViewModel) {
    LaunchedEffect(Unit) { vm.loadList(vm.listFilter) }
    val firstChip = remember { FocusRequester() }
    val firstPoster = remember { FocusRequester() }
    val toGrid = if (vm.listItems.isNotEmpty()) Modifier.focusProperties { down = firstPoster } else Modifier
    Column(Modifier.fillMaxSize().padding(horizontal = SafeH, vertical = SafeV)) {
        TopBar(vm, Screen.MyList, down = firstChip, landOnTab = true)
        Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("watchlist" to "wl", "watched" to "wd", "liked" to "lk").forEachIndexed { i, (f, k) ->
                DChip(tr(k), vm.listFilter == f, { vm.loadList(f) }, (if (i == 0) Modifier.focusRequester(firstChip) else Modifier).then(toGrid))
            }
        }
        if (vm.listItems.isEmpty()) {
            Centered { T(if (vm.listLoading) tr("loading") else tr("empty_list"), 14, C.Muted, align = TextAlign.Center) }
        } else {
            LazyVerticalGrid(
                GridCells.Adaptive(112.dp), Modifier.fillMaxSize(),
                contentPadding = PaddingValues(14.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                gridItems(vm.listItems.size, key = { "${vm.listItems[it].type}:${vm.listItems[it].id}" }) { idx ->
                    val m = vm.listItems[idx]
                    PosterCard(m, { vm.go(Screen.Detail(m.type, m.id)) }, if (idx == 0) Modifier.focusRequester(firstPoster) else Modifier)
                }
            }
        }
    }
}

// ======================= FAMILY VOTE =======================
@Composable
fun VoteScreen(vm: AppViewModel) {
    LaunchedEffect(Unit) { if (vm.voteSel.isEmpty()) vm.profile?.let { vm.voteSel.add(it.id) } }
    val firstChip = remember { FocusRequester() }
    Column(Modifier.fillMaxSize().padding(horizontal = SafeH, vertical = SafeV), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TopBar(vm, Screen.Vote, down = firstChip, landOnTab = true)
        T(tr("vote_title"), 20, weight = FontWeight.ExtraBold)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            vm.profiles.forEachIndexed { i, p -> DChip((if (p.isKid) "🧒 " else "") + p.name, vm.voteSel.contains(p.id), { vm.toggleVote(p.id) }, if (i == 0) Modifier.focusRequester(firstChip) else Modifier) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            DButton(if (vm.voteBusy) tr("loading") else tr("vote_go"), { vm.runVote() }, primary = true)
            if (vm.voteKids && vm.voteItems != null) T(tr("vote_kid"), 12, C.Muted)
        }
        val items = vm.voteItems
        if (items != null) {
            if (items.isEmpty()) T(tr("vote_none"), 13, C.Muted) else {
                LazyVerticalGrid(
                    GridCells.Adaptive(112.dp), Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(6.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    gridItems(items, key = { "${it.type}:${it.id}" }) { m ->
                        PosterCard(m, { vm.go(Screen.Detail(m.type, m.id)) }, caption = if (m.lovedBy.isNotEmpty()) tr("loved_by") + " " + m.lovedBy.joinToString(", ") else null)
                    }
                }
            }
        }
    }
}

// ======================= SETTINGS =======================
@Composable
fun SettingsScreen(vm: AppViewModel) {
    var dialog by remember { mutableStateOf<String?>(null) }
    val p = vm.profile
    val onOff = { v: Boolean -> if (v) tr("on") else tr("off") }
    val first = remember { FocusRequester() }
    var n = 0
    // The first row gets the focus requester, so Down from the tab bar always reaches it.
    fun m(): Modifier = if (n++ == 0) Modifier.focusRequester(first) else Modifier

    Column(Modifier.fillMaxSize().padding(horizontal = SafeH, vertical = SafeV)) {
        TopBar(vm, Screen.Settings, down = first, landOnTab = true)
        Spacer(Modifier.height(6.dp))
        // A plain scrolling column (not a lazy one): every row exists, so the remote can always move to the next row,
        // and the list scrolls by itself to follow the highlight.
        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            T(tr("set_profile"), 13, C.Accent, FontWeight.Bold, Modifier.padding(top = 4.dp))
            if (p != null) {
                SettingRow(tr("edit_profile"), p.name, { vm.go(Screen.ProfileEdit(p.id)) }, m())
                SettingRow(tr("switch_profile"), "", { vm.requestSwitchProfile() }, m())
                SettingRow(tr("set_lang"), if (p.lang == "ar") "العربية" else "English", { vm.setLanguage(if (p.lang == "ar") "en" else "ar") }, m())
                SettingRow(tr("spoiler"), onOff(p.spoilerSafe), { vm.setSpoilerSafe(!p.spoilerSafe) }, m())
            }
            SettingRow(tr("voice_on"), onOff(vm.voiceOn), { vm.setVoiceOn(!vm.voiceOn) }, m())
            SettingRow(tr("auto_brief"), onOff(vm.autoBrief), { vm.setAutoBrief(!vm.autoBrief) }, m())
            SettingRow(tr("parent_pin"), if (vm.me?.hasParentPin == true) tr("on") else tr("not_set"), { vm.changeParentPin() }, m())

            T(tr("apps"), 13, C.Accent, FontWeight.Bold, Modifier.padding(top = 10.dp))
            SettingRow(tr("prime_pkg"), vm.primePkg.ifBlank { tr("not_set") }, { dialog = "pkg" }, m())
            SettingRow(tr("prime_link"), vm.primeLink.ifBlank { tr("not_set") }, { dialog = "link" }, m())
            SettingRow(tr("test_prime"), "", { vm.openPrime(null) }, m())

            if (vm.localMode) {
                T(tr("keys"), 13, C.Accent, FontWeight.Bold, Modifier.padding(top = 10.dp))
                SettingRow(tr("tmdb_key"), if (vm.tmdbKey.isBlank()) tr("not_set") else "••••" + vm.tmdbKey.takeLast(4), { dialog = "tmdb" }, m())
                SettingRow(tr("gemini_key"), if (vm.geminiKey.isBlank()) tr("not_set") else "••••" + vm.geminiKey.takeLast(4), { dialog = "gemini" }, m())
                SettingRow(tr("claude_key"), if (vm.claudeKey.isBlank()) tr("not_set") else "••••" + vm.claudeKey.takeLast(4), { dialog = "claude" }, m())
                T(tr("keys_tip"), 12, C.Muted)
            }

            T(tr("about"), 13, C.Accent, FontWeight.Bold, Modifier.padding(top = 10.dp))
            if (!vm.localMode) SettingRow(tr("server_addr"), vm.serverUrl, { dialog = "server" }, m())
            SettingRow(tr("clear_hist"), "", { vm.clearLog() }, m())
            if (!vm.localMode) SettingRow(tr("sign_out"), vm.me?.email ?: "", { vm.signOut() }, m())
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(C.Panel).border(1.dp, C.Line, RoundedCornerShape(12.dp)).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                T("Dexter 1.0", 16, weight = FontWeight.ExtraBold)
                T("${tr("created_by")} $CREATOR_NAME", 14, C.Text, FontWeight.SemiBold)
                T(CREATOR_EMAIL, 13, C.Muted)
                val me = vm.me
                if (me != null) T("${tr("ai_on")}: ${onOff(me.ai)}   ·   ${tr("data_on")}: ${onOff(me.tmdb)}", 12, C.Muted)
            }
            Spacer(Modifier.height(10.dp))
        }
    }
    when (dialog) {
        "pkg" -> TextInputDialog(tr("prime_pkg"), vm.primePkg, "com.yourname.primevision", onDone = { vm.setPrimePkg(it); dialog = null }, onCancel = { dialog = null })
        "link" -> TextInputDialog(tr("prime_link"), vm.primeLink, "primevision://search?q={query}", onDone = { vm.setPrimeLink(it); dialog = null }, onCancel = { dialog = null })
        "tmdb" -> TextInputDialog(tr("tmdb_key"), vm.tmdbKey, "", onDone = { vm.setTmdbKey(it); dialog = null }, onCancel = { dialog = null })
        "gemini" -> TextInputDialog(tr("gemini_key"), vm.geminiKey, "AQ.…", onDone = { vm.setGeminiKey(it); dialog = null }, onCancel = { dialog = null })
        "claude" -> TextInputDialog(tr("claude_key"), vm.claudeKey, "sk-ant-...", onDone = { vm.setClaudeKey(it); dialog = null }, onCancel = { dialog = null })
        "server" -> TextInputDialog(tr("server_addr"), vm.serverUrl, "http://192.168.1.50:8787", onDone = { vm.changeServer(it); dialog = null }, onCancel = { dialog = null })
    }
}

package com.dexter.tv.local

import com.dexter.tv.BuildConfig
import com.dexter.tv.data.ApiException
import com.dexter.tv.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Talks to Google's Gemini API (key from Google AI Studio). Same shape as [ClaudeClient] so [Ai] can use either. */
class GeminiClient(private val prefs: Prefs, private val http: OkHttpClient) {
    fun enabled() = prefs.geminiKey.isNotBlank()

    private val model get() = BuildConfig.GEMINI_MODEL.ifBlank { "gemini-flash-latest" }

    /** Same fields Claude returns through its tool, expressed as a JSON schema for structured output. */
    private val schema = """
    {
      "type": "OBJECT",
      "properties": {
        "reply": {"type": "STRING"},
        "lang": {"type": "STRING", "enum": ["ar", "en"]},
        "titles": {
          "type": "ARRAY",
          "items": {
            "type": "OBJECT",
            "properties": {
              "title": {"type": "STRING"},
              "year": {"type": "INTEGER"},
              "type": {"type": "STRING", "enum": ["movie", "tv"]},
              "why": {"type": "STRING"}
            },
            "required": ["title", "type"]
          }
        },
        "learn": {"type": "ARRAY", "items": {"type": "STRING"}},
        "open_app": {"type": "STRING"}
      },
      "required": ["reply", "lang"]
    }
    """.trimIndent()

    private val outputRules = """

OUTPUT FORMAT (JSON only):
- reply: what Dexter says out loud. Warm, short (max about 55 words), no markdown, no emojis, easy to speak. Same language as the viewer.
- lang: "ar" or "en", the language of reply.
- titles: real titles, as many as the instructions above ask for (maximum 20). title = official English or original title exactly as listed on TMDB (so it can be looked up), year, type = "movie" or "tv", why = one short sentence in the reply language on why it fits this viewer, no spoilers. Empty array if none.
- learn: up to 3 durable taste facts the viewer clearly stated this turn. Empty if none.
- open_app: only if the viewer asked to open an app: primevision, netflix, youtube, shahid, prime, disney. Otherwise omit it."""

    private suspend fun post(body: JSONObject, readSeconds: Long): JSONObject = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .header("x-goog-api-key", prefs.geminiKey.trim())
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        try {
            http.newBuilder().readTimeout(readSeconds, TimeUnit.SECONDS).build().newCall(req).execute().use { r ->
                val text = r.body?.string().orEmpty()
                val badKey = r.code == 401 || r.code == 403 || (r.code == 400 && (text.contains("API key", true) || text.contains("API_KEY_INVALID")))
                if (badKey) throw ApiException(400, ERR_BAD_CLAUDE)
                if (!r.isSuccessful) throw ApiException(r.code, "Gemini ${r.code}")
                JSONObject(text)
            }
        } catch (e: IOException) {
            throw ApiException(0, "network")
        } catch (e: org.json.JSONException) {
            throw ApiException(502, "Gemini bad reply")
        }
    }

    private fun textOf(j: JSONObject): String {
        val parts = j.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val p = parts.optJSONObject(i) ?: continue
            if (p.optBoolean("thought")) continue
            sb.append(p.optString("text"))
        }
        return sb.toString().trim()
    }

    private fun parseJson(raw: String): JSONObject? {
        var s = raw.trim()
        if (s.startsWith("```")) s = s.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return try { JSONObject(s) } catch (_: Exception) { null }
    }

    /** One chat turn. [messages] uses Claude's format (role user/assistant, string content). Returns the reply JSON or null. */
    suspend fun reply(system: String, messages: JSONArray): JSONObject? {
        val contents = JSONArray()
        for (i in 0 until messages.length()) {
            val m = messages.getJSONObject(i)
            val role = if (m.optString("role") == "assistant") "model" else "user"
            contents.put(JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", m.optString("content")))))
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system + outputRules))))
            .put("contents", contents)
            .put(
                "generationConfig",
                JSONObject().put("responseMimeType", "application/json").put("responseSchema", JSONObject(schema)).put("maxOutputTokens", 4096),
            )
        return parseJson(textOf(post(body, 40)))
    }

    suspend fun text(system: String, user: String, maxTokens: Int): String {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", user)))))
            .put("generationConfig", JSONObject().put("maxOutputTokens", maxOf(maxTokens, 1024)))
        return textOf(post(body, 20))
    }
}

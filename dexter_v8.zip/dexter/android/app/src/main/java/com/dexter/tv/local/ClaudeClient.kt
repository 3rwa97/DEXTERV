package com.dexter.tv.local

import com.dexter.tv.data.ApiException
import com.dexter.tv.data.Prefs
import com.dexter.tv.data.objs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

const val ERR_BAD_CLAUDE = "BAD_CLAUDE"

/** Talks to Claude directly from the TV (only used in TV-only mode, with the key you typed in Settings). */
class ClaudeClient(private val prefs: Prefs, private val http: OkHttpClient) {
    fun enabled() = prefs.claudeKey.isNotBlank()

    private val model = "claude-sonnet-5-5"

    private val tool = """
    {
      "name": "dexter_reply",
      "description": "Send Dexter's reply to the viewer, with optional title suggestions.",
      "input_schema": {
        "type": "object",
        "properties": {
          "reply": {"type": "string", "description": "What Dexter says out loud. Warm, short (max ~55 words), no markdown, no emojis, easy to speak. Same language as the viewer."},
          "lang": {"type": "string", "enum": ["ar", "en"], "description": "Language of the reply."},
          "titles": {
            "type": "array", "maxItems": 20,
            "items": {
              "type": "object",
              "properties": {
                "title": {"type": "string", "description": "Official English or original title, exactly as listed on TMDB, so it can be looked up."},
                "year": {"type": "integer"},
                "type": {"type": "string", "enum": ["movie", "tv"]},
                "why": {"type": "string", "description": "One short sentence on why it fits this viewer, in the reply language. No spoilers."}
              },
              "required": ["title", "type"]
            }
          },
          "learn": {"type": "array", "maxItems": 3, "items": {"type": "string"}, "description": "Durable taste facts the viewer clearly stated this turn. Empty if none."},
          "open_app": {"type": "string", "description": "Only if the viewer asked to open an app: primevision, netflix, youtube, shahid, prime, disney."}
        },
        "required": ["reply", "lang"]
      }
    }
    """.trimIndent()

    private suspend fun post(body: JSONObject, readSeconds: Long): JSONObject = withContext(Dispatchers.IO) {
        val req = Request.Builder().url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", prefs.claudeKey.trim())
            .header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        try {
            http.newBuilder().readTimeout(readSeconds, TimeUnit.SECONDS).build().newCall(req).execute().use { r ->
                val text = r.body?.string().orEmpty()
                if (r.code == 401 || r.code == 403) throw ApiException(400, ERR_BAD_CLAUDE)
                if (!r.isSuccessful) throw ApiException(r.code, "Claude ${r.code}")
                JSONObject(text)
            }
        } catch (e: IOException) {
            throw ApiException(0, "network")
        }
    }

    /** One chat turn forced through the reply tool. Returns the tool input, or null if Claude gave nothing usable. */
    suspend fun reply(system: String, messages: JSONArray): JSONObject? {
        val body = JSONObject().put("model", model).put("max_tokens", 900).put("system", system).put("messages", messages)
            .put("tools", JSONArray().put(JSONObject(tool)))
            .put("tool_choice", JSONObject().put("type", "tool").put("name", "dexter_reply"))
        val j = post(body, 30)
        return j.optJSONArray("content").objs().firstOrNull { it.optString("type") == "tool_use" }?.optJSONObject("input")
    }

    suspend fun text(system: String, user: String, maxTokens: Int): String {
        val body = JSONObject().put("model", model).put("max_tokens", maxTokens).put("system", system)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
        val j = post(body, 15)
        return j.optJSONArray("content").objs().filter { it.optString("type") == "text" }.joinToString("") { it.optString("text") }.trim()
    }
}

package com.dexter.tv

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dexter.tv.data.*
import com.dexter.tv.ui.S
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.TimeZone

sealed interface Screen {
    object Boot : Screen
    object Login : Screen
    object Profiles : Screen
    object Home : Screen
    object Chat : Screen
    object Log : Screen
    object MyList : Screen
    object Vote : Screen
    object Settings : Screen
    object Mood : Screen
    data class ProfileEdit(val id: Long?) : Screen
    data class Detail(val type: String, val id: Long) : Screen
}

/** A PIN pad request. [verify] throws ApiException(403) when wrong; [onOk] receives the PIN that was entered. */
class PinPrompt(val title: String, val verify: suspend (String) -> Unit, val onOk: (String) -> Unit)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)
    val voice = Voice(app)
    private val remote = Api(prefs) { viewModelScope.launch { localSignOut() } }
    private val local = com.dexter.tv.local.LocalBackend(app, prefs)
    /** Server mode or TV-only mode: the screens don't care which one they talk to. */
    val api: Backend get() = if (prefs.localMode) local else remote

    // ---------- navigation ----------
    val stack = mutableStateListOf<Screen>(Screen.Boot)
    val screen: Screen get() = stack.last()
    fun go(s: Screen) { stack.add(s) }
    fun back(): Boolean {
        if (stack.size > 1) { stack.removeAt(stack.lastIndex); return true }
        return false
    }
    private fun root(s: Screen) { stack.clear(); stack.add(s) }
    private fun setTab(s: Screen) { stack.clear(); stack.add(Screen.Home); if (s != Screen.Home) stack.add(s) }
    fun tab(s: Screen) { if (s == Screen.Settings) guard { setTab(s) } else setTab(s) }

    // ---------- global state ----------
    var me by mutableStateOf<Me?>(null)
    var profiles by mutableStateOf<List<Profile>>(emptyList())
    var profile by mutableStateOf<Profile?>(null)
    var message by mutableStateOf<String?>(null)
    private var uiLangState by mutableStateOf(prefs.uiLang)
    val lang: String get() = profile?.lang ?: uiLangState
    fun s(key: String) = S.get(lang, key)

    var voiceOn by mutableStateOf(prefs.voiceOn)
    var autoBrief by mutableStateOf(prefs.autoBrief)
    var primePkg by mutableStateOf(prefs.primePkg)
    var primeLink by mutableStateOf(prefs.primeLink)
    var serverUrl by mutableStateOf(prefs.server)
    var localMode by mutableStateOf(prefs.localMode)
    var tmdbKey by mutableStateOf(prefs.tmdbKey)
    var claudeKey by mutableStateOf(prefs.claudeKey)
    var geminiKey by mutableStateOf(prefs.geminiKey)
    val primeReady: Boolean get() = primePkg.isNotBlank()

    private var toastJob: Job? = null
    fun toast(t: String) {
        message = t
        toastJob?.cancel()
        toastJob = viewModelScope.launch { delay(3500); message = null }
    }
    private fun errText(e: ApiException) = when {
        e.message == "NEED_TMDB" -> s("need_tmdb")
        e.message == "BAD_TMDB" -> s("bad_tmdb")
        e.message == "BAD_CLAUDE" -> s("bad_claude")
        e.status == 0 -> s("err_net")
        else -> e.message ?: s("err_net")
    }

    init {
        voice.onResult = { onVoiceResult(it) }
        voice.onFail = {
            toast(
                s(
                    when (it) {
                        VoiceError.NO_RECOGNIZER -> "err_no_stt"
                        VoiceError.NETWORK -> "err_net"
                        VoiceError.BUSY -> "err_busy"
                        VoiceError.TTS_LANGUAGE -> "err_tts"
                        else -> "err_didnt_catch"
                    },
                ),
            )
        }
    }

    // ---------- boot & login ----------
    var bootError by mutableStateOf<String?>(null)
    var login by mutableStateOf<DeviceLogin?>(null)
    var qr by mutableStateOf<Bitmap?>(null)
    var loginError by mutableStateOf<String?>(null)
    var loginExpired by mutableStateOf(false)
    private var pollJob: Job? = null

    private var booted = false
    fun bootOnce() { if (!booted) { booted = true; boot() } }

    fun boot() {
        bootError = null
        viewModelScope.launch {
            // This TV only: no account and no sign-in screen. The first launch goes straight into the app.
            if (prefs.token == null) { enterLocalMode(); return@launch }
            try {
                me = api.me()
                profiles = api.profiles()
                val saved = profiles.firstOrNull { it.id == prefs.profileId }
                if (saved != null && !saved.hasPin) enterProfile(saved) else root(Screen.Profiles)
            } catch (e: ApiException) {
                if (e.status != 401) bootError = errText(e)
            }
        }
    }

    fun startLogin() {
        pollJob?.cancel()
        loginError = null; loginExpired = false; login = null; qr = null
        pollJob = viewModelScope.launch {
            try {
                val d = api.deviceStart(prefs.deviceName)
                login = d
                qr = withContext(Dispatchers.Default) { Qr.make(d.verifyUrl) }
                val deadline = System.currentTimeMillis() + d.expiresIn * 1000L
                while (isActive && System.currentTimeMillis() < deadline) {
                    delay(3000)
                    var tok: String? = null
                    try { tok = api.devicePoll(d.deviceCode) } catch (e: ApiException) {
                        if (e.status == 410) { loginExpired = true; return@launch }
                    }
                    if (tok != null) { prefs.token = tok; boot(); return@launch }
                }
                if (isActive) loginExpired = true
            } catch (e: ApiException) {
                loginError = errText(e)
            }
        }
    }

    /** Use Dexter on this TV only: no server, no account. */
    fun enterLocalMode() {
        pollJob?.cancel()
        prefs.localMode = true
        localMode = true
        prefs.token = "local"
        boot()
    }

    fun setTmdbKey(k: String) {
        prefs.tmdbKey = k; tmdbKey = prefs.tmdbKey
        local.clearCaches(); prefs.cacheClear(); homeDirty = true; briefing = null
        viewModelScope.launch { try { me = api.me() } catch (_: ApiException) { } }
        toast(s("saved"))
    }

    fun setClaudeKey(k: String) {
        prefs.claudeKey = k; claudeKey = prefs.claudeKey
        local.clearCaches(); briefing = null
        viewModelScope.launch { try { me = api.me() } catch (_: ApiException) { } }
        toast(s("saved"))
    }

    fun setGeminiKey(k: String) {
        prefs.geminiKey = k; geminiKey = prefs.geminiKey
        local.clearCaches(); briefing = null
        viewModelScope.launch { try { me = api.me() } catch (_: ApiException) { } }
        toast(s("saved"))
    }

    fun setLoginLang(l: String) { uiLangState = l; prefs.uiLang = l }

    fun changeServer(url: String) {
        prefs.server = url
        serverUrl = prefs.server
        if (screen == Screen.Login) startLogin() else toast(s("saved"))
    }

    private fun localSignOut() {
        if (prefs.token == null && screen == Screen.Login) return
        prefs.token = null; prefs.profileId = 0; prefs.cacheClear()
        prefs.localMode = false; localMode = false
        inboxJob?.cancel(); voice.stopSpeaking()
        profile = null; profiles = emptyList(); me = null
        rows = emptyList(); briefing = null; chat.clear(); chatLoaded = false
        root(Screen.Login)
        startLogin()
    }

    fun signOut() {
        viewModelScope.launch {
            try { api.logout() } catch (_: ApiException) { }
            localSignOut()
        }
    }

    // ---------- profiles & pins ----------
    var pinPrompt by mutableStateOf<PinPrompt?>(null)
    var pinError by mutableStateOf<String?>(null)
    var pinErrorCount by mutableStateOf(0)

    private fun ask(p: PinPrompt) { pinError = null; pinPrompt = p }
    fun cancelPin() { pinPrompt = null; pinError = null }
    fun submitPin(pin: String) {
        val p = pinPrompt ?: return
        viewModelScope.launch {
            try {
                p.verify(pin)
                pinPrompt = null; pinError = null
                p.onOk(pin)
            } catch (e: ApiException) {
                pinError = if (e.status == 403) s("wrong_pin") else errText(e)
                pinErrorCount++
            }
        }
    }

    /** Runs [action] right away, or after the parent PIN when a kids profile is active and a PIN exists. */
    fun guard(action: () -> Unit) {
        if (profile?.isKid == true && me?.hasParentPin == true) ask(PinPrompt(s("enter_parent_pin"), { api.verifyParentPin(it) }) { action() }) else action()
    }

    /** Asks for the parent PIN when one exists, then hands it to [onOk] (null when none is set). */
    fun withParentPin(onOk: (String?) -> Unit) {
        if (me?.hasParentPin == true) ask(PinPrompt(s("enter_parent_pin"), { api.verifyParentPin(it) }) { onOk(it) }) else onOk(null)
    }

    fun changeParentPin() {
        fun askNew(cur: String?) {
            ask(
                PinPrompt(s("new_pin"), { }) { new ->
                    viewModelScope.launch {
                        try { api.setParentPin(new, cur); me = me?.copy(hasParentPin = true); toast(s("saved")) } catch (e: ApiException) { toast(errText(e)) }
                    }
                },
            )
        }
        if (me?.hasParentPin == true) ask(PinPrompt(s("enter_parent_pin"), { api.verifyParentPin(it) }) { askNew(it) }) else askNew(null)
    }

    /** Asks for a fresh 4-digit PIN (used for per-profile PINs). */
    fun askNewPin(onPin: (String) -> Unit) { ask(PinPrompt(s("new_pin"), { }) { onPin(it) }) }

    fun pickProfile(p: Profile) {
        if (p.hasPin) ask(PinPrompt(s("enter_pin"), { api.verifyProfilePin(p.id, it) }) { enterProfile(p) }) else enterProfile(p)
    }

    fun requestSwitchProfile() {
        guard {
            inboxJob?.cancel(); voice.stopSpeaking(); voice.stopListening()
            profile = null
            root(Screen.Profiles)
        }
    }

    fun enterProfile(p: Profile) {
        prefs.profileId = p.id
        profile = p
        rows = emptyList(); briefing = null; chat.clear(); chatLoaded = false; detail = null
        moodReply = null; moodItems = emptyList(); moodSel = null
        root(Screen.Home)
        loadHome()
        loadBriefing(autoSpeak = prefs.autoBrief)
        startInbox()
        if (prefs.localMode && prefs.tmdbKey.isBlank()) { setTab(Screen.Settings); toast(s("need_tmdb")) }
    }

    fun saveProfile(id: Long?, body: JSONObject, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            try {
                val p = api.saveProfile(id, body)
                profiles = if (id == null) profiles + p else profiles.map { if (it.id == p.id) p else it }
                if (profile?.id == p.id) { profile = p; homeDirty = true; briefing = null }
                toast(s("saved"))
                onDone()
            } catch (e: ApiException) { toast(errText(e)) }
        }
    }

    fun deleteProfile(id: Long) {
        withParentPin { pin ->
            viewModelScope.launch {
                try { api.deleteProfile(id, pin); profiles = profiles.filter { it.id != id }; back() } catch (e: ApiException) { toast(errText(e)) }
            }
        }
    }

    fun setLanguage(l: String) {
        val p = profile ?: return
        saveProfile(p.id, JSONObject().put("lang", l)) { loadHome(); loadBriefing() }
    }

    fun setSpoilerSafe(v: Boolean) { profile?.let { saveProfile(it.id, JSONObject().put("spoilerSafe", v)) } }
    fun setVoiceOn(v: Boolean) { voiceOn = v; prefs.voiceOn = v; if (!v) voice.stopSpeaking() }
    fun setAutoBrief(v: Boolean) { autoBrief = v; prefs.autoBrief = v }
    fun setPrimePkg(v: String) { prefs.primePkg = v; primePkg = prefs.primePkg }
    fun setPrimeLink(v: String) { prefs.primeLink = v; primeLink = prefs.primeLink }

    // ---------- home & briefing ----------
    var rows by mutableStateOf<List<HomeRow>>(emptyList())
    var homeLoading by mutableStateOf(false)
    var homeError by mutableStateOf<String?>(null)
    var homeDirty by mutableStateOf(false)
    var briefing by mutableStateOf<Briefing?>(null)
    var briefingLoading by mutableStateOf(false)

    fun loadHome() {
        val pid = prefs.profileId
        if (pid <= 0) return
        homeDirty = false
        viewModelScope.launch {
            val key = "home_$pid"
            if (rows.isEmpty()) {
                val cached = withContext(Dispatchers.IO) { prefs.cacheGet(key) }
                if (cached != null) try { rows = withContext(Dispatchers.Default) { parseRows(JSONObject(cached)) } } catch (_: Exception) { }
            }
            homeLoading = rows.isEmpty()
            homeError = null
            try {
                val j = api.homeRaw()
                rows = withContext(Dispatchers.Default) { parseRows(j) }
                launch(Dispatchers.IO) { prefs.cachePut(key, j.toString()) }
            } catch (e: ApiException) {
                if (rows.isEmpty()) homeError = errText(e)
            }
            homeLoading = false
        }
    }

    fun loadBriefing(autoSpeak: Boolean = false) {
        viewModelScope.launch {
            briefingLoading = true
            try {
                val j = api.briefingRaw(TimeZone.getDefault().id)
                briefing = withContext(Dispatchers.Default) { parseBriefing(j) }
                if (autoSpeak && voiceOn) speakBriefing()
            } catch (_: ApiException) { }
            briefingLoading = false
        }
    }

    private fun speakBriefing() { briefing?.let { voice.speak("${it.greeting}. ${it.text}") } }

    fun playBriefing() {
        when {
            voice.speaking.value -> voice.stopSpeaking()
            briefing != null -> speakBriefing()
            else -> loadBriefing(autoSpeak = true)
        }
    }

    // ---------- voice ----------
    var needMic by mutableStateOf(false)
    var voiceLangMode by mutableStateOf("auto") // auto | ar | en
    fun cycleVoiceLang() { voiceLangMode = when (voiceLangMode) { "auto" -> "ar"; "ar" -> "en"; else -> "auto" } }
    private fun voiceLangCode() = if (voiceLangMode == "auto") lang else voiceLangMode

    private fun hasMic() = ContextCompat.checkSelfPermission(getApplication(), Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    private val voiceAllowed: Boolean get() = profile != null && screen !is Screen.Boot && screen !is Screen.Login && screen !is Screen.Profiles

    fun micPermissionResult(granted: Boolean) {
        needMic = false
        if (granted) startMic() else toast(s("err_mic_perm"))
    }

    fun startMic() {
        if (!voiceAllowed) return
        if (!hasMic()) { needMic = true; return }
        voice.startListening(voiceLangCode())
    }

    fun toggleMic() { if (voice.listening.value) voice.stopListening() else startMic() }

    private fun onVoiceResult(text: String) {
        if (handleCommand(text)) return
        if (screen == Screen.Mood) { runMood(text); return }
        if (screen != Screen.Chat) setTab(Screen.Chat)
        sendChat(text)
    }

    /** A few spoken shortcuts that don't need the AI. Everything else goes to Dexter. */
    private fun handleCommand(text: String): Boolean {
        val t = text.lowercase().trim()
        fun has(vararg w: String) = w.any { t.contains(it) }
        when {
            has("briefing", "brief me", "good morning", "ملخص", "نشرة", "صباح الخير") -> { setTab(Screen.Home); playBriefing() }
            has("settings", "الإعدادات", "الاعدادات") -> tab(Screen.Settings)
            has("my list", "watchlist", "قائمتي", "قائمة المشاهدة") -> setTab(Screen.MyList)
            has("family vote", "تصويت") -> setTab(Screen.Vote)
            has("go home", "home screen", "الرئيسية") -> setTab(Screen.Home)
            has("primevision", "prime vision", "برايم فيجن", "برايم فيجين") -> openPrime(null)
            else -> return false
        }
        return true
    }

    // ---------- mood ----------
    var moodSel by mutableStateOf<String?>(null)
    var moodReply by mutableStateOf<String?>(null)
    var moodItems by mutableStateOf<List<Item>>(emptyList())
    var moodBusy by mutableStateOf(false)

    /** True while Dexter is working on an answer (the animated orb swirls). */
    val thinking: Boolean get() = chatBusy || moodBusy

    fun runMood(text: String, id: String? = null, genres: List<Int> = emptyList(), all: Boolean = false) {
        val t = text.trim()
        if (t.isEmpty() || moodBusy) return
        voice.stopSpeaking()
        moodSel = id
        moodReply = null; moodItems = emptyList(); moodBusy = true
        viewModelScope.launch {
            try {
                val r = api.mood(t, TimeZone.getDefault().id, genres, all)
                moodReply = r.reply; moodItems = r.titles
                if (voiceOn) voice.speak(r.reply)
            } catch (e: ApiException) {
                moodReply = errText(e)
            }
            moodBusy = false
        }
    }

    /** From the Home mood strip: jump to the Mood tab and run that mood. */
    fun pickMood(prompt: String, id: String, genres: List<Int>, all: Boolean) { setTab(Screen.Mood); runMood(prompt, id, genres, all) }

    // ---------- chat ----------
    val chat = mutableStateListOf<ChatMsg>()
    var chatBusy by mutableStateOf(false)
    private var chatLoaded = false
    private var localId = -1L
    private fun nextLocal() = localId--

    fun loadChat() {
        if (chatLoaded) return
        chatLoaded = true
        viewModelScope.launch {
            try { chat.clear(); chat.addAll(api.chatLog(limit = 40)) } catch (e: ApiException) { toast(errText(e)) }
            if (chat.isEmpty()) chat.add(ChatMsg(nextLocal(), "assistant", s("hello_msg")))
        }
    }

    fun sendChat(text: String) {
        val t = text.trim()
        if (t.isEmpty() || chatBusy) return
        voice.stopSpeaking()
        chat.add(ChatMsg(nextLocal(), "user", t))
        chatBusy = true
        viewModelScope.launch {
            try {
                val r = api.chat(t, TimeZone.getDefault().id)
                chat.add(ChatMsg(nextLocal(), "assistant", r.reply, r.titles))
                if (voiceOn) voice.speak(r.reply)
                r.openApp?.let { name ->
                    if (!Launcher.openByName(getApplication(), prefs, name)) toast(s(if (name.lowercase().contains("prime") && !primeReady) "prime_missing" else "app_missing"))
                }
            } catch (e: ApiException) {
                chat.add(ChatMsg(nextLocal(), "assistant", errText(e)))
            }
            chatBusy = false
        }
    }

    var logItems by mutableStateOf<List<ChatMsg>>(emptyList())
    var logQuery by mutableStateOf("")
    fun searchLog(q: String) {
        logQuery = q
        viewModelScope.launch { try { logItems = api.chatLog(q.ifBlank { null }, 100) } catch (e: ApiException) { toast(errText(e)) } }
    }

    fun clearLog() {
        viewModelScope.launch {
            try { api.clearLog(); chat.clear(); chatLoaded = false; logItems = emptyList(); toast(s("saved")) } catch (e: ApiException) { toast(errText(e)) }
        }
    }

    // ---------- detail ----------
    var detail by mutableStateOf<Detail?>(null)
    var detailError by mutableStateOf<String?>(null)
    var whyText by mutableStateOf<String?>(null)
    var whyBusy by mutableStateOf(false)

    fun loadDetail(type: String, id: Long) {
        detail = null; detailError = null; whyText = null
        viewModelScope.launch {
            try { detail = api.title(type, id) } catch (e: ApiException) { detailError = errText(e) }
        }
    }

    fun updateLib(d: Detail, watchlist: Boolean? = null, watched: Boolean? = null, reaction: Int? = null) {
        val old = d.state
        var next = old.copy(watchlist = watchlist ?: old.watchlist, watched = watched ?: old.watched, reaction = reaction ?: old.reaction)
        if (watched == true && watchlist == null) next = next.copy(watchlist = false)
        detail = d.copy(state = next)
        viewModelScope.launch {
            try {
                val st = api.setLibrary(d.item, watchlist, watched, reaction)
                val cur = detail
                if (cur != null && cur.item.id == d.item.id) detail = cur.copy(state = st)
                homeDirty = true
                briefing = null
            } catch (e: ApiException) {
                val cur = detail
                if (cur != null && cur.item.id == d.item.id) detail = cur.copy(state = old)
                toast(errText(e))
            }
        }
    }

    fun explain(d: Detail) {
        if (whyBusy) return
        whyBusy = true
        viewModelScope.launch {
            try {
                val t = api.why(d.item.type, d.item.id)
                whyText = t
                if (voiceOn) voice.speak(t)
            } catch (e: ApiException) { toast(errText(e)) }
            whyBusy = false
        }
    }

    fun openProvider(p: Provider, title: String) {
        if (Launcher.openPackage(getApplication(), p.pkg)) toast("${s("search_there")}: $title") else toast(s("app_missing"))
    }

    fun openPrime(title: String?) {
        if (!Launcher.primeConfigured(prefs)) { toast(s("prime_missing")); return }
        if (Launcher.openPrimeVision(getApplication(), prefs, title)) { if (title != null) toast("${s("search_there")}: $title") } else toast(s("prime_fail"))
    }

    fun openTrailerExternally(key: String) { if (!Launcher.openYouTube(getApplication(), key)) toast(s("app_missing")) }

    // ---------- my list ----------
    var listFilter by mutableStateOf("watchlist")
    var listItems by mutableStateOf<List<Item>>(emptyList())
    var listLoading by mutableStateOf(false)
    fun loadList(filter: String) {
        listFilter = filter
        listLoading = true
        viewModelScope.launch {
            try { listItems = api.library(filter) } catch (e: ApiException) { toast(errText(e)) }
            listLoading = false
        }
    }

    // ---------- family vote ----------
    val voteSel = mutableStateListOf<Long>()
    var voteItems by mutableStateOf<List<Item>?>(null)
    var voteKids by mutableStateOf(false)
    var voteBusy by mutableStateOf(false)
    fun toggleVote(id: Long) { if (voteSel.contains(id)) voteSel.remove(id) else voteSel.add(id) }
    fun runVote() {
        if (voteSel.isEmpty() || voteBusy) return
        voteBusy = true
        viewModelScope.launch {
            try { val (items, kids) = api.vote(voteSel.toList()); voteItems = items; voteKids = kids } catch (e: ApiException) { toast(errText(e)) }
            voteBusy = false
        }
    }

    // ---------- phone -> TV ----------
    private var inboxJob: Job? = null
    private fun startInbox() {
        inboxJob?.cancel()
        inboxJob = viewModelScope.launch {
            while (isActive) {
                delay(15_000)
                try {
                    api.inbox().lastOrNull()?.let {
                        toast("${s("from_phone")}: ${it.title}")
                        go(Screen.Detail(it.type, it.id))
                    }
                } catch (_: ApiException) { }
            }
        }
    }

    override fun onCleared() {
        voice.destroy()
        super.onCleared()
    }
}

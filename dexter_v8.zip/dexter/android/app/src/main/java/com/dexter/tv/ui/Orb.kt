package com.dexter.tv.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.dexter.tv.AppViewModel
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class OrbMode { Idle, Listening, Thinking, Speaking }

/**
 * A soft, glowing orb of drifting colour blobs, in the spirit of Siri.
 * Listening: it swells with the loudness of your voice. Thinking: the colours swirl wider.
 * Speaking: it breathes. [level] is the microphone loudness from 0 to 1.
 */
@Composable
fun SiriOrb(mode: OrbMode, level: Float, modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "orb")
    // Whole turns only (multipliers below are integers), so the loop never jumps.
    val t by inf.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(8000, easing = LinearEasing)), label = "t")
    val breathe by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "breathe")
    val lvl by animateFloatAsState(level, tween(80), label = "lvl")
    val colors = listOf(C.Cyan, C.Accent, C.Pink, Color(0xFFFFD36B))

    Canvas(modifier) {
        val base = size.minDimension / 2f
        val amp = when (mode) {
            OrbMode.Listening -> 0.05f + 0.22f * lvl + 0.03f * breathe
            OrbMode.Speaking -> 0.06f + 0.12f * breathe
            OrbMode.Thinking -> 0.04f + 0.04f * breathe
            OrbMode.Idle -> 0.03f * breathe
        }
        val swirl = if (mode == OrbMode.Thinking) 0.34f else 0.22f
        val r = base * (0.5f + amp)
        val c = center

        // outer halo
        drawCircle(Brush.radialGradient(listOf(C.Accent.copy(alpha = 0.30f), Color.Transparent), c, base), base, c)

        for (i in colors.indices) {
            val dir = if (i % 2 == 0) 1 else -1
            val a = t * dir * (1 + i / 2) + i * 1.5708f
            val p = Offset(c.x + cos(a) * r * swirl, c.y + sin(a) * r * swirl * 0.85f)
            val br = r * 1.05f
            drawCircle(
                Brush.radialGradient(listOf(colors[i].copy(alpha = 0.95f), colors[i].copy(alpha = 0f)), p, br),
                br, p, blendMode = BlendMode.Plus,
            )
        }
        // bright core
        drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.55f), Color.Transparent), c, r * 0.55f), r * 0.55f, c, blendMode = BlendMode.Plus)
    }
}

/** Shown on every screen while Dexter listens, thinks or speaks: the orb sits at the bottom, with the words above it. */
@Composable
fun VoiceOverlay(vm: AppViewModel) {
    val listening by vm.voice.listening.collectAsState()
    val speaking by vm.voice.speaking.collectAsState()
    val partial by vm.voice.partial.collectAsState()
    val level by vm.voice.level.collectAsState()
    val thinking = vm.thinking
    val mode = when {
        listening -> OrbMode.Listening
        speaking -> OrbMode.Speaking
        thinking -> OrbMode.Thinking
        else -> OrbMode.Idle
    }
    AnimatedVisibility(
        visible = mode != OrbMode.Idle,
        modifier = Modifier.fillMaxSize(),
        enter = fadeIn(tween(250)) + scaleIn(tween(300), initialScale = 0.5f, transformOrigin = TransformOrigin(0.5f, 1f)),
        exit = fadeOut(tween(250)) + scaleOut(tween(250), targetScale = 0.5f, transformOrigin = TransformOrigin(0.5f, 1f)),
    ) {
        Box(Modifier.fillMaxSize()) {
            Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(170.dp)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD05050A)))),
            )
            Column(Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                val line = when (mode) {
                    OrbMode.Listening -> partial.ifBlank { tr("hint_listen") }
                    OrbMode.Thinking -> tr("thinking")
                    else -> ""
                }
                if (line.isNotBlank()) T(line, 15, Color(0xFFEDEDF7), FontWeight.SemiBold, Modifier.padding(horizontal = 60.dp), maxLines = 2, align = TextAlign.Center)
                SiriOrb(mode, level, Modifier.size(120.dp))
            }
        }
    }
}

@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.dexter.tv.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.dexter.tv.AppViewModel
import com.dexter.tv.Screen
import com.dexter.tv.data.Profile
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

const val CREATOR_NAME = "Orwa Shoura"
const val CREATOR_EMAIL = "orwashoura@gmail.com"

@Composable
fun CreditLine(modifier: Modifier = Modifier, align: TextAlign = TextAlign.Unspecified) {
    T("${tr("created_by")} $CREATOR_NAME  ·  $CREATOR_EMAIL", 11, C.Muted, modifier = modifier, align = align, maxLines = 1)
}

/** A full-width settings-style row: title on one side, current value on the other. */
@Composable
fun SettingRow(title: String, value: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Focusable(onClick, modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp), color = C.Panel, focusColor = C.Panel2, scale = 1.02f) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            T(title, 14, weight = FontWeight.Medium, modifier = Modifier.weight(1f), maxLines = 1)
            Spacer(Modifier.width(12.dp))
            T(value, 13, C.Muted, maxLines = 1, modifier = Modifier.weight(1f), align = TextAlign.End)
        }
    }
}

@Composable
fun BootScreen(vm: AppViewModel) {
    Centered {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            T("Dexter", 44, weight = FontWeight.ExtraBold)
            val err = vm.bootError
            if (err == null) T(tr("connecting"), 14, C.Muted) else {
                T(err, 14, C.Danger, align = TextAlign.Center)
                DButton(tr("retry"), { vm.boot() }, primary = true)
                DButton(tr("server") + ": " + vm.serverUrl, { vm.go(Screen.Login) })
            }
        }
    }
}

@Composable
fun LoginScreen(vm: AppViewModel) {
    var serverDialog by remember { mutableStateOf(false) }
    // Everything inside the safe area: 48dp left/right and 27dp top/bottom on the 960x540 design canvas.
    Row(
        Modifier.fillMaxSize().padding(horizontal = SafeH, vertical = SafeV),
        horizontalArrangement = Arrangement.spacedBy(36.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.padding(top = 36.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(46.dp).clip(CircleShape).background(C.Accent), contentAlignment = Alignment.Center) { T("▶", 20, Color.White) }
                    Spacer(Modifier.width(12.dp))
                    T("Dexter", 54, weight = FontWeight.ExtraBold)
                }
                T(tr("tagline"), 17, C.Muted)
                Spacer(Modifier.height(18.dp))
                T(tr("login_title"), 20, weight = FontWeight.Bold)
                listOf("login_s1", "login_s2", "login_s3").forEachIndexed { i, k ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(Modifier.size(22.dp).clip(CircleShape).background(C.Panel2), contentAlignment = Alignment.Center) { T("${i + 1}", 12, C.Accent, FontWeight.Bold) }
                        T(tr(k), 14, Color(0xFFD6D6E2), modifier = Modifier.weight(1f))
                    }
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DChip("English", vm.lang == "en", { vm.setLoginLang("en") })
                    DChip("العربية", vm.lang == "ar", { vm.setLoginLang("ar") })
                    DChip(tr("server") + ": " + vm.serverUrl.removePrefix("http://").removePrefix("https://"), false, { serverDialog = true })
                }
                DButton(tr("local_mode"), { vm.enterLocalMode() }, primary = true)
                T(tr("local_hint"), 12, C.Muted, maxLines = 2)
                CreditLine()
            }
        }

        // Code + QR card. The code sits ABOVE the QR; the card is only ~380dp tall inside a 486dp safe area, so nothing is cropped.
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Column(
                Modifier.width(300.dp).clip(RoundedCornerShape(20.dp)).background(C.Panel).border(1.dp, C.Line, RoundedCornerShape(20.dp)).padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                val l = vm.login
                T(tr("your_code"), 13, C.Muted, FontWeight.Medium)
                Spacer(Modifier.height(2.dp))
                T(l?.userCode?.chunked(3)?.joinToString(" ") ?: "···  ···", 44, C.Text, FontWeight.ExtraBold, spacing = 3f, maxLines = 1, align = TextAlign.Center)
                Spacer(Modifier.height(10.dp))
                // Smaller QR placeholder when there is an error, so the error text and buttons always fit inside the safe area.
                val qrSize = if (vm.loginError != null) 96.dp else 196.dp
                Box(Modifier.size(qrSize).clip(RoundedCornerShape(12.dp)).background(Color.White).padding(4.dp), contentAlignment = Alignment.Center) {
                    val bmp = vm.qr
                    if (bmp != null && !vm.loginExpired) Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), filterQuality = FilterQuality.None)
                    else T(if (vm.loginExpired) "⟳" else "…", 40, Color(0xFF888888))
                }
                Spacer(Modifier.height(8.dp))
                T(l?.verifyUrl?.removePrefix("http://")?.removePrefix("https://") ?: "", 10, C.Muted, align = TextAlign.Center, maxLines = 2)
                Spacer(Modifier.height(8.dp))
                when {
                    vm.loginError != null -> {
                        T(vm.loginError ?: "", 12, C.Danger, align = TextAlign.Center)
                        // Show exactly which address was tried: a wrong IP is the usual cause.
                        T(vm.serverUrl, 12, C.Text, FontWeight.SemiBold, align = TextAlign.Center, maxLines = 2)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            DButton(tr("retry"), { vm.startLogin() }, primary = true, size = 12)
                            DButton(tr("change_server"), { serverDialog = true }, size = 12)
                        }
                    }
                    vm.loginExpired -> DButton(tr("new_code"), { vm.startLogin() }, primary = true)
                    else -> T(tr("waiting"), 12, C.Green, FontWeight.Medium)
                }
            }
        }
    }
    if (serverDialog) {
        TextInputDialog(tr("server_addr"), vm.serverUrl, "http://192.168.1.50:8787", onDone = { serverDialog = false; vm.changeServer(it) }, onCancel = { serverDialog = false })
    }
}

@Composable
fun ProfilesScreen(vm: AppViewModel) {
    val cards: List<Profile?> = vm.profiles + (if (vm.profiles.size < 8) listOf<Profile?>(null) else emptyList())
    val first = remember { FocusRequester() }
    LaunchedEffect(cards.size) { delay(200); try { first.requestFocus() } catch (_: Exception) { } }
    Column(Modifier.fillMaxSize().padding(horizontal = SafeH, vertical = SafeV), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.weight(1f))
        T(tr("whos"), 30, weight = FontWeight.ExtraBold)
        Spacer(Modifier.height(22.dp))
        cards.chunked(4).forEachIndexed { rowIdx, rowCards ->
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                rowCards.forEachIndexed { i, p ->
                    val m = if (rowIdx == 0 && i == 0) Modifier.focusRequester(first) else Modifier
                    if (p != null) {
                        Focusable({ vm.pickProfile(p) }, m.width(130.dp), RoundedCornerShape(18.dp), Color.Transparent, C.Panel2, scale = 1.06f) {
                            Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Avatar(p.name, p.color, 80.dp)
                                Spacer(Modifier.height(8.dp))
                                T(p.name, 15, weight = FontWeight.SemiBold, maxLines = 1)
                                T(if (p.isKid) "🧒 " + tr("kid") else if (p.hasPin) "🔒" else " ", 11, C.Muted)
                            }
                        }
                    } else {
                        Focusable({ vm.go(Screen.ProfileEdit(null)) }, m.width(130.dp), RoundedCornerShape(18.dp), Color.Transparent, C.Panel2, scale = 1.06f) {
                            Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(Modifier.size(80.dp).clip(CircleShape).background(C.Panel2), contentAlignment = Alignment.Center) { T("+", 40, C.Muted) }
                                Spacer(Modifier.height(8.dp))
                                T(tr("add_profile"), 14, C.Muted, FontWeight.Medium, maxLines = 1)
                                T(" ", 11)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
        }
        Spacer(Modifier.weight(1f))
        CreditLine()
    }
}

private val GENRES = listOf("comedy", "drama", "action", "thriller", "horror", "romance", "sci-fi", "animation", "crime", "documentary", "fantasy", "mystery", "adventure", "family")
private val SERVICES = listOf("Netflix", "Shahid", "Amazon Prime Video", "Disney Plus", "OSN+", "YouTube", "Apple TV", "Max", "Viu", "StarzPlay")

@Composable
fun ProfileEditScreen(vm: AppViewModel, id: Long?) {
    val existing = remember(id) { vm.profiles.firstOrNull { it.id == id } }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var favs by remember { mutableStateOf(existing?.favorites ?: emptyList()) }
    var kid by remember { mutableStateOf(existing?.isKid ?: false) }
    var lang by remember { mutableStateOf(existing?.lang ?: vm.lang) }
    var genres by remember { mutableStateOf((existing?.genres ?: emptyList()).toSet()) }
    var services by remember { mutableStateOf((existing?.services ?: emptyList()).toSet()) }
    var newPin by remember { mutableStateOf<String?>(null) } // null = unchanged, "" = remove
    var dialog by remember { mutableStateOf<String?>(null) }

    fun save() {
        if (name.isBlank()) { dialog = "name"; return }
        val body = JSONObject()
            .put("name", name.trim()).put("lang", lang).put("isKid", kid)
            .put("favorites", JSONArray(favs)).put("genres", JSONArray(genres.toList())).put("services", JSONArray(services.toList()))
        newPin?.let { body.put("pin", if (it.isEmpty()) JSONObject.NULL else it) }
        val go = { vm.saveProfile(existing?.id, body) { vm.back() } }
        if (existing != null && existing.isKid != kid) vm.withParentPin { pin -> body.put("parentPin", pin ?: ""); go() } else go()
    }

    Column(Modifier.fillMaxSize().background(C.Bg).padding(horizontal = SafeH, vertical = SafeV)) {
        Row(Modifier.fillMaxWidth().height(44.dp), verticalAlignment = Alignment.CenterVertically) {
            T(if (existing == null) tr("add_profile") else tr("edit_profile"), 22, weight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
            DButton(tr("save"), { save() }, primary = true)
            Spacer(Modifier.width(8.dp))
            DButton(tr("cancel"), { vm.back() })
            if (existing != null && vm.profiles.size > 1) {
                Spacer(Modifier.width(8.dp))
                DButton(tr("delete"), { vm.deleteProfile(existing.id) })
            }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 6.dp)) {
            item { SettingRow(tr("name"), name.ifBlank { "—" }, { dialog = "name" }) }
            item { SettingRow(tr("fav"), favs.joinToString(", ").ifBlank { "—" }, { dialog = "favs" }) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    T(tr("set_lang"), 13, C.Muted, modifier = Modifier.width(90.dp))
                    DChip("English", lang == "en", { lang = "en" })
                    DChip("العربية", lang == "ar", { lang = "ar" })
                    Spacer(Modifier.width(14.dp))
                    DChip("🧒 " + tr("kid_mode"), kid, { kid = !kid })
                }
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    T(tr("genres"), 13, C.Muted)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        GENRES.forEach { g -> DChip(tr("g_$g"), g in genres, { genres = if (g in genres) genres - g else genres + g }) }
                    }
                }
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    T(tr("services"), 13, C.Muted)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SERVICES.forEach { s -> DChip(s, s in services, { services = if (s in services) services - s else services + s }) }
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    T(tr("profile_pin"), 13, C.Muted, modifier = Modifier.width(150.dp))
                    val hasPin = (newPin ?: if (existing?.hasPin == true) "set" else "").isNotEmpty()
                    DButton(if (hasPin) "●●●●" else tr("not_set"), { vm.askNewPin { newPin = it } })
                    if (hasPin) DButton("✕", { newPin = "" })
                }
            }
        }
    }
    when (dialog) {
        "name" -> TextInputDialog(tr("name"), name, onDone = { name = it.trim(); dialog = null }, onCancel = { dialog = null })
        "favs" -> TextInputDialog(tr("fav"), favs.joinToString(", "), tr("fav_hint"), onDone = { v -> favs = v.split(",", "،").map { it.trim() }.filter { it.isNotEmpty() }.take(30); dialog = null }, onCancel = { dialog = null })
    }
}

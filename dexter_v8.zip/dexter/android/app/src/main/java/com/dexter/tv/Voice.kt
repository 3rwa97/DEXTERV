package com.dexter.tv

import android.app.Application
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.Locale

/** Error kinds reported to the UI (which shows a localized message). */
enum class VoiceError { NO_RECOGNIZER, DIDNT_CATCH, NETWORK, BUSY, TTS_LANGUAGE, OTHER }

/**
 * Speech in (remote-control mic through the TV's speech service) and speech out (text-to-speech).
 * All methods must be called from the main thread.
 */
class Voice(private val app: Application) {
    val listening = MutableStateFlow(false)
    val partial = MutableStateFlow("")
    val speaking = MutableStateFlow(false)

    /** Microphone loudness 0..1 while listening; the animated orb moves with it. */
    val level = MutableStateFlow(0f)

    var onResult: (String) -> Unit = {}
    var onFail: (VoiceError) -> Unit = {}

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val main = Handler(Looper.getMainLooper())
    private var lastPartial = ""

    init {
        tts = TextToSpeech(app) { status -> ttsReady = status == TextToSpeech.SUCCESS }
    }

    fun recognizerAvailable() = SpeechRecognizer.isRecognitionAvailable(app)

    /**
     * [attempt] 0 is the viewer's press; a silent automatic retry (attempt 1) happens when the speech service
     * hears nothing or does not support the exact dialect, so the viewer rarely sees "I didn't catch that".
     */
    fun startListening(lang: String, attempt: Int = 0, tagOverride: String? = null) {
        if (!recognizerAvailable()) { onFail(VoiceError.NO_RECOGNIZER); return }
        val wasSpeaking = speaking.value
        stopSpeaking()
        destroyRecognizer()
        lastPartial = ""
        val r = SpeechRecognizer.createSpeechRecognizer(app)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) { level.value = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f) }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { partial.value = it; if (it.isNotBlank()) lastPartial = it }
            }

            override fun onResults(results: Bundle?) {
                listening.value = false
                level.value = 0f
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull { it.isNotBlank() }.orEmpty().ifBlank { lastPartial }
                partial.value = ""
                lastPartial = ""
                if (text.isBlank()) onFail(VoiceError.DIDNT_CATCH) else onResult(text)
            }

            override fun onError(error: Int) {
                listening.value = false
                level.value = 0f
                partial.value = ""
                // The service often reports "no match" even though it already heard the words: use them.
                val heard = lastPartial
                lastPartial = ""
                val quiet = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                if (quiet && heard.isNotBlank()) { onResult(heard); return }
                if (error == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED || error == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE) {
                    if (attempt == 0 && tagOverride == null) { main.postDelayed({ startListening(lang, 1, if (lang == "ar") "ar" else "en") }, 150); return }
                }
                if ((quiet || error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_CLIENT) && attempt == 0) {
                    if (error != SpeechRecognizer.ERROR_CLIENT) { main.postDelayed({ startListening(lang, 1, tagOverride) }, 250) }
                    return
                }
                onFail(
                    when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> VoiceError.DIDNT_CATCH
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> VoiceError.NETWORK
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> VoiceError.BUSY
                        else -> VoiceError.OTHER
                    },
                )
            }
        })
        val tag = tagOverride ?: if (lang == "ar") "ar-JO" else "en-US"
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2200L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1600L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1200L)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, app.packageName)
        }
        partial.value = ""
        listening.value = true
        // If Dexter was still talking, give the speaker a moment to go quiet so the mic does not hear it.
        if (wasSpeaking) main.postDelayed({ if (recognizer === r) r.startListening(i) }, 350) else r.startListening(i)
    }

    fun stopListening() {
        main.removeCallbacksAndMessages(null)
        recognizer?.stopListening()
        listening.value = false
        level.value = 0f
    }

    private fun destroyRecognizer() {
        recognizer?.let { try { it.cancel(); it.destroy() } catch (_: Exception) { } }
        recognizer = null
        listening.value = false
    }

    private fun isArabic(text: String) = text.count { it in '؀'..'ۿ' } > text.length / 4

    fun speak(text: String) {
        val t = tts ?: return
        if (!ttsReady || text.isBlank()) return
        val loc = if (isArabic(text)) Locale("ar") else Locale.US
        val r = t.setLanguage(loc)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            onFail(VoiceError.TTS_LANGUAGE)
            return
        }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { speaking.value = true }
            override fun onDone(utteranceId: String?) { speaking.value = false }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { speaking.value = false }
            override fun onStop(utteranceId: String?, interrupted: Boolean) { speaking.value = false }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dexter")
    }

    fun stopSpeaking() {
        tts?.stop()
        speaking.value = false
    }

    fun destroy() {
        destroyRecognizer()
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}

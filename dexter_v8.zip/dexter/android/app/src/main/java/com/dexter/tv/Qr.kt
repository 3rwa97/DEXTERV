package com.dexter.tv

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import kotlin.math.max

object Qr {
    /** Crisp black-on-white QR with its own quiet zone, so it scans well from the sofa and never depends on layout padding. */
    fun make(text: String, targetPx: Int = 600): Bitmap {
        val hints = mapOf<EncodeHintType, Any>(
            EncodeHintType.MARGIN to 0,
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
        )
        val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 0, 0, hints)
        val quiet = 3
        val n = m.width
        val scale = max(1, targetPx / (n + quiet * 2))
        val size = (n + quiet * 2) * scale
        val px = IntArray(size * size) { Color.WHITE }
        for (y in 0 until n) for (x in 0 until n) {
            if (m.get(x, y)) {
                for (dy in 0 until scale) {
                    val row = ((y + quiet) * scale + dy) * size
                    for (dx in 0 until scale) px[row + (x + quiet) * scale + dx] = Color.BLACK
                }
            }
        }
        return Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
    }
}

// End-to-end smoke test. Runs the real server in demo mode (no API keys needed).
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'dexter-'));
process.env.DATA_DIR = tmp;
process.env.DB_FILE = path.join(tmp, 'test.db');
process.env.ANTHROPIC_API_KEY = '';
process.env.TMDB_API_KEY = '';
process.env.PUBLIC_URL = 'http://tv.local:8787';

const { server } = await import('./server.js');
await new Promise((r) => server.listen(0, r));
const base = `http://127.0.0.1:${server.address().port}`;

let passed = 0;
async function call(method, p, { body, token, profile, expect = 200 } = {}) {
  const res = await fetch(base + p, {
    method,
    headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}), ...(profile ? { 'x-profile': String(profile) } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const j = await res.json().catch(() => ({}));
  assert.equal(res.status, expect, `${method} ${p} -> ${res.status} ${JSON.stringify(j)}`);
  return j;
}
const ok = (name) => (passed++, console.log('  ok  ' + name));

// 1. TV starts login, shows code + QR link
const start = await call('POST', '/api/device/start', { body: { name: 'Living room' } });
assert.match(start.userCode, /^[A-Z2-9]{6}$/);
assert.equal(start.verifyUrl, `http://tv.local:8787/link?code=${start.userCode}`);
ok('device start gives 6-char code + verify URL');

assert.equal((await call('GET', `/api/device/poll?code=${start.deviceCode}`)).status, 'pending');
ok('poll is pending before approval');

// 2. phone approves (register)
await call('POST', '/api/device/approve', { body: { userCode: 'ZZZZZZ', email: 'a@b.co', password: 'secret1', register: true }, expect: 404 });
await call('POST', '/api/device/approve', { body: { userCode: start.userCode, email: 'nope', password: 'secret1', register: true }, expect: 400 });
const appr = await call('POST', '/api/device/approve', { body: { userCode: start.userCode.toLowerCase(), email: 'orwa@example.com', password: 'secret1', register: true } });
assert.ok(appr.acctToken);
const poll = await call('GET', `/api/device/poll?code=${start.deviceCode}`);
assert.equal(poll.status, 'approved');
const T = poll.token;
ok('phone approves, TV receives token');
await call('GET', `/api/device/poll?code=${start.deviceCode}`, { expect: 410 });
ok('code is single use');

// 3. wrong password / duplicate
const s2 = await call('POST', '/api/device/start', { body: { name: 'Bedroom' } });
await call('POST', '/api/device/approve', { body: { userCode: s2.userCode, email: 'orwa@example.com', password: 'wrongpass', register: false }, expect: 401 });
await call('POST', '/api/device/approve', { body: { userCode: s2.userCode, email: 'orwa@example.com', password: 'secret1', register: true }, expect: 409 });
await call('POST', '/api/device/approve', { body: { userCode: s2.userCode, email: 'orwa@example.com', password: 'secret1', register: false } });
const T2 = (await call('GET', `/api/device/poll?code=${s2.deviceCode}`)).token;
ok('second TV signs into same account; wrong password rejected');

const me = await call('GET', '/api/me', { token: T });
assert.equal(me.creator.name, 'Orwa Shoura');
assert.equal(me.creator.email, 'orwashoura@gmail.com');
ok('creator credit served by /api/me');
await call('GET', '/api/me', { expect: 401 });
await call('GET', '/api/me', { token: 'garbage.token', expect: 401 });
ok('unauthenticated requests rejected');

// 4. profiles (shared across TVs)
const dad = (await call('POST', '/api/profiles', { token: T, body: { name: 'Orwa', lang: 'ar', favorites: ['Breaking Bad', 'Inception'], genres: ['thriller'], services: ['Netflix'] } })).profile;
const kid = (await call('POST', '/api/profiles', { token: T, body: { name: 'Sara', isKid: true, lang: 'en' } })).profile;
assert.equal(dad.favorites.length, 2);
const seen2 = await call('GET', '/api/profiles', { token: T2 });
assert.equal(seen2.profiles.length, 2);
ok('profiles created and visible from the other TV');

// 5. parent PIN guards kid mode
await call('POST', '/api/pin/set', { token: T, body: { pin: '12' }, expect: 400 });
await call('POST', '/api/pin/set', { token: T, body: { pin: '1234' } });
await call('PATCH', `/api/profiles/${kid.id}`, { token: T, body: { isKid: false }, expect: 403 });
await call('PATCH', `/api/profiles/${kid.id}`, { token: T, body: { isKid: false, parentPin: '1234' } });
await call('PATCH', `/api/profiles/${kid.id}`, { token: T, body: { isKid: true, parentPin: '1234' } });
await call('POST', '/api/pin/verify', { token: T, body: { pin: '0000' }, expect: 403 });
ok('parent PIN required to change kid mode');

// 6. home, search, title
await call('GET', '/api/home', { token: T, expect: 400 });
const home = await call('GET', '/api/home', { token: T, profile: dad.id });
assert.ok(home.rows.length > 0 && home.rows[0].items.length > 0);
assert.equal(home.rows[0].title, 'مختارات لك');
ok('home rows load (Arabic row titles for Arabic profile)');
const kidHome = await call('GET', '/api/home', { token: T, profile: kid.id });
const kidIds = new Set(kidHome.rows.flatMap((r) => r.items.map((i) => i.title)));
assert.ok(!kidIds.has('Breaking Bad') && !kidIds.has('Parasite'));
ok('kids profile never sees mature titles');
const s = await call('GET', '/api/search?q=incep', { token: T, profile: dad.id });
assert.equal(s.items[0].title, 'Inception');
const t = await call('GET', '/api/title/movie/2', { token: T, profile: dad.id });
assert.equal(t.title, 'Inception');
await call('GET', '/api/title/tv/3', { token: T, profile: kid.id, expect: 403 });
ok('search + title details + kid block');

// 7. library / memory
let st = await call('POST', '/api/library', { token: T, profile: dad.id, body: { id: 2, type: 'movie', title: 'Inception', poster: 'p', year: '2010', watchlist: true } });
assert.equal(st.state.watchlist, true);
st = await call('POST', '/api/library', { token: T, profile: dad.id, body: { id: 2, type: 'movie', title: 'Inception', watched: true, reaction: 1 } });
assert.deepEqual(st.state, { watchlist: false, watched: true, reaction: 1 });
const lib = await call('GET', '/api/library?filter=watched', { token: T, profile: dad.id });
assert.equal(lib.items.length, 1);
ok('watchlist -> watched -> liked tracking');

// 8. chat, memory of watched, log
const c1 = await call('POST', '/api/chat', { token: T, profile: dad.id, body: { message: 'something funny please comedy' } });
assert.ok(c1.reply && c1.titles.length > 0);
const c2 = await call('POST', '/api/chat', { token: T, profile: dad.id, body: { message: 'اقترح لي مسلسل دراما' } });
assert.equal(c2.lang, 'ar');
assert.ok(!c2.titles.some((x) => x.id === 2)); // never suggests what he watched
const log = await call('GET', '/api/chat/log', { token: T, profile: dad.id });
assert.equal(log.messages.length, 4);
const found = await call('GET', '/api/chat/log?q=funny', { token: T, profile: dad.id });
assert.equal(found.messages.length, 1);
const kidLog = await call('GET', '/api/chat/log', { token: T, profile: kid.id });
assert.equal(kidLog.messages.length, 0);
ok('chat (EN + AR), conversation log, search, per-profile isolation');

// 9. briefing
const br = await call('GET', '/api/briefing?lang=en&tz=Asia/Amman', { token: T, profile: dad.id });
assert.match(br.greeting, /Orwa/);
assert.ok(br.text.length > 5 && br.pick);
const brAr = await call('GET', '/api/briefing?lang=ar', { token: T, profile: dad.id });
assert.match(brAr.greeting, /Orwa/);
assert.ok(/[؀-ۿ]/.test(brAr.text));
ok('daily briefing (EN + AR)');

// 10. family vote
const vote = await call('POST', '/api/vote', { token: T, profile: dad.id, body: { profileIds: [dad.id, kid.id] } });
assert.equal(vote.kidsIncluded, true);
assert.ok(vote.items.length > 0 && !vote.items.some((i) => i.title === 'Parasite'));
ok('family vote overlap (kid-safe when a child is included)');

// 11. phone remote -> TV
const devs = await call('GET', '/api/remote/devices', { token: appr.acctToken });
assert.equal(devs.devices.length, 2);
await call('POST', '/api/remote/push', { token: appr.acctToken, body: { deviceId: devs.devices[0].id, type: 'movie', id: 7, title: 'Coco' } });
await call('GET', '/api/remote/devices', { token: T, expect: 401 });
const inbox = [...(await call('GET', '/api/inbox', { token: T })).items, ...(await call('GET', '/api/inbox', { token: T2 })).items];
assert.equal(inbox.length, 1);
assert.equal(inbox[0].title, 'Coco');
assert.equal((await call('GET', '/api/inbox', { token: T })).items.length + (await call('GET', '/api/inbox', { token: T2 })).items.length, 0);
ok('phone push reaches the TV inbox once');

// 12. sign-out revokes
await call('POST', '/api/logout', { token: T2 });
await call('GET', '/api/me', { token: T2, expect: 401 });
ok('signing out a TV revokes its token');

// 12b. sign-in link works with no PUBLIC_URL configured (uses the address the TV connected with)
const savedUrl = process.env.PUBLIC_URL;
delete process.env.PUBLIC_URL;
const auto = await call('POST', '/api/device/start', { body: { name: 'Kitchen' } });
assert.equal(auto.verifyUrl, `${base}/link?code=${auto.userCode}`);
process.env.PUBLIC_URL = savedUrl;
ok('QR link is built automatically from the address the TV used');

// 13. static pages
const page = await fetch(base + '/link?code=ABC234');
assert.equal(page.status, 200);
assert.match(await page.text(), /Orwa Shoura/);
assert.equal((await fetch(base + '/remote')).status, 200);
assert.equal((await fetch(base + '/../package.json')).status, 404);
ok('phone pages served, path traversal blocked');

console.log(`\n${passed} checks passed`);
server.close();
fs.rmSync(tmp, { recursive: true, force: true });
process.exit(0);

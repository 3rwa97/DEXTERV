#!/usr/bin/env bash
# Starts the Dexter server on an Android phone using Termux.
# Usage:  bash termux-start.sh
cd "$(dirname "$0")" || exit 1

if ! command -v node >/dev/null 2>&1; then
  echo "Installing Node.js (first time only, 1 to 3 minutes)..."
  if command -v pkg >/dev/null 2>&1; then
    pkg update -y && pkg install -y nodejs || { echo "Could not install Node.js. Check the internet connection and run this again."; exit 1; }
  else
    echo "Node.js 22 or newer is required."; exit 1
  fi
fi
if [ "$(node -p 'Number(process.versions.node.split(".")[0])')" -lt 22 ]; then
  echo "Node.js 22 or newer is needed. Run:  pkg upgrade -y   then try again."; exit 1
fi

if [ ! -f .env ]; then
  echo ""
  echo "First-time setup. Press Enter to skip a question (you can add it later)."
  echo ""
  echo "1) TMDB key = the movie and series database (free): themoviedb.org > Settings > API"
  printf "   Paste it here: "; read -r TMDB
  echo "2) Claude key = Dexter's brain (optional, paid): console.anthropic.com > API keys"
  printf "   Paste it here: "; read -r CLAUDE
  printf 'PORT=8787\nREGION=JO\nTMDB_API_KEY=%s\nANTHROPIC_API_KEY=%s\n' "$TMDB" "$CLAUDE" > .env
  echo "Saved. To change a key later, delete the file named .env and run this script again."
fi

# Stop Android from putting the phone's CPU to sleep while Dexter runs.
command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock

echo ""
echo "================ DEXTER SERVER ================"
echo "Keep Termux open. The server stops if you close it."
echo "On the TV, press the Server button and type the address shown below."
echo ""
while true; do
  node --disable-warning=ExperimentalWarning server.js
  echo "Server stopped. Restarting in 3 seconds... (press Ctrl+C to quit)"
  sleep 3
done

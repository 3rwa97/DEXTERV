import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import { promisify } from 'node:util';
import { PORT, ROOT, REGION, CREATOR, publicUrl, lanAddresses } from './lib/env.js';
import { db, now } from './lib/db.js';
import { hashSecret, verifySecret, signToken, verifyToken, makeUserCode, randomId, rateLimit } from './lib/auth.js';
import { tmdbEnabled, search, details, lists, newThisWeek } from './lib/tmdb.js';
import { aiEnabled, chatTurn, explainWhy } from './lib/ai.js';
import { forYou, familyVote, bannedKeys } from './lib/taste.js';
import { buildBriefing } from './lib/briefing.js';

const gzip = promisify(zlib.gzip);
const PUBLIC_DIR = path.join(ROOT, 'public');
const DAY = 86400;

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}
const fail = (status, message) => {
  throw new HttpError(status, message);
};

// ---------- tiny router ----------
const routes = [];
function route(method, pattern, handler, auth = 'device') {
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/:([a-zA-Z]+)/g, (_, k) => (keys.push(k), '([^/]+)')) + '/?$');
  routes.push({ method, re, keys, handler, auth });
}

// ---------- helpers ----------
const J = (s, fallback = []) => {
  try {
    return JSON.parse(s);
  } catch {
    return fallback;
  }
};
const cleanList = (a, max = 40, len = 80) => (Array.isArray(a) ? [...new Set(a.map((x) => String(x).trim().slice(0, len)).filter(Boolean))].slice(0, max) : []);
const COLORS = ['#E50914', '#F5A524', '#17C964', '#0E8AFF', '#9353D3', '#F31260', '#06B7DB', '#FF7A59'];

function profileOut(p) {
  return {
    id: p.id,
    name: p.name,
    color: p.color,
    isKid: !!p.is_kid,
    lang: p.lang,
    hasPin: !!p.pin_hash,
    favorites: J(p.favorites),
    genres: J(p.genres),
    services: J(p.services),
    notes: J(p.notes),
    spoilerSafe: !!p.spoiler_safe,
  };
}
const profileCtx = (p) => ({ ...p, is_kid: p.is_kid, favorites: J(p.favorites), genres: J(p.genres), services: J(p.services), notes: J(p.notes) });
const libOut = (r) => ({ id: r.tmdb_id, type: r.media_type, title: r.title, poster: r.poster, year: r.year, watchlist: !!r.watchlist, watched: !!r.watched, reaction: r.reaction });

const q = {
  profilesOf: db.prepare('SELECT * FROM profiles WHERE account_id = ? ORDER BY id'),
  profile: db.prepare('SELECT * FROM profiles WHERE id = ? AND account_id = ?'),
  libOf: db.prepare('SELECT * FROM library WHERE profile_id = ? ORDER BY updated DESC LIMIT 400'),
  libOne: db.prepare('SELECT * FROM library WHERE profile_id = ? AND tmdb_id = ? AND media_type = ?'),
  device: db.prepare('SELECT * FROM devices WHERE id = ?'),
  touchDevice: db.prepare('UPDATE devices SET last_seen = ? WHERE id = ?'),
  account: db.prepare('SELECT * FROM accounts WHERE id = ?'),
  accountByEmail: db.prepare('SELECT * FROM accounts WHERE email = ?'),
};

// ---------- device login (QR + code) ----------
const pending = new Map(); // deviceCode -> entry
const byUserCode = new Map();
setInterval(() => {
  const t = Date.now();
  for (const [k, v] of pending) if (v.exp < t) (pending.delete(k), byUserCode.delete(v.userCode));
}, 60_000).unref();

route(
  'POST',
  '/api/device/start',
  ({ body, ip, req }) => {
    if (!rateLimit('start:' + ip, 20, 60_000)) fail(429, 'Too many requests');
    let userCode = makeUserCode();
    while (byUserCode.has(userCode)) userCode = makeUserCode();
    const deviceCode = randomId(20);
    const entry = { userCode, deviceCode, name: String(body.name || 'Living room TV').slice(0, 40), exp: Date.now() + 10 * 60_000, status: 'pending' };
    pending.set(deviceCode, entry);
    byUserCode.set(userCode, deviceCode);
    const verifyUrl = `${publicUrl(req)}/link?code=${userCode}`;
    return { deviceCode, userCode, verifyUrl, expiresIn: 600, interval: 3 };
  },
  'none',
);

route(
  'GET',
  '/api/device/poll',
  ({ query }) => {
    const e = pending.get(String(query.code || ''));
    if (!e || e.exp < Date.now()) fail(410, 'Code expired');
    if (e.status !== 'approved') return { status: 'pending' };
    pending.delete(e.deviceCode);
    byUserCode.delete(e.userCode);
    return { status: 'approved', token: e.token };
  },
  'none',
);

const validEmail = (e) => /^[^\s@]{1,64}@[^\s@]{1,255}\.[^\s@]{2,}$/.test(e);

async function loginOrRegister({ email, password, register, ip }) {
  if (!rateLimit('auth:' + ip, 12, 60_000)) fail(429, 'Too many attempts, wait a minute');
  email = String(email || '').trim().toLowerCase();
  password = String(password || '');
  if (!validEmail(email)) fail(400, 'Enter a valid email');
  if (password.length < 6) fail(400, 'Password must be at least 6 characters');
  let acc = q.accountByEmail.get(email);
  if (register) {
    if (acc) fail(409, 'This email already has an account. Sign in instead.');
    const r = db.prepare('INSERT INTO accounts (email, pass_hash, created) VALUES (?,?,?)').run(email, await hashSecret(password), now());
    acc = q.account.get(Number(r.lastInsertRowid));
  } else {
    if (!acc || !(await verifySecret(password, acc.pass_hash))) fail(401, 'Wrong email or password');
  }
  return acc;
}

route(
  'POST',
  '/api/device/approve',
  async ({ body, ip }) => {
    const code = String(body.userCode || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    const dc = byUserCode.get(code);
    const e = dc && pending.get(dc);
    if (!e || e.exp < Date.now()) fail(404, 'That code is not valid or has expired. Check the TV screen.');
    const acc = await loginOrRegister({ email: body.email, password: body.password, register: !!body.register, ip });
    const deviceId = randomId(10);
    db.prepare('INSERT INTO devices (id, account_id, name, created, last_seen) VALUES (?,?,?,?,?)').run(deviceId, acc.id, e.name, now(), now());
    e.token = signToken({ t: 'dev', did: deviceId, aid: acc.id }, 365 * DAY);
    e.status = 'approved';
    return { ok: true, deviceName: e.name, acctToken: signToken({ t: 'acct', aid: acc.id }, 30 * DAY) };
  },
  'none',
);

route('POST', '/api/account/login', async ({ body, ip }) => {
  const acc = await loginOrRegister({ email: body.email, password: body.password, register: false, ip });
  return { acctToken: signToken({ t: 'acct', aid: acc.id }, 30 * DAY), email: acc.email };
}, 'none');

// ---------- device-authenticated API ----------
route('GET', '/api/me', ({ account, device }) => ({
  account: { email: account.email, hasParentPin: !!account.parent_pin_hash },
  device: { id: device.id, name: device.name },
  creator: CREATOR,
  features: { ai: aiEnabled(), tmdb: tmdbEnabled(), region: REGION },
}));

route('POST', '/api/logout', ({ device }) => {
  db.prepare('UPDATE devices SET revoked = 1 WHERE id = ?').run(device.id);
  return { ok: true };
});
route('GET', '/api/devices', ({ account, device }) => ({
  devices: db.prepare('SELECT id, name, last_seen FROM devices WHERE account_id = ? AND revoked = 0 ORDER BY last_seen DESC').all(account.id).map((d) => ({ ...d, current: d.id === device.id })),
}));
route('DELETE', '/api/devices/:id', ({ account, params }) => {
  db.prepare('UPDATE devices SET revoked = 1 WHERE id = ? AND account_id = ?').run(params.id, account.id);
  return { ok: true };
});

// ----- parent PIN -----
async function requireParentPin(account, pin) {
  if (!account.parent_pin_hash) return;
  if (!rateLimit('pin:' + account.id, 8, 60_000)) fail(429, 'Too many attempts');
  if (!(await verifySecret(String(pin || ''), account.parent_pin_hash))) fail(403, 'Wrong parent PIN');
}
route('POST', '/api/pin/set', async ({ account, body }) => {
  const pin = String(body.pin || '');
  if (!/^\d{4}$/.test(pin)) fail(400, 'PIN must be 4 digits');
  await requireParentPin(account, body.current);
  db.prepare('UPDATE accounts SET parent_pin_hash = ? WHERE id = ?').run(await hashSecret(pin), account.id);
  return { ok: true };
});
route('POST', '/api/pin/verify', async ({ account, body }) => {
  if (!account.parent_pin_hash) return { ok: true, set: false };
  await requireParentPin(account, body.pin);
  return { ok: true, set: true };
});

// ----- profiles -----
route('GET', '/api/profiles', ({ account }) => ({ profiles: q.profilesOf.all(account.id).map(profileOut) }));

route('POST', '/api/profiles', async ({ account, body }) => {
  const existing = q.profilesOf.all(account.id);
  if (existing.length >= 8) fail(400, 'Up to 8 profiles per family');
  const name = String(body.name || '').trim().slice(0, 24);
  if (!name) fail(400, 'Name is required');
  const pin = body.pin ? String(body.pin) : null;
  if (pin && !/^\d{4}$/.test(pin)) fail(400, 'PIN must be 4 digits');
  const r = db
    .prepare('INSERT INTO profiles (account_id, name, color, is_kid, lang, pin_hash, favorites, genres, services, created) VALUES (?,?,?,?,?,?,?,?,?,?)')
    .run(
      account.id,
      name,
      COLORS.includes(body.color) ? body.color : COLORS[existing.length % COLORS.length],
      body.isKid ? 1 : 0,
      body.lang === 'ar' ? 'ar' : 'en',
      pin ? await hashSecret(pin) : null,
      JSON.stringify(cleanList(body.favorites)),
      JSON.stringify(cleanList(body.genres, 20, 30)),
      JSON.stringify(cleanList(body.services, 12, 30)),
      now(),
    );
  return { profile: profileOut(q.profile.get(Number(r.lastInsertRowid), account.id)) };
});

route('PATCH', '/api/profiles/:id', async ({ account, params, body }) => {
  const p = q.profile.get(Number(params.id), account.id);
  if (!p) fail(404, 'Profile not found');
  if (body.isKid !== undefined && !!body.isKid !== !!p.is_kid) await requireParentPin(account, body.parentPin);
  const set = [];
  const vals = [];
  const add = (col, v) => (set.push(`${col} = ?`), vals.push(v));
  if (body.name !== undefined) add('name', String(body.name).trim().slice(0, 24) || p.name);
  if (body.color !== undefined && COLORS.includes(body.color)) add('color', body.color);
  if (body.isKid !== undefined) add('is_kid', body.isKid ? 1 : 0);
  if (body.lang !== undefined) add('lang', body.lang === 'ar' ? 'ar' : 'en');
  if (body.favorites !== undefined) add('favorites', JSON.stringify(cleanList(body.favorites)));
  if (body.genres !== undefined) add('genres', JSON.stringify(cleanList(body.genres, 20, 30)));
  if (body.services !== undefined) add('services', JSON.stringify(cleanList(body.services, 12, 30)));
  if (body.spoilerSafe !== undefined) add('spoiler_safe', body.spoilerSafe ? 1 : 0);
  if (body.pin !== undefined) {
    if (body.pin === null || body.pin === '') add('pin_hash', null);
    else if (/^\d{4}$/.test(String(body.pin))) add('pin_hash', await hashSecret(String(body.pin)));
    else fail(400, 'PIN must be 4 digits');
  }
  if (set.length) db.prepare(`UPDATE profiles SET ${set.join(', ')} WHERE id = ?`).run(...vals, p.id);
  return { profile: profileOut(q.profile.get(p.id, account.id)) };
});

route('DELETE', '/api/profiles/:id', async ({ account, params, query }) => {
  const p = q.profile.get(Number(params.id), account.id);
  if (!p) fail(404, 'Profile not found');
  await requireParentPin(account, query.parentPin);
  db.prepare('DELETE FROM profiles WHERE id = ?').run(p.id);
  return { ok: true };
});

route('POST', '/api/profiles/:id/verify-pin', async ({ account, params, body }) => {
  const p = q.profile.get(Number(params.id), account.id);
  if (!p) fail(404, 'Profile not found');
  if (!p.pin_hash) return { ok: true };
  if (!rateLimit('ppin:' + p.id, 8, 60_000)) fail(429, 'Too many attempts');
  if (!(await verifySecret(String(body.pin || ''), p.pin_hash))) fail(403, 'Wrong PIN');
  return { ok: true };
});

// ----- profile-scoped helpers -----
function needProfile({ account, req }) {
  const id = Number(req.headers['x-profile']);
  const p = id ? q.profile.get(id, account.id) : null;
  if (!p) fail(400, 'Select a profile first');
  return profileCtx(p);
}
const langOf = (p, query) => (query?.lang === 'ar' || query?.lang === 'en' ? query.lang : p.lang);

// ----- home -----
const ROW_TITLES = {
  en: { foryou: 'Picked for you', mylist: 'My list', fresh: 'New this week', trending: 'Trending now', arTv: 'Arabic series', arMovie: 'Arabic movies', family: 'Family time', topMovie: 'Top rated movies', topTv: 'Top rated series' },
  ar: { foryou: 'مختارات لك', mylist: 'قائمتي', fresh: 'جديد هذا الأسبوع', trending: 'الأكثر مشاهدة الآن', arTv: 'مسلسلات عربية', arMovie: 'أفلام عربية', family: 'وقت العائلة', topMovie: 'أفضل الأفلام تقييماً', topTv: 'أفضل المسلسلات تقييماً' },
};

route('GET', '/api/home', async (ctx) => {
  const p = needProfile(ctx);
  const lang = langOf(p, ctx.query);
  const lib = q.libOf.all(p.id);
  const kid = !!p.is_kid;
  const exclude = bannedKeys(lib);
  const names = ROW_TITLES[lang];
  const safe = (fn) => fn().catch((e) => (console.error('[home row]', e.message), []));
  const [foryou, fresh, trending, arTv, arMovie, family, topMovie, topTv] = await Promise.all([
    safe(() => forYou(p, lib, lang)),
    safe(() => newThisWeek(lang, { kid })),
    safe(() => lists('trending', lang, { kid, exclude })),
    safe(() => lists('arabic-tv', lang, { kid, exclude })),
    safe(() => lists('arabic-movie', lang, { kid, exclude })),
    safe(() => lists('family', lang, { kid, exclude })),
    safe(() => lists('top-movie', lang, { kid, exclude })),
    safe(() => lists('top-tv', lang, { kid, exclude })),
  ]);
  const mylist = lib.filter((x) => x.watchlist && !x.watched).map((x) => ({ id: x.tmdb_id, type: x.media_type, title: x.title, poster: x.poster, year: x.year }));
  const rowsByKey = { foryou, mylist, fresh, trending, arTv, arMovie, family, topMovie, topTv };
  const order = kid
    ? ['foryou', 'mylist', 'family', 'trending', 'topMovie', 'topTv', 'arTv']
    : lang === 'ar'
      ? ['foryou', 'mylist', 'arTv', 'arMovie', 'fresh', 'trending', 'topMovie', 'topTv', 'family']
      : ['foryou', 'mylist', 'fresh', 'trending', 'arTv', 'arMovie', 'topMovie', 'topTv', 'family'];
  const rows = order
    .map((k) => ({ id: k, title: names[k], items: (rowsByKey[k] || []).slice(0, 20).map(slim) }))
    .filter((r) => r.items.length);
  return { rows };
});
const slim = (x) => ({ id: x.id, type: x.type, title: x.title, year: x.year, poster: x.poster, backdrop: x.backdrop || null, rating: x.rating || 0, overview: (x.overview || '').slice(0, 220), lovedBy: x.lovedBy || undefined, why: x.why || undefined });

route('GET', '/api/briefing', async (ctx) => {
  const p = needProfile(ctx);
  const lang = langOf(p, ctx.query);
  const tz = /^[A-Za-z_]+\/[A-Za-z_\-/]+$/.test(ctx.query.tz || '') ? ctx.query.tz : 'Asia/Amman';
  const b = await buildBriefing({ profile: p, library: q.libOf.all(p.id), tz, lang });
  return { ...b, pick: b.pick && slim(b.pick), newThisWeek: b.newThisWeek.map(slim) };
});

route('GET', '/api/search', async (ctx) => {
  const p = needProfile(ctx);
  const text = String(ctx.query.q || '').trim().slice(0, 80);
  if (text.length < 2) return { items: [] };
  return { items: (await search(text, langOf(p, ctx.query), { kid: !!p.is_kid })).map(slim) };
});

route('GET', '/api/title/:type/:id', async (ctx) => {
  const p = needProfile(ctx);
  const type = ctx.params.type === 'tv' ? 'tv' : 'movie';
  const id = Number(ctx.params.id);
  const d = await details(type, id, langOf(p, ctx.query));
  if (p.is_kid && d.genreIds && !d.genreIds.some((g) => [16, 10751, 10762].includes(g))) fail(403, 'Not available on a kids profile');
  const st = q.libOne.get(p.id, id, type);
  return { ...d, similar: (d.similar || []).map(slim), state: st ? { watchlist: !!st.watchlist, watched: !!st.watched, reaction: st.reaction } : { watchlist: false, watched: false, reaction: 0 } };
});

route('POST', '/api/why', async (ctx) => {
  const p = needProfile(ctx);
  const lang = langOf(p, ctx.body);
  const item = await details(ctx.body.type === 'tv' ? 'tv' : 'movie', Number(ctx.body.id), lang);
  return { text: await explainWhy({ profile: p, library: q.libOf.all(p.id), item, lang }) };
});

// ----- library (watchlist / watched / reactions) -----
route('GET', '/api/library', (ctx) => {
  const p = needProfile(ctx);
  const rows = q.libOf.all(p.id).map(libOut);
  const f = ctx.query.filter;
  const items = f === 'watchlist' ? rows.filter((x) => x.watchlist && !x.watched) : f === 'watched' ? rows.filter((x) => x.watched) : f === 'liked' ? rows.filter((x) => x.reaction === 1) : rows;
  return { items };
});

route('POST', '/api/library', (ctx) => {
  const p = needProfile(ctx);
  const b = ctx.body;
  const type = b.type === 'tv' ? 'tv' : 'movie';
  const id = Number(b.id);
  if (!id || !b.title) fail(400, 'id and title required');
  const cur = q.libOne.get(p.id, id, type);
  const watched = b.watched !== undefined ? (b.watched ? 1 : 0) : (cur?.watched ?? 0);
  let watchlist = b.watchlist !== undefined ? (b.watchlist ? 1 : 0) : (cur?.watchlist ?? 0);
  if (watched && b.watchlist === undefined) watchlist = 0; // finished titles leave the list
  const reaction = b.reaction !== undefined ? Math.max(-1, Math.min(1, Number(b.reaction) | 0)) : (cur?.reaction ?? 0);
  if (!watched && !watchlist && !reaction) {
    db.prepare('DELETE FROM library WHERE profile_id = ? AND tmdb_id = ? AND media_type = ?').run(p.id, id, type);
    return { state: { watchlist: false, watched: false, reaction: 0 } };
  }
  db.prepare(
    `INSERT INTO library (profile_id, tmdb_id, media_type, title, poster, year, watchlist, watched, reaction, updated)
     VALUES (?,?,?,?,?,?,?,?,?,?)
     ON CONFLICT(profile_id, tmdb_id, media_type) DO UPDATE SET watchlist=excluded.watchlist, watched=excluded.watched, reaction=excluded.reaction, updated=excluded.updated`,
  ).run(p.id, id, type, String(b.title).slice(0, 200), b.poster || cur?.poster || null, String(b.year || cur?.year || ''), watchlist, watched, reaction, now());
  return { state: { watchlist: !!watchlist, watched: !!watched, reaction } };
});

// ----- chat + conversation log -----
route('POST', '/api/chat', async (ctx) => {
  const p = needProfile(ctx);
  const message = String(ctx.body.message || '').trim().slice(0, 600);
  if (!message) fail(400, 'Say something first');
  if (!rateLimit('chat:' + p.id, 30, 60_000)) fail(429, 'Slow down a little');
  const lib = q.libOf.all(p.id);
  const history = db.prepare('SELECT role, content FROM chat_log WHERE profile_id = ? ORDER BY id DESC LIMIT 12').all(p.id).reverse();
  db.prepare('INSERT INTO chat_log (profile_id, role, content, created) VALUES (?,?,?,?)').run(p.id, 'user', message, now());
  const tz = ctx.body.tz || 'Asia/Amman';
  let nowText;
  try {
    nowText = new Intl.DateTimeFormat('en-GB', { dateStyle: 'full', timeStyle: 'short', timeZone: tz }).format(new Date());
  } catch {
    nowText = new Date().toISOString();
  }
  const out = await chatTurn({ profile: p, library: lib, history, message, nowText, region: REGION });
  const titles = out.titles.map(slim);
  db.prepare('INSERT INTO chat_log (profile_id, role, content, titles, created) VALUES (?,?,?,?,?)').run(p.id, 'assistant', out.reply, titles.length ? JSON.stringify(titles) : null, now());
  if (out.learn.length) {
    const notes = cleanList([...p.notes, ...out.learn], 30, 120);
    db.prepare('UPDATE profiles SET notes = ? WHERE id = ?').run(JSON.stringify(notes), p.id);
  }
  return { reply: out.reply, lang: out.lang, titles, openApp: out.openApp };
});

route('GET', '/api/chat/log', (ctx) => {
  const p = needProfile(ctx);
  const limit = Math.min(Number(ctx.query.limit) || 40, 100);
  const before = Number(ctx.query.before) || Number.MAX_SAFE_INTEGER;
  const text = String(ctx.query.q || '').trim();
  const rows = text
    ? db.prepare("SELECT * FROM chat_log WHERE profile_id = ? AND id < ? AND content LIKE ? ESCAPE '\\' ORDER BY id DESC LIMIT ?").all(p.id, before, `%${text.replace(/[\\%_]/g, '\\$&')}%`, limit)
    : db.prepare('SELECT * FROM chat_log WHERE profile_id = ? AND id < ? ORDER BY id DESC LIMIT ?').all(p.id, before, limit);
  return { messages: rows.reverse().map((r) => ({ id: r.id, role: r.role, content: r.content, titles: r.titles ? J(r.titles) : [], at: r.created })) };
});
route('DELETE', '/api/chat/log', (ctx) => {
  const p = needProfile(ctx);
  db.prepare('DELETE FROM chat_log WHERE profile_id = ?').run(p.id);
  return { ok: true };
});

// ----- family vote -----
route('POST', '/api/vote', async (ctx) => {
  needProfile(ctx);
  const ids = [...new Set((ctx.body.profileIds || []).map(Number))].slice(0, 8);
  const profiles = ids.map((id) => q.profile.get(id, ctx.account.id)).filter(Boolean).map(profileCtx);
  if (!profiles.length) fail(400, 'Pick at least one person');
  const libs = new Map(profiles.map((p) => [p.id, q.libOf.all(p.id)]));
  const lang = langOf(profiles[0], ctx.body);
  const items = await familyVote(profiles, libs, lang);
  return { items: items.map(slim), kidsIncluded: profiles.some((p) => p.is_kid) };
});

// ----- phone -> TV push -----
const inbox = new Map(); // deviceId -> [item]
route('GET', '/api/inbox', ({ device }) => {
  const items = inbox.get(device.id) || [];
  inbox.delete(device.id);
  return { items };
});

route(
  'GET',
  '/api/remote/devices',
  ({ account }) => ({ devices: db.prepare('SELECT id, name, last_seen FROM devices WHERE account_id = ? AND revoked = 0 ORDER BY last_seen DESC').all(account.id) }),
  'acct',
);
route(
  'GET',
  '/api/remote/search',
  async ({ query }) => {
    const text = String(query.q || '').trim().slice(0, 80);
    if (text.length < 2) return { items: [] };
    return { items: (await search(text, query.lang === 'ar' ? 'ar' : 'en')).map(slim) };
  },
  'acct',
);
route(
  'POST',
  '/api/remote/push',
  ({ account, body }) => {
    const dev = q.device.get(String(body.deviceId || ''));
    if (!dev || dev.account_id !== account.id || dev.revoked) fail(404, 'TV not found');
    const arr = inbox.get(dev.id) || [];
    arr.push({ id: Number(body.id), type: body.type === 'tv' ? 'tv' : 'movie', title: String(body.title || '').slice(0, 120), poster: body.poster || null, at: now() });
    inbox.set(dev.id, arr.slice(-10));
    return { ok: true };
  },
  'acct',
);

// ---------- server ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };

async function send(req, res, status, data, headers = {}) {
  let buf = Buffer.from(typeof data === 'string' || Buffer.isBuffer(data) ? data : JSON.stringify(data));
  const h = { 'content-type': 'application/json; charset=utf-8', 'x-content-type-options': 'nosniff', ...headers };
  if (buf.length > 1024 && /\bgzip\b/.test(req.headers['accept-encoding'] || '')) {
    buf = await gzip(buf);
    h['content-encoding'] = 'gzip';
  }
  h['content-length'] = buf.length;
  res.writeHead(status, h);
  res.end(buf);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > 100_000) {
        reject(new HttpError(413, 'Body too large'));
        req.destroy();
      } else chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString()));
      } catch {
        reject(new HttpError(400, 'Invalid JSON'));
      }
    });
    req.on('error', reject);
  });
}

function authenticate(req, kind) {
  const token = (req.headers.authorization || '').replace(/^Bearer /i, '');
  const p = verifyToken(token);
  if (!p) fail(401, 'Please sign in again');
  if (kind === 'device') {
    if (p.t !== 'dev') fail(401, 'Device token required');
    const device = q.device.get(p.did);
    if (!device || device.revoked) fail(401, 'This TV was signed out');
    if (Date.now() - device.last_seen > 5 * 60_000) q.touchDevice.run(now(), device.id);
    const account = q.account.get(device.account_id);
    if (!account) fail(401, 'Account missing');
    return { device, account };
  }
  if (p.t !== 'acct') fail(401, 'Sign in required');
  const account = q.account.get(p.aid);
  if (!account) fail(401, 'Account missing');
  return { account };
}

function serveStatic(req, res, pathname) {
  const map = { '/link': 'link.html', '/remote': 'remote.html', '/': 'link.html' };
  const rel = map[pathname] || pathname.replace(/^\/+/, '');
  const file = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!file.startsWith(PUBLIC_DIR) || !fs.existsSync(file) || !fs.statSync(file).isFile()) return false;
  const ext = path.extname(file);
  send(req, res, 200, fs.readFileSync(file), { 'content-type': MIME[ext] || 'application/octet-stream', 'cache-control': ext === '.html' ? 'no-cache' : 'public, max-age=86400' });
  return true;
}

export const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').toString().split(',')[0].trim();
  try {
    if (url.pathname === '/health') return send(req, res, 200, { ok: true, ai: aiEnabled(), tmdb: tmdbEnabled() });
    const r = routes.find((x) => x.method === req.method && x.re.test(url.pathname));
    if (!r) {
      if (req.method === 'GET' && serveStatic(req, res, url.pathname)) return;
      return send(req, res, 404, { error: 'Not found' });
    }
    const m = url.pathname.match(r.re);
    const params = Object.fromEntries(r.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])]));
    const ctx = { req, res, ip, params, query: Object.fromEntries(url.searchParams), body: {} };
    if (req.method === 'POST' || req.method === 'PATCH') ctx.body = await readBody(req);
    if (r.auth !== 'none') Object.assign(ctx, authenticate(req, r.auth));
    const out = await r.handler(ctx);
    send(req, res, 200, out, { 'cache-control': 'no-store' });
  } catch (e) {
    const status = e.status || 500;
    if (status === 500) console.error('[error]', req.method, url.pathname, e);
    send(req, res, status, { error: status === 500 ? 'Something went wrong' : e.message });
  }
});

if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(new URL(import.meta.url).pathname)) {
  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Dexter backend running on port ${PORT}`);
    const lan = lanAddresses();
    if (lan.length) console.log(`  TV server address: ${lan.map((a) => `http://${a}:${PORT}`).join('   or   ')}`);
    else console.log('  TV server address: http://YOUR-PHONE-IP:' + PORT + '   (see Wi-Fi settings for the IP)');
    console.log(`  Claude AI  : ${aiEnabled() ? 'ON' : 'OFF (simple fallback replies)'}`);
    console.log(`  TMDB data  : ${tmdbEnabled() ? 'ON' : 'OFF (tiny demo catalog)'}`);
  });
}

# Dexter: AI movie & series companion for Google TV

Created by **Orwa Shoura** · orwashoura@gmail.com

Dexter talks Arabic and English, learns your taste, suggests what to watch, keeps a conversation log,
gives every family member their own profile, and works on every TV in the house.

```
dexter/
  backend/   Node 22 server: accounts, QR login, profiles, memory, Claude chat, movie data, briefings
  android/   Native Android TV app (Kotlin + Jetpack Compose)
```

## What's included

| Feature | How it works |
|---|---|
| Arabic + English chat and voice | Claude answers in the language you used; voice in/out for both |
| Suggestions from your favorites | Favorites + likes + genres feed a taste engine; never repeats watched/disliked titles |
| Access to (nearly) all movies and series | TMDB catalog, with "where to watch" for Jordan (Netflix, Shahid, Prime...) |
| Daily Briefing | Greeting, date, weather, tonight's pick, what's new on your services; read aloud on request |
| Login on every TV | TV shows a code **above** a QR; you approve on your phone; profiles sync across TVs |
| Family profiles | Up to 8, optional PIN per profile, Kids profiles (family-safe only), parent PIN |
| Conversation log | Per profile, searchable, can be cleared |
| Memory | Watchlist, watched, likes/dislikes, plus taste notes Dexter learns from chat |
| Family vote | Pick who is watching; Dexter finds titles everyone will enjoy (kid-safe if a child is included) |
| Trailers | Inside the app (YouTube) |
| "Why this?" | Dexter explains a suggestion, without spoilers |
| Spoiler-safe mode | On by default |
| Phone remote | `http://YOUR-SERVER/remote`: search on your phone, send to the TV |
| PrimeVision bridge | Open your IPTV app from Dexter, optionally with a search (see below) |
| Smooth on the TV | Poster cache, instant start from cached data, stale-while-revalidate, gzip, server-side caching |
| 100% fit on any TV | The UI is drawn on a 960x540 canvas and scaled to your screen, with TV-safe margins |

## What's new in this version (TV-only mode)

- **Gemini**: put your Google AI Studio key in `android/gradle.properties` (`GEMINI_KEY=`) or in Settings > Keys. Gemini is used first for chat, moods and the briefing; a Claude key, if present, is the backup.
- **Mood picker**: new Mood tab and a mood strip on Home. Pick a mood card, say it, or type it (for example "a complex crime movie with unexpected endings") and Dexter returns six precise picks.
- **TVmaze + Jikan**: new Home rows (on the air tonight, new seasons this week, anime airing now) and the next episode date on series pages. Both are free and need no key.
- **New look**: focused items zoom with a glowing frame, drawn icons, and a Siri-style animated orb at the bottom that reacts to your voice while Dexter listens, thinks and speaks.
- The server mode (`backend/`) was not changed: Gemini, moods and TVmaze work in TV-only mode.

## Easiest way: TV-only mode (no server, no computer, no account)

This is the setup for people with only a phone (iPhone is fine).

1. Rebuild the TV app with your online build service and install it on the TV.
2. On the sign-in screen press **"Use on this TV only (no account)"**.
3. Get a free movie-database key from your phone: open **themoviedb.org**, create a free account, then
   **Settings > API > Create > Developer**. Copy the short **API Key** (32 characters).
4. On the TV open **Settings > Keys > TMDB key** and type it. Tip: the **Google TV app on your iPhone**
   has a remote with a keyboard, so you can paste/type the key from the phone.
5. Optional: add a **Claude key** (console.anthropic.com) for smarter chat. Without it Dexter still
   searches, suggests by mood/genre, and gives briefings with simpler wording.

Each TV keeps its own profiles, watch history and conversation log (stored on that TV). To use another
TV, repeat the steps there. Family sync between TVs needs the server mode below.

## 1. Run the backend

Needs Node 22.13 or newer.

```bash
cd backend
cp .env.example .env     # then edit it
npm start
npm test                 # optional: 20 end-to-end checks, no keys needed
```

In `.env` set:
- `PUBLIC_URL` is optional. Leave it empty and Dexter builds the QR link from the address the TV connected with.
  Set it only if you host Dexter behind a domain name.
- `TMDB_API_KEY` (free at themoviedb.org/settings/api). Without it Dexter uses a 12-title demo catalog.
- `ANTHROPIC_API_KEY` (console.anthropic.com). Without it Dexter uses simple built-in replies.

**No computer?** Run the server on an Android phone with Termux. Follow `backend/PHONE-SETUP.txt`
(three commands, no rebuild of the TV app needed; type the phone's address into the app's Server button).

Where to host it:
- **On an Android phone/tablet** (no computer): see above. Keep it plugged in, on the same Wi-Fi, with Termux open.
- **At home** (easiest with a computer): any always-on PC or Raspberry Pi on your Wi-Fi. Works for every TV in the house.
- **Online** (works away from home too): any small VPS or container host with a persistent disk.
  A `Dockerfile` is included; mount a volume at `/data`. Use HTTPS and set `PUBLIC_URL` to the https address.

Your API keys stay on the server. The TV app never sees them.

## 2. Build and install the TV app

1. Install **Android Studio** and open the `android/` folder (let it sync; it creates the Gradle wrapper).
2. In `android/gradle.properties` set `DEXTER_SERVER` to your server's address
   (you can also change it later inside the app, on the sign-in screen or in Settings).
3. **Build > Build Bundle(s) / APK(s) > Build APK(s)**, or run `./gradlew assembleRelease`.
4. Install on the TV:
   - Turn on Developer options and USB/network debugging on the TV, then
     `adb connect TV_IP:5555` and `adb install app/build/outputs/apk/release/app-release.apk`
   - or copy the APK to a USB stick / use the "Send Files to TV" app, then open it on the TV.

Do the same on every TV; each one shows its own sign-in code.

## 3. First run

1. The TV shows a code with a QR beneath it. Scan it (or open the link) on your phone, enter the code,
   sign in or create your account. The TV continues by itself.
2. Create profiles. Add favorites, genres, and your streaming apps for better suggestions.
3. Home shows your Daily Briefing, then rows picked for you. Open a title to add it to your list,
   mark it watched, like/dislike it, play the trailer, or ask "Why this?".

## Voice and the remote's microphone

- Pressing **OK** on the big mic button starts listening. Dexter also listens when the app receives the
  remote's search/mic key (or the yellow key as a backup).
- Many Google TV remotes reserve the mic button for Google Assistant, so the system may grab it before
  Dexter does. If so, use the on-screen mic button (it is focused automatically in the chat screen)
  or the yellow key. Please test which one your Skyworth remote supports.
- You can say "briefing", "my list", "settings", "open PrimeVision" or "family vote", and everything
  else goes to Dexter.
- Spoken Arabic replies need an Arabic text-to-speech voice on the TV
  (TV Settings > System > Language > Text-to-speech). If it is missing, Dexter shows the text and tells you.
- Microphone permission is requested the first time you use voice.

## Connecting PrimeVision (your IPTV app)

Dexter already has a bridge. In **Settings > Connected apps** enter PrimeVision's package name
(its `applicationId`). Dexter can then open PrimeVision from the top bar, from any title's page,
or by voice ("open PrimeVision"). It tries, in order:

1. Your deep-link template, for example `primevision://search?q={query}`
2. A standard `android.intent.action.SEARCH` intent with the title
3. Just launching the app (the title is also passed as an extra named `query`)

To make options 1 or 2 work, add this to PrimeVision's `AndroidManifest.xml` inside the activity that should open:

```xml
<intent-filter>
    <action android:name="android.intent.action.VIEW" />
    <category android:name="android.intent.category.DEFAULT" />
    <category android:name="android.intent.category.BROWSABLE" />
    <data android:scheme="primevision" android:host="search" />
</intent-filter>
<intent-filter>
    <action android:name="android.intent.action.SEARCH" />
    <category android:name="android.intent.category.DEFAULT" />
</intent-filter>
```

and read the query in that activity (in `onCreate` and `onNewIntent`):

```kotlin
val q = intent?.data?.getQueryParameter("q")
    ?: intent?.getStringExtra(android.app.SearchManager.QUERY)
    ?: intent?.getStringExtra("query")
if (!q.isNullOrBlank()) openSearch(q)   // your own function
```

To go further (for example "play channel X" or "what's on now") I need from you: PrimeVision's package name,
its `AndroidManifest.xml`, the code that starts a channel and does search, and what kind of playlist it
uses (M3U, Xtream Codes, or a custom API).

## Limits to know about

- Dexter suggests and opens apps. It cannot play Netflix, Shahid and others itself, and it cannot see what
  you watched inside them, so watched/liked state comes from you (one button on each title page).
- Opening Netflix and similar apps launches the app; deep-linking to a specific title is not offered by those apps.
- The Android app was written carefully but I could not compile it in my sandbox (no Android SDK).
  Expect to fix a small thing or two on the first Android Studio build. The backend is tested.
- `usesCleartextTraffic` is on so a plain `http://` home server works. Use HTTPS if you host online.
- The release APK is signed with the debug key so you can sideload it. Publishing on the Play Store would need your own key.

## Project map

- `backend/server.js` routes; `lib/ai.js` Claude + fallback; `lib/tmdb.js` movie data + cache;
  `lib/taste.js` recommendations and family vote; `lib/briefing.js` Daily Briefing; `public/` phone pages.
- `android/app/src/main/java/com/dexter/tv/` `AppViewModel.kt` (all logic), `Voice.kt`, `Launcher.kt`
  (PrimeVision and app launching), `ui/` (screens).
